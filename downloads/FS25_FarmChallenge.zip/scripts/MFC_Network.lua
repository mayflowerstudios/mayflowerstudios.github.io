--
-- MFC_Network.lua
--
-- Server-authoritative multiplayer sync, per farm.
--
-- Every farm runs its own challenge. The server owns the files, judges each
-- farm's run and broadcasts one snapshot containing every farm's state; each
-- client keeps the lot and shows its own. Clients can request exactly two
-- things -- start and clear -- and the server always applies them to the
-- requester's OWN farm, resolved from the connection rather than from anything
-- the client sent. A farm manager (or the server admin) is the only one allowed
-- to make either request.
--
-- Snapshots carry just what a client needs to draw the page, the HUD and the
-- end-of-run dialog, not the server's bookkeeping.
--

MFC_Network = {}
local NET = MFC_Network

local function MFC()
    return MayflowerFarmChallenge
end

-- ============================================================
-- Stream helpers
-- ============================================================

local function writeOptionalFloat(streamId, value)
    streamWriteBool(streamId, value ~= nil)
    if value ~= nil then streamWriteFloat32(streamId, tonumber(value) or 0) end
end

local function readOptionalFloat(streamId)
    if streamReadBool(streamId) then return streamReadFloat32(streamId) end
    return nil
end

local function writeOptionalInt(streamId, value)
    streamWriteBool(streamId, value ~= nil)
    if value ~= nil then streamWriteInt32(streamId, math.floor(tonumber(value) or 0)) end
end

local function readOptionalInt(streamId)
    if streamReadBool(streamId) then return streamReadInt32(streamId) end
    return nil
end

local function clampU8(value, lo)
    return math.max(lo or 0, math.min(255, math.floor(tonumber(value) or (lo or 0))))
end

local function clampU16(value)
    return math.max(0, math.min(65535, math.floor(tonumber(value) or 0)))
end

local function writeFlagSet(streamId, set)
    local keys = {}
    for key, enabled in pairs(set or {}) do
        if enabled == true and #keys < 255 then table.insert(keys, tostring(key)) end
    end
    streamWriteUInt8(streamId, #keys)
    for _, key in ipairs(keys) do streamWriteString(streamId, key) end
end

local function readFlagSet(streamId)
    local out = {}
    for _ = 1, streamReadUInt8(streamId) do
        out[streamReadString(streamId)] = true
    end
    return out
end

-- ============================================================
-- Challenge serialisation
-- ============================================================

function NET.writeCampaign(streamId, c)
    streamWriteInt32(streamId, math.floor(c.farmId or 0))
    streamWriteInt32(streamId, math.floor(c.seed or 0))
    streamWriteString(streamId, tostring(c.name or "Challenge"))
    streamWriteString(streamId, tostring(c.state or "active"))
    streamWriteString(streamId, tostring(c.difficulty or ""))
    streamWriteUInt8(streamId, clampU8(c.years, 0))
    streamWriteInt32(streamId, math.floor(c.maxLoan or -1))
    writeOptionalInt(streamId, c.endYearsUsed)
    writeOptionalFloat(streamId, c.endGoalValue)
    writeOptionalFloat(streamId, c.repNetWorth)
    writeOptionalInt(streamId, c.repFields)
    writeFlagSet(streamId, c.restrictions)

    local milestones = c.milestones or {}
    local count = math.min(#milestones, 16)
    streamWriteUInt8(streamId, count)
    for i = 1, count do
        local m = milestones[i]
        streamWriteUInt8(streamId, clampU8(m.order or i, 0))
        streamWriteString(streamId, tostring(m.kind or "NetWorth"))
        streamWriteString(streamId, tostring(m.metric or m.kind or "NetWorth"))
        streamWriteFloat32(streamId, tonumber(m.target) or 0)
        streamWriteString(streamId, tostring(m.title or ""))
        streamWriteUInt8(streamId, clampU8(m.dueYear or 1, 1))
        streamWriteUInt8(streamId, math.max(1, math.min(4, math.floor(m.dueQuarter or 4))))
        streamWriteBool(streamId, m.completed == true)
        streamWriteBool(streamId, m.missed == true)
    end
end

-- Must mirror writeCampaign field for field, in order.
--
-- Every read is its own statement rather than a field in a table constructor:
-- Lua does not actually guarantee the evaluation order of constructor fields,
-- and for a stream decoder that order IS the format. One statement per field
-- makes the sequence explicit and impossible to reorder by accident.
function NET.readCampaign(streamId)
    local c = {}
    c.farmId = streamReadInt32(streamId)
    c.seed = streamReadInt32(streamId)
    c.name = streamReadString(streamId)
    c.state = streamReadString(streamId)
    c.difficulty = streamReadString(streamId)
    c.years = streamReadUInt8(streamId)
    c.maxLoan = streamReadInt32(streamId)
    c.endYearsUsed = readOptionalInt(streamId)
    c.endGoalValue = readOptionalFloat(streamId)
    c.repNetWorth = readOptionalFloat(streamId)
    c.repFields = readOptionalInt(streamId)
    c.restrictions = readFlagSet(streamId)
    c.milestones = {}

    local count = streamReadUInt8(streamId)
    for _ = 1, count do
        local m = {}
        m.order = streamReadUInt8(streamId)
        m.kind = streamReadString(streamId)
        m.metric = streamReadString(streamId)
        m.target = streamReadFloat32(streamId)
        m.title = streamReadString(streamId)
        m.dueYear = streamReadUInt8(streamId)
        m.dueQuarter = streamReadUInt8(streamId)
        m.completed = streamReadBool(streamId)
        m.missed = streamReadBool(streamId)
        table.insert(c.milestones, m)
    end
    return c
end

-- ============================================================
-- Permissions
--
-- Both checks resolve the player's OWN farm, so "may I manage this?" is always
-- asked about the farm the player belongs to and never about anyone else's.
-- ============================================================

local function getUserAndFarm(connection)
    if g_currentMission == nil or g_farmManager == nil then return nil, nil end
    local manager = g_currentMission.userManager
    local user, userId = nil, nil
    if connection ~= nil and manager ~= nil then
        if manager.getUserByConnection ~= nil then
            user = manager:getUserByConnection(connection)
        end
        if manager.getUserIdByConnection ~= nil then
            userId = manager:getUserIdByConnection(connection)
        end
    end
    if userId == nil and user ~= nil and user.getId ~= nil then userId = user:getId() end

    local farm = nil
    if userId ~= nil and g_farmManager.getFarmByUserId ~= nil then
        farm = g_farmManager:getFarmByUserId(userId)
    end
    return user, farm
end

local function userIsFarmManager(user, farm)
    if user == nil then return false end
    -- The server admin can manage any farm they are standing in.
    if user.getIsMasterUser ~= nil and user:getIsMasterUser() then return true end
    if user.getIsFarmManager ~= nil then
        local ok, value = pcall(function() return user:getIsFarmManager() end)
        if ok and value == true then return true end
    end
    local userId = (user.getId ~= nil) and user:getId() or nil
    if farm == nil or userId == nil then return false end
    if farm.getIsUserFarmManager ~= nil then
        local ok, value = pcall(function() return farm:getIsUserFarmManager(userId) end)
        if ok and value == true then return true end
    end
    local player = farm.userIdToPlayer and farm.userIdToPlayer[userId] or nil
    if player ~= nil and player.isFarmManager == true then return true end
    return farm.farmManagerUserId ~= nil and farm.farmManagerUserId == userId
end

-- Buying vehicles is the closest stock permission to "may commit the farm to
-- something", so it stands in for farm-management rights.
local function hasFarmPermission(connection, farmId)
    if g_currentMission == nil or g_currentMission.getHasPlayerPermission == nil
        or Farm == nil or Farm.PERMISSION == nil or Farm.PERMISSION.BUY_VEHICLE == nil then
        return false
    end
    local ok, allowed = pcall(function()
        if connection ~= nil then
            return g_currentMission:getHasPlayerPermission(Farm.PERMISSION.BUY_VEHICLE, connection, farmId)
        end
        return g_currentMission:getHasPlayerPermission(Farm.PERMISSION.BUY_VEHICLE)
    end)
    return ok and allowed == true
end

-- May the player behind this connection manage their own farm's challenge?
function NET.canConnectionManage(connection)
    if connection == nil then return true end
    local user, farm = getUserAndFarm(connection)
    -- No farm means nothing to run a challenge on.
    if farm == nil or (farm.farmId or 0) <= 0 then return false end
    if userIsFarmManager(user, farm) then return true end
    return hasFarmPermission(connection, farm.farmId)
end

-- Same question for the player sitting at this machine.
function NET.canLocalManage()
    if g_currentMission == nil then return true end
    local mod = MFC()
    if mod == nil then return true end
    if not mod.isMultiplayer() then return true end
    -- Without a farm there is nothing to start a challenge for.
    if mod.localFarmId() <= 0 then return false end
    if g_currentMission.isMasterUser == true then return true end
    if hasFarmPermission(nil, nil) then return true end

    local user, farm = nil, nil
    local manager = g_currentMission.userManager
    if manager ~= nil and manager.getUserByUserId ~= nil and g_currentMission.playerUserId ~= nil then
        user = manager:getUserByUserId(g_currentMission.playerUserId)
    end
    if user ~= nil and user.getId ~= nil and g_farmManager ~= nil
        and g_farmManager.getFarmByUserId ~= nil then
        farm = g_farmManager:getFarmByUserId(user:getId())
    end
    return userIsFarmManager(user, farm)
end

-- The farm a request must be applied to. Taken from the connection, never from
-- the payload, so a client cannot act on someone else's farm.
function NET.getConnectionFarmId(connection)
    local _, farm = getUserAndFarm(connection)
    return (farm ~= nil and farm.farmId) or 0
end

-- ============================================================
-- Full state snapshot (server -> clients)
--
-- One event carries every farm's run. Clients keep all of them: the page and
-- HUD show the player's own farm, while the rule hooks can still answer
-- correctly for a vehicle owned by another farm.
-- ============================================================

MFC_StateEvent = {}
local MFC_StateEvent_mt = Class(MFC_StateEvent, Event)
InitEventClass(MFC_StateEvent, "MFC_StateEvent")

function MFC_StateEvent.emptyNew()
    return Event.new(MFC_StateEvent_mt)
end

function MFC_StateEvent.new(entries)
    local self = MFC_StateEvent.emptyNew()
    self.entries = entries or {}
    return self
end

function MFC_StateEvent:writeStream(streamId, connection)
    local entries = self.entries or {}
    local count = math.min(#entries, 255)
    streamWriteUInt8(streamId, count)
    for i = 1, count do
        local entry = entries[i]
        NET.writeCampaign(streamId, entry.campaign)
        streamWriteUInt8(streamId, clampU8(entry.challengeYear or 1, 1))
        streamWriteFloat32(streamId, entry.netWorth or 0)
        streamWriteUInt16(streamId, clampU16(entry.fields))
        streamWriteFloat32(streamId, entry.income or 0)
    end
end

function MFC_StateEvent:readStream(streamId, connection)
    self.campaigns = {}
    local count = streamReadUInt8(streamId)
    for _ = 1, count do
        local c = NET.readCampaign(streamId)
        c.challengeYear = streamReadUInt8(streamId)
        local netWorth = streamReadFloat32(streamId)
        local fields = streamReadUInt16(streamId)
        local income = streamReadFloat32(streamId)
        c.live = { netWorth = netWorth, fields = fields, income = income }
        c.income = income
        c.elapsedYears = math.max(0, (c.challengeYear or 1) - 1)
        c.setupPending = false
        if (c.farmId or 0) > 0 then self.campaigns[c.farmId] = c end
    end
    self:run(connection)
end

function MFC_StateEvent:run(connection)
    -- Only ever accept this from the server.
    if connection == nil or not connection:getIsServer() then return end
    local mod = MFC()
    if mod ~= nil and mod.applyNetworkState ~= nil then
        mod.applyNetworkState(self.campaigns)
    end
end

-- ============================================================
-- Requests (client -> server)
-- ============================================================

MFC_RequestSyncEvent = {}
local MFC_RequestSyncEvent_mt = Class(MFC_RequestSyncEvent, Event)
InitEventClass(MFC_RequestSyncEvent, "MFC_RequestSyncEvent")

function MFC_RequestSyncEvent.emptyNew() return Event.new(MFC_RequestSyncEvent_mt) end
function MFC_RequestSyncEvent.new() return MFC_RequestSyncEvent.emptyNew() end
function MFC_RequestSyncEvent:writeStream(streamId, connection) end
function MFC_RequestSyncEvent:readStream(streamId, connection) self:run(connection) end
function MFC_RequestSyncEvent:run(connection)
    if connection == nil or connection:getIsServer() then return end
    NET.sendStateTo(connection)
end

MFC_StartRequestEvent = {}
local MFC_StartRequestEvent_mt = Class(MFC_StartRequestEvent, Event)
InitEventClass(MFC_StartRequestEvent, "MFC_StartRequestEvent")

function MFC_StartRequestEvent.emptyNew() return Event.new(MFC_StartRequestEvent_mt) end

function MFC_StartRequestEvent.new(campaign)
    local self = MFC_StartRequestEvent.emptyNew()
    self.campaign = campaign
    return self
end

-- The request carries the full editor state, so it needs the fields the
-- snapshot leaves out (starting economy, income mode).
function MFC_StartRequestEvent:writeStream(streamId, connection)
    NET.writeCampaign(streamId, self.campaign)
    local c = self.campaign
    streamWriteInt32(streamId, math.floor(c.startMoney or -1))
    streamWriteInt32(streamId, math.floor(c.startDebt or -1))
    streamWriteString(streamId, tostring(c.econDifficulty or ""))
    streamWriteString(streamId, tostring(c.incomeMode or "gross"))
end

function MFC_StartRequestEvent:readStream(streamId, connection)
    self.campaign = NET.readCampaign(streamId)
    self.campaign.startMoney = streamReadInt32(streamId)
    self.campaign.startDebt = streamReadInt32(streamId)
    self.campaign.econDifficulty = streamReadString(streamId)
    self.campaign.incomeMode = streamReadString(streamId)
    self:run(connection)
end

function MFC_StartRequestEvent:run(connection)
    if connection == nil or connection:getIsServer() then return end
    local mod = MFC()
    if mod == nil or self.campaign == nil then return end
    if not NET.canConnectionManage(connection) then
        connection:sendEvent(MFC_ActionResultEvent.new(
            "Only a farm manager (or the server admin) can start your farm's challenge."))
        return
    end
    local farmId = NET.getConnectionFarmId(connection)
    if farmId <= 0 then
        connection:sendEvent(MFC_ActionResultEvent.new("You need to be in a farm to start a challenge."))
        return
    end
    -- Always the requester's own farm, whatever the payload claimed.
    self.campaign.farmId = farmId
    mod.startCampaignAuthoritative(self.campaign)
end

MFC_AbandonRequestEvent = {}
local MFC_AbandonRequestEvent_mt = Class(MFC_AbandonRequestEvent, Event)
InitEventClass(MFC_AbandonRequestEvent, "MFC_AbandonRequestEvent")

function MFC_AbandonRequestEvent.emptyNew() return Event.new(MFC_AbandonRequestEvent_mt) end
function MFC_AbandonRequestEvent.new() return MFC_AbandonRequestEvent.emptyNew() end
function MFC_AbandonRequestEvent:writeStream(streamId, connection) end
function MFC_AbandonRequestEvent:readStream(streamId, connection) self:run(connection) end
function MFC_AbandonRequestEvent:run(connection)
    if connection == nil or connection:getIsServer() then return end
    local mod = MFC()
    if mod == nil then return end
    if not NET.canConnectionManage(connection) then
        connection:sendEvent(MFC_ActionResultEvent.new(
            "Only a farm manager (or the server admin) can clear your farm's challenge."))
        return
    end
    local farmId = NET.getConnectionFarmId(connection)
    if farmId <= 0 then return end
    mod.abandonCampaignAuthoritative(farmId)
end

-- ============================================================
-- Message back to one client
-- ============================================================

MFC_ActionResultEvent = {}
local MFC_ActionResultEvent_mt = Class(MFC_ActionResultEvent, Event)
InitEventClass(MFC_ActionResultEvent, "MFC_ActionResultEvent")

function MFC_ActionResultEvent.emptyNew() return Event.new(MFC_ActionResultEvent_mt) end

function MFC_ActionResultEvent.new(message)
    local self = MFC_ActionResultEvent.emptyNew()
    self.message = tostring(message or "")
    return self
end

function MFC_ActionResultEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.message)
end

function MFC_ActionResultEvent:readStream(streamId, connection)
    self.message = streamReadString(streamId)
    self:run(connection)
end

function MFC_ActionResultEvent:run(connection)
    if connection == nil or not connection:getIsServer() then return end
    local mod = MFC()
    if mod ~= nil and self.message ~= "" then mod.notify(self.message) end
end

-- ============================================================
-- Entry points
-- ============================================================

local function makeStateEvent()
    local mod = MFC()
    local entries = {}
    if mod ~= nil then
        for farmId, c in pairs(mod.campaigns or {}) do
            if farmId > 0 then
                local live = mod.buildLiveValues(c)
                table.insert(entries, {
                    campaign = c,
                    challengeYear = c.challengeYear or 1,
                    netWorth = live.netWorth,
                    fields = live.fields,
                    income = live.income,
                })
            end
        end
        -- Stable order so the payload doesn't reshuffle between snapshots.
        table.sort(entries, function(a, b)
            return (a.campaign.farmId or 0) < (b.campaign.farmId or 0)
        end)
    end
    return MFC_StateEvent.new(entries)
end

function NET.sendStateTo(connection)
    if connection == nil then return end
    connection:sendEvent(makeStateEvent())
end

function NET.broadcastState()
    local mod = MFC()
    -- Nothing to broadcast in singleplayer, where the local player is already
    -- looking at the authoritative state.
    if mod == nil or not mod.isMultiplayer() or g_server == nil then return end
    g_server:broadcastEvent(makeStateEvent())
end

function NET.requestSync()
    if g_server ~= nil then return end
    if g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(MFC_RequestSyncEvent.new())
    end
end

function NET.requestStart(campaign)
    local mod = MFC()
    if mod == nil then return false end
    if g_server ~= nil then
        -- Listen-server host: their own farm, same rule as any other player.
        if (campaign.farmId or 0) <= 0 then campaign.farmId = mod.localFarmId() end
        return mod.startCampaignAuthoritative(campaign)
    end
    if g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(MFC_StartRequestEvent.new(campaign))
        return true
    end
    return false
end

function NET.requestAbandon()
    local mod = MFC()
    if mod == nil then return false end
    if g_server ~= nil then
        return mod.abandonCampaignAuthoritative(mod.localFarmId())
    end
    if g_client ~= nil and g_client.getServerConnection ~= nil then
        g_client:getServerConnection():sendEvent(MFC_AbandonRequestEvent.new())
        return true
    end
    return false
end
