--
-- MayflowerFarmChallenge.lua
--
-- Farm Challenge: build a challenge in the Escape menu, play it, and let the
-- mod enforce its rules and judge its goals.
--
-- Each farm runs its own challenge. In singleplayer that is simply your farm.
-- In multiplayer every farm can have a different challenge (or none): a farm
-- manager -- or the server admin -- starts and clears their own farm's run,
-- and everyone on that farm follows its progress. Rules only ever bite the
-- farm that signed up for them.
--
-- On-disk layout, inside this mod's own modSettings folder:
--   modSettings/<modName>/save_<slot>/farm_<id>/challenge.xml  the definition
--   modSettings/<modName>/save_<slot>/farm_<id>/progress.xml   live snapshot
--   modSettings/<modName>/save_<slot>/farm_<id>/history.xml    finished runs
--
-- Design notes:
--  * Every engine hook is wrapped so a renamed or missing API disables one
--    feature and logs a warning, instead of breaking the save.
--  * Hooks install once and re-check the live restriction on every call, so
--    starting or clearing a challenge takes effect without a restart. Each hook
--    resolves the farm it is acting for, so one farm's rules never leak.
--  * Multiplayer is server-authoritative: the server owns the files, judges
--    every farm's run, and broadcasts snapshots. Clients render and request.
--

MayflowerFarmChallenge = {}
local MFC = MayflowerFarmChallenge

MFC.MOD_DIR = g_currentModDirectory
MFC.MOD_NAME = g_currentModName or "FS25_FarmChallenge"
-- FS25 only grants a mod write/delete access to the modSettings directory that
-- matches its actual mod name. Building the path from g_currentModName keeps it
-- valid if the package is renamed and avoids "No access to folder" errors.
MFC.SETTINGS_DIR = getUserProfileAppPath() .. "modSettings/" .. MFC.MOD_NAME .. "/"
-- Where challenges lived before the folder was renamed to match the mod name.
-- Read-only: used once per save to copy old data forward.
MFC.LEGACY_DIR = getUserProfileAppPath() .. "modSettings/MayflowerFarmChallenge/"

-- The highest farm id probed when looking for saved challenges, used only if
-- the farm list isn't readable at map-load time.
local MAX_FARM_ID = 16

-- [farmId] = challenge table. The authority holds every farm's run; a client
-- holds whatever the server sent it.
MFC.campaigns = {}
-- A convenience view of the local player's own farm, kept in step by
-- refreshLocalCampaign(). The menu page and the HUD only ever want this one.
MFC.campaign = nil

MFC.lastDayWritten = -1

-- Diagnostic logging. Off for release builds so a normal session leaves
-- log.txt completely clean; set to true to trace loading, save setup and the
-- challenge lifecycle while troubleshooting. The companion scripts read the
-- same flag.
MFC.DEBUG = false

local function log(msg)
    if not MFC.DEBUG then return end
    print(string.format("[FarmChallenge] %s", msg))
end

local function guard(label, fn, fallback)
    local ok, result = pcall(fn)
    if not ok then
        log(string.format("WARN: '%s' failed (%s). That feature is disabled.", label, tostring(result)))
        return fallback
    end
    return result
end

MFC.log = log

-- ============================================================
-- Roles and farms
-- ============================================================

function MFC.isMultiplayer()
    local dyn = g_currentMission and g_currentMission.missionDynamicInfo
    return dyn ~= nil and dyn.isMultiplayer == true
end

function MFC.isServer()
    if g_server ~= nil then return true end
    if g_currentMission ~= nil and g_currentMission.getIsServer ~= nil then
        return g_currentMission:getIsServer()
    end
    return not MFC.isMultiplayer()
end

function MFC.isClient()
    if g_client ~= nil then return true end
    if g_currentMission ~= nil and g_currentMission.getIsClient ~= nil then
        return g_currentMission:getIsClient()
    end
    return true
end

-- True when this machine may write files and judge challenges.
local function isAuthority()
    return not MFC.isMultiplayer() or MFC.isServer()
end
MFC.isAuthority = isAuthority

-- The farm this player belongs to. 0 means none (a spectator, or a dedicated
-- server, which has no local player at all).
function MFC.localFarmId()
    if g_currentMission == nil then return 0 end
    local farmId = nil
    if g_currentMission.getFarmId ~= nil then
        local ok, value = pcall(function() return g_currentMission:getFarmId() end)
        if ok then farmId = value end
    end
    if (farmId == nil or farmId <= 0) and g_farmManager ~= nil
        and g_farmManager.getFarmByUserId ~= nil and g_currentMission.playerUserId ~= nil then
        local ok, farm = pcall(function()
            return g_farmManager:getFarmByUserId(g_currentMission.playerUserId)
        end)
        if ok and farm ~= nil then farmId = farm.farmId end
    end
    if farmId == nil or farmId <= 0 then return 0 end
    return farmId
end

-- Every farm id that currently exists, so per-farm work doesn't have to guess.
local function allFarmIds()
    return guard("allFarmIds", function()
        local ids = {}
        local farms = g_farmManager ~= nil and g_farmManager.farms or nil
        if type(farms) == "table" then
            for _, farm in pairs(farms) do
                local id = type(farm) == "table" and farm.farmId or nil
                -- Farm 0 is the spectator farm and never owns anything.
                if type(id) == "number" and id > 0 then table.insert(ids, id) end
            end
        end
        if #ids == 0 then
            for id = 1, MAX_FARM_ID do table.insert(ids, id) end
        end
        table.sort(ids)
        return ids
    end, { 1 })
end

function MFC.getCampaign(farmId)
    if farmId == nil or farmId <= 0 then return nil end
    return MFC.campaigns[farmId]
end

-- Point MFC.campaign at whatever the local player's farm is running. Farm
-- membership can change mid-session, so this is re-checked on a timer too.
function MFC.refreshLocalCampaign()
    MFC.campaign = MFC.getCampaign(MFC.localFarmId())
    return MFC.campaign
end

-- ============================================================
-- The calendar
--
-- An FS25 year is 12 periods of `daysPerPeriod` days, NOT 365 days. Deriving
-- the year from a 365-day calendar leaves the clock stuck on year 1 forever,
-- so time limits never expire. Everything below is anchored on the absolute
-- day counter and converted with the save's real season length, which also
-- gives quarter deadlines the precision they need.
-- ============================================================

local function environment()
    return g_currentMission and g_currentMission.environment or nil
end

local function absoluteDay()
    return guard("absoluteDay", function()
        local env = environment()
        return math.max(1, math.floor((env and env.currentDay) or 1))
    end, 1)
end

local function daysPerYear()
    return guard("daysPerYear", function()
        local env = environment()
        local perPeriod = (env and env.daysPerPeriod) or 1
        return math.max(1, math.floor(perPeriod)) * 12
    end, 12)
end

-- Calendar year/quarter, for the progress snapshot and display only.
local function getGameDate()
    local year = guard("getGameYear", function()
        local env = environment()
        if env ~= nil and type(env.currentYear) == "number" then
            return math.max(1, math.floor(env.currentYear))
        end
        return math.floor((absoluteDay() - 1) / daysPerYear()) + 1
    end, 1)
    local quarter = guard("getGameQuarter", function()
        local env = environment()
        local period = (env and env.currentPeriod) or 1
        return math.max(1, math.min(4, math.ceil(period / 3)))
    end, 1)
    return year, quarter
end

-- A milestone's deadline in elapsed challenge years, so "year 2, quarter 3"
-- becomes 1.75. Quarter defaults to 4 (the end of that year).
local function milestoneDeadline(m)
    local dueYear = math.max(1, tonumber(m.dueYear) or 1)
    local dueQuarter = math.max(1, math.min(4, tonumber(m.dueQuarter) or 4))
    return (dueYear - 1) + (dueQuarter / 4)
end

-- ============================================================
-- Restriction lookup
--
-- Every rule is scoped to the farm that signed up for it. A hook that knows
-- which farm it is acting for passes that id; anything acting on the player in
-- front of the screen (map actions, shop screens) leaves it nil and gets the
-- local farm.
-- ============================================================

local function isRestricted(id, farmId)
    if farmId == nil then farmId = MFC.localFarmId() end
    local c = MFC.getCampaign(farmId)
    return c ~= nil and (c.state or "active") == "active" and c.restrictions[id] == true
end

function MFC.isRestrictedPublic(id, farmId)
    return isRestricted(id, farmId)
end

-- ============================================================
-- Paths
-- ============================================================

local function savegameIndex()
    local info = g_currentMission and g_currentMission.missionInfo
    return tostring((info and info.savegameIndex) or "unknown")
end

function MFC.saveDir()
    return string.format("%ssave_%s/", MFC.SETTINGS_DIR, savegameIndex())
end

function MFC.farmDir(farmId)
    return string.format("%sfarm_%d/", MFC.saveDir(), farmId or 0)
end

function MFC.challengeFile(farmId) return MFC.farmDir(farmId) .. "challenge.xml" end
function MFC.progressFile(farmId) return MFC.farmDir(farmId) .. "progress.xml" end
function MFC.historyFile(farmId) return MFC.farmDir(farmId) .. "history.xml" end

local function ensureFarmDir(farmId)
    createFolder(MFC.SETTINGS_DIR)
    createFolder(MFC.saveDir())
    createFolder(MFC.farmDir(farmId))
end

-- ============================================================
-- Loading and saving a challenge
-- ============================================================

local function loadCampaignFile(path, farmId)
    if not fileExists(path) then return nil end

    local xml = XMLFile.load("MFCChallenge", path)
    if xml == nil then
        log("Could not open " .. path)
        return nil
    end
    if xml:getBool("challenge#abandoned") == true then
        xml:delete()
        return nil
    end

    local c = {}
    c.seed = xml:getInt("challenge#seed") or 0
    c.name = xml:getString("challenge#name") or "Challenge"
    c.state = xml:getString("challenge#state") or "active"
    c.celebrated = xml:getBool("challenge#celebrated") == true
    -- Whether the starting economy has already been applied to this farm. This
    -- replaces the old flag files, which piled up one per run.
    c.setupDone = xml:getBool("challenge#setupDone") == true
    c.endYearsUsed = xml:getInt("challenge#endYearsUsed")
    c.endGoalValue = xml:getFloat("challenge#endGoalValue")
    c.startDay = xml:getInt("challenge#startDay")
    c.farmId = xml:getInt("challenge#farmId") or farmId or 0
    c.repNetWorth = xml:getFloat("challenge#repNetWorth")
    c.repFields = xml:getInt("challenge#repFields")
    c.baselineNetWorth = xml:getFloat("challenge.baseline#netWorth")
    c.baselineFields = xml:getInt("challenge.baseline#ownedFields")
    c.baselineMoney = xml:getFloat("challenge.baseline#money")
    c.baselineCaptured = xml:getBool("challenge.baseline#captured") == true
    -- Challenges written before explicit baselines carried the same numbers
    -- under repNetWorth/repFields.
    if c.baselineNetWorth == nil then c.baselineNetWorth = c.repNetWorth end
    if c.baselineFields == nil then c.baselineFields = c.repFields end
    if c.baselineNetWorth ~= nil and c.baselineFields ~= nil then
        c.baselineCaptured = true
    end
    -- A challenge written before setupDone existed (or carried over from an
    -- older layout) is already configured if its starting snapshot was taken:
    -- baselines are captured the instant the starting economy lands. Without
    -- this, re-loading such a save would re-apply the starting cash and debt
    -- and wipe out real progress.
    if c.setupDone ~= true and c.baselineCaptured == true then c.setupDone = true end

    c.difficulty = xml:getString("challenge#difficulty") or ""
    c.years = xml:getInt("challenge.economy#years") or 0
    -- -1 means "leave this untouched" (the default). A value >= 0 is an
    -- explicit amount the player opted into.
    c.startMoney = xml:getInt("challenge.economy#startMoney") or -1
    c.startDebt = xml:getInt("challenge.economy#startDebt") or -1
    c.maxLoan = xml:getInt("challenge.economy#maxLoan") or -1
    c.econDifficulty = xml:getString("challenge.economy#econDifficulty") or ""
    -- How "Money earned" is measured: "gross" = income received since the run
    -- began (spending doesn't reduce it); "net" = current cash minus the
    -- balance captured at the start.
    c.incomeMode = xml:getString("challenge.economy#incomeMode") or "gross"

    c.restrictions = {}
    local i = 0
    while true do
        local key = string.format("challenge.restrictions.restriction(%d)", i)
        if not xml:hasProperty(key) then break end
        local id = xml:getString(key .. "#id")
        if id ~= nil and id ~= "" then c.restrictions[id] = true end
        i = i + 1
    end

    c.milestones = {}
    i = 0
    while true do
        local key = string.format("challenge.milestones.milestone(%d)", i)
        if not xml:hasProperty(key) then break end
        table.insert(c.milestones, {
            order = xml:getInt(key .. "#order") or (i + 1),
            kind = xml:getString(key .. "#kind") or "NetWorth",
            metric = xml:getString(key .. "#metric"),
            target = xml:getFloat(key .. "#target") or 0,
            title = xml:getString(key .. "#title") or "",
            dueYear = xml:getInt(key .. "#dueYear") or 1,
            dueQuarter = xml:getInt(key .. "#dueQuarter") or 4,
            completed = false,
            missed = false,
        })
        i = i + 1
    end

    xml:delete()

    -- Runtime-only fields, never serialised.
    c.income = 0
    c.challengeYear = 1
    c.elapsedYears = 0
    c.setupPending = (c.setupDone ~= true)
    c.live = nil

    log(string.format("Farm %d: loaded '%s' (seed %d, %d milestones).",
        c.farmId, c.name, c.seed, #c.milestones))
    return c
end

function MFC.writeCampaign(c)
    if c == nil or not isAuthority() then return false end
    local farmId = c.farmId or 0
    if farmId <= 0 then return false end
    return guard("writeCampaign", function()
        ensureFarmDir(farmId)
        local xml = XMLFile.create("MFCChallengeW", MFC.challengeFile(farmId), "challenge")
        if xml == nil then
            log("WARN: could not create challenge.xml for farm " .. farmId)
            return false
        end
        xml:setInt("challenge#seed", c.seed or 0)
        xml:setString("challenge#name", c.name or "Challenge")
        xml:setString("challenge#state", c.state or "active")
        xml:setBool("challenge#celebrated", c.celebrated == true)
        xml:setBool("challenge#setupDone", c.setupDone == true)
        xml:setString("challenge#difficulty", c.difficulty or "")
        xml:setInt("challenge#farmId", farmId)
        if c.startDay ~= nil then xml:setInt("challenge#startDay", c.startDay) end
        if c.endYearsUsed ~= nil then xml:setInt("challenge#endYearsUsed", c.endYearsUsed) end
        if c.endGoalValue ~= nil then xml:setFloat("challenge#endGoalValue", c.endGoalValue) end
        if c.repNetWorth ~= nil then xml:setFloat("challenge#repNetWorth", c.repNetWorth) end
        if c.repFields ~= nil then xml:setInt("challenge#repFields", c.repFields) end
        if c.baselineNetWorth ~= nil then xml:setFloat("challenge.baseline#netWorth", c.baselineNetWorth) end
        if c.baselineFields ~= nil then xml:setInt("challenge.baseline#ownedFields", c.baselineFields) end
        if c.baselineMoney ~= nil then xml:setFloat("challenge.baseline#money", c.baselineMoney) end
        xml:setBool("challenge.baseline#captured", c.baselineCaptured == true)

        xml:setInt("challenge.economy#years", c.years or 0)
        xml:setInt("challenge.economy#startMoney", c.startMoney or -1)
        xml:setInt("challenge.economy#startDebt", c.startDebt or -1)
        xml:setInt("challenge.economy#maxLoan", c.maxLoan or -1)
        xml:setString("challenge.economy#econDifficulty", c.econDifficulty or "")
        xml:setString("challenge.economy#incomeMode", c.incomeMode or "gross")

        local ri = 0
        for id in pairs(c.restrictions or {}) do
            xml:setString(string.format("challenge.restrictions.restriction(%d)#id", ri), id)
            ri = ri + 1
        end

        for mi, m in ipairs(c.milestones or {}) do
            local k = string.format("challenge.milestones.milestone(%d)", mi - 1)
            xml:setInt(k .. "#order", m.order or mi)
            xml:setString(k .. "#kind", m.kind or "NetWorth")
            if m.metric ~= nil then xml:setString(k .. "#metric", m.metric) end
            xml:setFloat(k .. "#target", m.target or 0)
            xml:setString(k .. "#title", m.title or "")
            xml:setInt(k .. "#dueYear", m.dueYear or 1)
            xml:setInt(k .. "#dueQuarter", m.dueQuarter or 4)
        end

        xml:save()
        xml:delete()
        return true
    end, false)
end

-- ============================================================
-- Reading live farm state
-- ============================================================

local function getFarm(farmId)
    if g_currentMission == nil or g_farmManager == nil then return nil end
    farmId = farmId or MFC.localFarmId()
    if farmId <= 0 or g_farmManager.getFarmById == nil then return nil end
    return g_farmManager:getFarmById(farmId)
end

local function getMoney(farmId)
    return guard("getMoney", function()
        local farm = getFarm(farmId)
        if farm == nil then return 0 end
        if farm.getBalance ~= nil then return farm:getBalance() or 0 end
        return farm.money or 0
    end, 0)
end

local function getLoan(farmId)
    return guard("getLoan", function()
        local farm = getFarm(farmId)
        if farm == nil then return 0 end
        if farm.getLoan ~= nil then
            local ok, value = pcall(function() return farm:getLoan() end)
            if ok and type(value) == "number" then return value end
        end
        return farm.loan or 0
    end, 0)
end

-- Net worth = cash + asset equity - loan. Farm:getEquity() counts owned land
-- and placeables only (no cash), which is why it reads 0 on a fresh farm.
local function getNetWorth(farmId)
    return guard("getNetWorth", function()
        local farm = getFarm(farmId)
        if farm == nil then return 0 end
        local assets = 0
        if farm.getEquity ~= nil then
            local ok, v = pcall(function() return farm:getEquity() end)
            if ok and type(v) == "number" then assets = v end
        end
        return getMoney(farmId) + assets - getLoan(farmId)
    end, 0)
end

local function getOwnedFields(farmId)
    return guard("getOwnedFields", function()
        farmId = farmId or MFC.localFarmId()
        if farmId <= 0 or g_farmlandManager == nil then return 0 end
        local owned = g_farmlandManager:getOwnedFarmlandIdsByFarmId(farmId)
        if owned == nil then return 0 end
        local count = 0
        for _ in pairs(owned) do count = count + 1 end
        return count
    end, 0)
end

-- A multiplayer client can't read another farm's books, and its own farm's
-- equity isn't fully replicated either, so displayed numbers come from the
-- server's snapshot whenever one is available.
local function liveValue(c, key, localFn)
    if c ~= nil and c.live ~= nil and not isAuthority() then
        return c.live[key] or 0
    end
    return localFn()
end

function MFC.getNetWorthPublic()
    local c = MFC.campaign
    return liveValue(c, "netWorth", function() return getNetWorth(MFC.localFarmId()) end)
end

function MFC.getOwnedFieldsPublic()
    local c = MFC.campaign
    return liveValue(c, "fields", function() return getOwnedFields(MFC.localFarmId()) end)
end

function MFC.getMoneyPublic() return getMoney(MFC.localFarmId()) end
function MFC.getLoanPublic() return getLoan(MFC.localFarmId()) end

-- Value a metric will have the moment a new challenge becomes active on this
-- player's farm. Existing assets and land count; the chosen starting cash and
-- debt are applied. Starting cash is deliberately not treated as earned income.
function MFC.getProjectedStartMetricPublic(metric, startMoney, startDebt)
    local farmId = MFC.localFarmId()
    if metric == "Income" then return 0 end
    if metric == "OwnFields" then return getOwnedFields(farmId) end

    local currentNetWorth = getNetWorth(farmId)
    local currentMoney = getMoney(farmId)
    local currentLoan = getLoan(farmId)
    local targetMoney = tonumber(startMoney) or currentMoney
    local targetDebt = tonumber(startDebt) or currentLoan
    local assetEquity = currentNetWorth - currentMoney + currentLoan
    return assetEquity + targetMoney - targetDebt
end

-- ============================================================
-- Income tracking
-- ============================================================

-- Money types that are not "earned". Borrowed cash and liquidated assets move
-- money into the account without the farm having produced anything, so an
-- Income goal could otherwise be cleared by taking a loan or selling a tractor.
-- Names absent from this game version are skipped rather than erroring.
local EXCLUDED_MONEY_TYPE_NAMES = {
    "LOAN", "LOAN_INTEREST",
    "SHOP_VEHICLE_SELL", "SOLD_VEHICLE",
    "SHOP_PROPERTY_SELL", "SOLD_PROPERTY",
    "FIELD_SELL", "SOLD_FARMLAND",
}

local excludedMoneyTypes = nil
local function isExcludedMoneyType(moneyType)
    if moneyType == nil then return false end
    if excludedMoneyTypes == nil then
        excludedMoneyTypes = {}
        if MoneyType ~= nil then
            local resolved = {}
            for _, name in ipairs(EXCLUDED_MONEY_TYPE_NAMES) do
                local value = MoneyType[name]
                if value ~= nil then
                    excludedMoneyTypes[value] = true
                    table.insert(resolved, name)
                end
            end
            log("Income excludes money types: " .. table.concat(resolved, ", "))
        end
    end
    return excludedMoneyTypes[moneyType] == true
end

-- The live "Money earned" figure for one farm, honouring its chosen mode.
function MFC.incomeValue(farmId)
    local c = MFC.getCampaign(farmId or MFC.localFarmId())
    if c == nil then return 0 end
    if c.live ~= nil and not isAuthority() then return c.live.income or 0 end
    if c.incomeMode == "net" then
        -- Until the starting balance is captured there is no gain yet; report 0
        -- rather than the whole current balance.
        if c.baselineMoney == nil then return 0 end
        return getMoney(c.farmId) - c.baselineMoney
    end
    return c.income or 0
end

function MFC.getIncomePublic() return MFC.incomeValue(MFC.localFarmId()) end

local function installIncomeTracker()
    if MFC.incomeHookInstalled then return end
    guard("installIncomeTracker", function()
        if FSBaseMission == nil or FSBaseMission.addMoney == nil then
            log("WARN: FSBaseMission.addMoney not found; income goals inactive.")
            return
        end
        -- Signature: FSBaseMission:addMoney(amount, farmId, moneyType, ...)
        FSBaseMission.addMoney = Utils.appendedFunction(FSBaseMission.addMoney,
            function(mission, amount, farmId, moneyType, ...)
                pcall(function()
                    if not isAuthority() then return end
                    if type(amount) ~= "number" or amount <= 0 then return end
                    -- Money with no farm attached can't be credited to anyone.
                    if farmId == nil then return end
                    local c = MFC.getCampaign(farmId)
                    if c == nil or (c.state or "active") ~= "active" then return end
                    -- Starting-money adjustments happen while save setup is
                    -- pending and must never count as income earned in the run.
                    if c.setupPending then return end
                    if isExcludedMoneyType(moneyType) then return end
                    c.income = (c.income or 0) + amount
                end)
            end)
        MFC.incomeHookInstalled = true
        log("Income tracker installed.")
    end)
end

-- Capture a starting snapshot for the end-of-run report. Conditions themselves
-- use absolute farm values, so everything already owned counts.
function MFC.captureBaselines(c)
    if c == nil or c.baselineCaptured == true then return end
    c.baselineNetWorth = getNetWorth(c.farmId)
    c.baselineFields = getOwnedFields(c.farmId)
    c.baselineMoney = getMoney(c.farmId)
    c.baselineCaptured = true
    c.repNetWorth = c.baselineNetWorth
    c.repFields = c.baselineFields
    MFC.writeCampaign(c)
    log(string.format("Farm %d starting snapshot: net worth %.0f, fields %d.",
        c.farmId or 0, c.baselineNetWorth or 0, c.baselineFields or 0))
end

-- ============================================================
-- Restriction enforcement
-- ============================================================

function MFC.notify(msg)
    guard("notify", function()
        if g_currentMission ~= nil and g_currentMission.addIngameNotification ~= nil then
            g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, msg)
        end
    end)
end

-- Tell just the players on one farm. On a dedicated server this is a no-op
-- locally; the message reaches them through the state snapshot instead.
local function notifyFarm(farmId, msg)
    if farmId ~= nil and farmId == MFC.localFarmId() then MFC.notify(msg) end
end

local function installWorkerBlock()
    if MFC.workerHookInstalled then return end
    guard("installWorkerBlock", function()
        if g_currentMission == nil or g_currentMission.aiSystem == nil
            or g_currentMission.aiSystem.startJob == nil then
            log("WARN: aiSystem.startJob not found; worker block inactive.")
            return
        end
        g_currentMission.aiSystem.startJob = Utils.overwrittenFunction(
            g_currentMission.aiSystem.startJob,
            function(self, superFunc, ...)
                local job = ({ ... })[1]
                local farmId = job and (job.farmId or job.ownerFarmId) or nil
                if farmId == nil and job ~= nil and job.vehicle ~= nil
                    and job.vehicle.getOwnerFarmId ~= nil then
                    pcall(function() farmId = job.vehicle:getOwnerFarmId() end)
                end
                if isRestricted("noWorkers", farmId) then
                    notifyFarm(farmId or MFC.localFarmId(),
                        "Workers are disabled for your farm's challenge.")
                    return nil
                end
                return superFunc(self, ...)
            end)
        MFC.workerHookInstalled = true
        log("Worker hook installed.")
    end)
end

-- Contract machines: override AbstractFieldMission.hasLeasableVehicles so
-- contracts stay available but that farm must bring its own equipment.
local function installContractMachineBlock()
    if MFC.contractMachineHookInstalled then return end
    guard("installContractMachineBlock", function()
        if AbstractFieldMission == nil or AbstractFieldMission.hasLeasableVehicles == nil then
            log("WARN: AbstractFieldMission.hasLeasableVehicles not found; contract-machine block inactive.")
            return
        end
        AbstractFieldMission.hasLeasableVehicles = Utils.overwrittenFunction(
            AbstractFieldMission.hasLeasableVehicles,
            function(self, superFunc, ...)
                local farmId = self and (self.farmId or self.ownerFarmId) or nil
                if isRestricted("noContractMachines", farmId) then return false end
                return superFunc(self, ...)
            end)
        MFC.contractMachineHookInstalled = true
        log("Contract-machine hook installed.")
    end)
end

-- Loan rules.
--
-- Farm.MIN_LOAN / Farm.MAX_LOAN are class-wide, not per farm, so they can only
-- ever express one farm's rule at a time. They are therefore driven by the
-- LOCAL player's farm: on every client (and on a listen-server host) the
-- borrowing limit matches the challenge that player actually signed up for. A
-- dedicated server has no local farm and leaves the stock limits alone.
local function applyLoanRules()
    guard("applyLoanRules", function()
        if Farm == nil then
            log("WARN: Farm class not found; loan rules inactive.")
            return
        end
        if MFC.origMinLoan == nil then
            MFC.origMinLoan = Farm.MIN_LOAN or 0
            MFC.origMaxLoan = Farm.MAX_LOAN or 0
        end
        if isRestricted("noLoans") then
            Farm.MIN_LOAN = 0
            Farm.MAX_LOAN = 0
            return
        end
        Farm.MIN_LOAN = MFC.origMinLoan
        local c = MFC.campaign
        local cap = (c ~= nil and (c.state or "active") == "active") and tonumber(c.maxLoan) or nil
        if cap ~= nil and cap >= 0 then
            Farm.MAX_LOAN = math.min(cap, MFC.origMaxLoan)
        else
            Farm.MAX_LOAN = MFC.origMaxLoan
        end
    end)
end

-- Steering assist / GPS. AIAutomaticSteering.getIsAutomaticSteeringAllowed is
-- the gate the game itself queries, and it is a vehicle specialization -- so
-- the vehicle's owner decides whose rule applies. Other GPS mods chain the same
-- function and only ever force false, so these compose in either load order.
local function installSteeringAssistBlock()
    if MFC.steeringHookInstalled then return end
    guard("installSteeringAssistBlock", function()
        if AIAutomaticSteering == nil or AIAutomaticSteering.getIsAutomaticSteeringAllowed == nil then
            log("WARN: AIAutomaticSteering.getIsAutomaticSteeringAllowed not found; GPS block inactive.")
            return
        end
        AIAutomaticSteering.getIsAutomaticSteeringAllowed = Utils.overwrittenFunction(
            AIAutomaticSteering.getIsAutomaticSteeringAllowed,
            function(vehicle, superFunc, ...)
                local allowed = superFunc(vehicle, ...)
                if allowed ~= true then return allowed end
                -- Falls back to the local farm if the owner can't be read.
                local farmId = nil
                if type(vehicle) == "table" and vehicle.getOwnerFarmId ~= nil then
                    pcall(function() farmId = vehicle:getOwnerFarmId() end)
                end
                if isRestricted("manualOnly", farmId) then return false end
                return allowed
            end)
        MFC.steeringHookInstalled = true
        log("Steering-assist hook installed.")
    end)
end

-- Apply restriction state. The class-level hooks install once and self-gate per
-- farm; only the two pieces of global state below track the local player.
function MFC.applyRestrictions()
    installWorkerBlock()
    installContractMachineBlock()
    installSteeringAssistBlock()
    installIncomeTracker()
    applyLoanRules()
    guard("teleportToggleState", function()
        if g_currentMission ~= nil then
            g_currentMission.isToggleVehicleAllowed = not isRestricted("noTeleport")
        end
    end)
end

-- ============================================================
-- Leasing enforcement
--
-- The shop's lease button is removed outright (see the ShopConfigScreen hook at
-- the bottom of this file). This sweep only catches leases that predate the
-- challenge. It returns them through the game's own sell path and pays nothing:
-- an earlier build refunded the full retail price, which turned every lease
-- into a money faucet.
-- ============================================================

-- A stable per-vehicle key. Table addresses get reused after collection, so
-- keying the "already checked" set on tostring(v) could let a new vehicle
-- inherit an old entry and skip the check.
local function vehicleKey(v)
    if v.uniqueId ~= nil then return "u" .. tostring(v.uniqueId) end
    if v.rootNode ~= nil then return "n" .. tostring(v.rootNode) end
    return tostring(v)
end

MFC.checkedVehicles = MFC.checkedVehicles or {}

function MFC.resetVehicleScan()
    MFC.checkedVehicles = {}
end

local function anyFarmBlocksLeasing()
    for _, c in pairs(MFC.campaigns) do
        if (c.state or "active") == "active" and c.restrictions.noLeasing == true then
            return true
        end
    end
    return false
end

local function scanLeasedVehicles()
    if not anyFarmBlocksLeasing() then return end
    guard("scanLeasedVehicles", function()
        local vehicleSystem = g_currentMission and g_currentMission.vehicleSystem
        local list = vehicleSystem and vehicleSystem.vehicles
        if type(list) ~= "table" then return end

        for _, v in pairs(list) do
            if type(v) == "table" and v.getOwnerFarmId ~= nil then
                local key = vehicleKey(v)
                if not MFC.checkedVehicles[key] then
                    local ok, owner = pcall(function() return v:getOwnerFarmId() end)
                    if ok and owner ~= nil and isRestricted("noLeasing", owner) then
                        -- Mark it handled first, unconditionally. If removal
                        -- fails we must not retry every frame.
                        MFC.checkedVehicles[key] = true
                        -- Contract equipment belongs to the mission, not the
                        -- farm's leasing decisions; "no contract machines" is
                        -- the rule that governs it.
                        local isLeased = false
                        if v.activeMissionId == nil and v.getPropertyState ~= nil then
                            local ok2, state = pcall(function() return v:getPropertyState() end)
                            isLeased = ok2 and state == VehiclePropertyState.LEASED
                        end
                        if isLeased then
                            notifyFarm(owner,
                                "Leasing is disabled for your farm's challenge; the lease was returned.")
                            guard("returnLease", function()
                                -- sellVehicle is the game's own return path and
                                -- settles the lease correctly. Never hand back
                                -- money here.
                                if g_currentMission.sellVehicle ~= nil then
                                    g_currentMission:sellVehicle(v)
                                elseif v.delete ~= nil then
                                    v:delete()
                                end
                            end)
                        end
                    elseif ok then
                        MFC.checkedVehicles[key] = true
                    end
                end
            end
        end
    end)
end

-- ============================================================
-- Fast-travel enforcement
--
-- These gate an action the player in front of the screen is taking, so they
-- resolve against the local farm. Installed once at load time (they must be
-- hooked before any hotspot exists) and self-gated on the live restriction.
-- ============================================================

local function installTeleportClassHooks()
    if MFC.teleportHooksInstalled then return end
    guard("installTeleportClassHooks", function()
        local function deny(self, superFunc, ...)
            if isRestricted("noTeleport") then return false end
            return superFunc(self, ...)
        end

        for _, class in ipairs({ PlaceableHotspot, NPCHotspot, FerryHotspot }) do
            if class ~= nil and class.getBeVisited ~= nil then
                class.getBeVisited = Utils.overwrittenFunction(class.getBeVisited, deny)
            end
        end
        if Enterable ~= nil and Enterable.getIsEnterableFromMenu ~= nil then
            Enterable.getIsEnterableFromMenu = Utils.overwrittenFunction(
                Enterable.getIsEnterableFromMenu, deny)
        end

        if InGameMenuMapFrame ~= nil and InGameMenuMapFrame.setMapInputContext ~= nil
            and InGameMenuMapFrame.ACTIONS ~= nil and InGameMenuMapFrame.ACTIONS.VISIT_PLACE ~= nil then
            InGameMenuMapFrame.setMapInputContext = Utils.appendedFunction(
                InGameMenuMapFrame.setMapInputContext,
                function(mapFrame)
                    if isRestricted("noTeleport") and mapFrame.contextActions ~= nil then
                        local action = mapFrame.contextActions[InGameMenuMapFrame.ACTIONS.VISIT_PLACE]
                        if action ~= nil then
                            action.isActive = false
                            if mapFrame.updateContextInputBarVisibility ~= nil then
                                mapFrame:updateContextInputBarVisibility()
                            end
                        end
                    end
                end)
        end

        MFC.teleportHooksInstalled = true
        log("Teleport hooks installed.")
    end)
end

-- ============================================================
-- Judging
-- ============================================================

function MFC.getChallengeMetricPublic(metric)
    if MFC.campaign == nil then return 0 end
    if metric == "Income" then return MFC.getIncomePublic() end
    if metric == "OwnFields" then return MFC.getOwnedFieldsPublic() end
    return MFC.getNetWorthPublic()
end

function MFC.getChallengeYearPublic()
    return (MFC.campaign and MFC.campaign.challengeYear) or 1
end

local function checkMilestones(c, netWorth, fields, income)
    for _, m in ipairs(c.milestones) do
        if not m.completed then
            local metric = m.metric or m.kind
            local current = netWorth
            if metric == "OwnFields" then current = fields
            elseif metric == "Income" then current = income end
            if current >= (m.target or 0) then
                m.completed = true
                MFC.networkDirty = true
                notifyFarm(c.farmId, string.format("Milestone complete: %s", m.title or ""))
                log(string.format("Farm %d milestone %d complete: %s",
                    c.farmId or 0, m.order or 0, m.title or ""))
            end
        end
    end
end

-- Judge one farm's run: milestone completion, missed markers, win/fail.
local function evaluateOne(c)
    -- Never judge until save setup has applied the configured starting economy.
    -- The editor guarantees every target sits above the value the farm will
    -- have at that point.
    if c.setupPending then return end
    if c.baselineCaptured ~= true then MFC.captureBaselines(c) end

    local farmId = c.farmId
    local netWorth = math.max(0, getNetWorth(farmId))
    local fields = math.max(0, getOwnedFields(farmId))
    local income = MFC.incomeValue(farmId)

    -- Anchor the clock the first time this run is seen in a live game.
    if c.startDay == nil then
        c.startDay = absoluteDay()
        MFC.writeCampaign(c)
    end
    c.elapsedYears = math.max(0, (absoluteDay() - c.startDay) / daysPerYear())
    c.challengeYear = math.floor(c.elapsedYears) + 1

    checkMilestones(c, netWorth, fields, income)

    if (c.state or "active") ~= "active" then return end

    -- Missed markers are display-only and only move while the run is live.
    for _, m in ipairs(c.milestones) do
        m.missed = (not m.completed) and (c.elapsedYears > milestoneDeadline(m))
    end

    local finalDone, goalMetric = false, "NetWorth"
    for _, m in ipairs(c.milestones) do
        if m.kind == "FinalGoal" then
            goalMetric = m.metric or "NetWorth"
            if m.completed then finalDone = true end
        end
    end
    local goalValueNow = netWorth
    if goalMetric == "OwnFields" then goalValueNow = fields
    elseif goalMetric == "Income" then goalValueNow = income end

    if finalDone then
        c.state = "won"
    elseif c.elapsedYears >= (c.years or 1) then
        c.state = "failed"
    else
        return
    end

    c.celebrated = false
    c.endYearsUsed = c.challengeYear
    c.endGoalValue = goalValueNow
    MFC.networkDirty = true
    MFC.writeCampaign(c)
    MFC.appendHistory(c, c.state)
    MFC.applyRestrictions() -- a finished run stops enforcing
    log(string.format("Farm %d challenge %s: %s (year %d of %d).",
        farmId or 0, c.state, c.name or "?", c.challengeYear, c.years or 0))
end

-- Judge every farm. Runs once a second so a win lands the moment a target is
-- crossed; persistence stays on the slower writeProgress cadence.
function MFC.evaluateChallenges()
    if not isAuthority() then return end
    for _, c in pairs(MFC.campaigns) do
        guard("evaluateChallenge", function() evaluateOne(c) end)
    end
end

local function writeProgressFor(c)
    if c.setupPending then return end
    local farmId = c.farmId
    local year, quarter = getGameDate()

    ensureFarmDir(farmId)
    local xml = XMLFile.create("MFCProgress", MFC.progressFile(farmId), "progress")
    if xml == nil then return end
    xml:setInt("progress#seed", c.seed or 0)
    xml:setInt("progress#farmId", farmId or 0)
    xml:setFloat("progress#netWorth", getNetWorth(farmId))
    xml:setFloat("progress#money", getMoney(farmId))
    xml:setInt("progress#ownedFields", getOwnedFields(farmId))
    xml:setFloat("progress#earnedIncome", c.income or 0)
    if c.baselineNetWorth ~= nil then xml:setFloat("progress#baselineNetWorth", c.baselineNetWorth) end
    if c.baselineFields ~= nil then xml:setInt("progress#baselineFields", c.baselineFields) end
    xml:setInt("progress#year", year)
    xml:setInt("progress#quarter", quarter)
    xml:setInt("progress#challengeYear", c.challengeYear or 1)

    local idx = 0
    for _, m in ipairs(c.milestones) do
        if m.completed then
            xml:setInt(string.format("progress.completed.milestone(%d)#order", idx), m.order or 0)
            idx = idx + 1
        end
    end
    xml:save()
    xml:delete()
end

function MFC.writeProgress()
    if not isAuthority() then return end
    MFC.evaluateChallenges()
    for _, c in pairs(MFC.campaigns) do
        guard("writeProgress", function() writeProgressFor(c) end)
    end
end

-- Restore earned income and completed milestones from a previous session.
local function readProgressFor(c)
    guard("readProgress", function()
        local path = MFC.progressFile(c.farmId)
        if not fileExists(path) then return end
        local xml = XMLFile.load("MFCProgressR", path)
        if xml == nil then return end
        if (xml:getInt("progress#seed") or -1) == (c.seed or 0) then
            c.income = xml:getFloat("progress#earnedIncome") or 0
            c.challengeYear = xml:getInt("progress#challengeYear") or 1
            local done = {}
            local idx = 0
            while true do
                local key = string.format("progress.completed.milestone(%d)", idx)
                if not xml:hasProperty(key) then break end
                local order = xml:getInt(key .. "#order")
                if order ~= nil then done[order] = true end
                idx = idx + 1
            end
            for _, m in ipairs(c.milestones or {}) do
                if done[m.order] then m.completed = true end
            end
        else
            -- Different run than last session's progress: income restarts.
            c.income = 0
        end
        xml:delete()
    end)
end

-- ============================================================
-- Run history (per farm)
-- ============================================================

function MFC.appendHistory(c, result)
    if not isAuthority() or c == nil then return end
    guard("appendHistory", function()
        local farmId = c.farmId
        local entries = MFC.readHistory(farmId) or {}
        local goalMetric, goalTarget = "NetWorth", 0
        for _, m in ipairs(c.milestones or {}) do
            if m.kind == "FinalGoal" then
                goalMetric = m.metric or "NetWorth"
                goalTarget = m.target or 0
            end
        end
        local dateStr = ""
        pcall(function() dateStr = getDate("%d.%m.%Y") or "" end)
        table.insert(entries, 1, {
            name = c.name or "Challenge", difficulty = c.difficulty or "",
            result = result or "?", yearsUsed = c.challengeYear or 1,
            yearsTotal = c.years or 0, metric = goalMetric,
            target = goalTarget, date = dateStr, earned = MFC.incomeValue(farmId),
        })

        ensureFarmDir(farmId)
        local xml = XMLFile.create("MFCHistoryW", MFC.historyFile(farmId), "history")
        if xml == nil then return end
        for i, e in ipairs(entries) do
            if i > 20 then break end
            local k = string.format("history.run(%d)", i - 1)
            xml:setString(k .. "#name", e.name)
            xml:setString(k .. "#difficulty", e.difficulty)
            xml:setString(k .. "#result", e.result)
            xml:setInt(k .. "#yearsUsed", e.yearsUsed or 1)
            xml:setInt(k .. "#yearsTotal", e.yearsTotal or 0)
            xml:setString(k .. "#metric", e.metric)
            xml:setFloat(k .. "#target", e.target or 0)
            xml:setString(k .. "#date", e.date or "")
            xml:setFloat(k .. "#earned", e.earned or 0)
        end
        xml:save()
        xml:delete()
        log(string.format("Farm %d history: recorded '%s' as %s.",
            farmId or 0, c.name or "?", result or "?"))
    end)
end

function MFC.readHistory(farmId)
    return guard("readHistory", function()
        local path = MFC.historyFile(farmId or MFC.localFarmId())
        if not fileExists(path) then return {} end
        local xml = XMLFile.load("MFCHistoryR", path)
        if xml == nil then return {} end
        local entries = {}
        local i = 0
        while true do
            local k = string.format("history.run(%d)", i)
            if not xml:hasProperty(k) then break end
            table.insert(entries, {
                name = xml:getString(k .. "#name") or "Challenge",
                difficulty = xml:getString(k .. "#difficulty") or "",
                result = xml:getString(k .. "#result") or "?",
                yearsUsed = xml:getInt(k .. "#yearsUsed") or 1,
                yearsTotal = xml:getInt(k .. "#yearsTotal") or 0,
                metric = xml:getString(k .. "#metric") or "NetWorth",
                target = xml:getFloat(k .. "#target") or 0,
                date = xml:getString(k .. "#date") or "",
                earned = xml:getFloat(k .. "#earned") or 0,
            })
            i = i + 1
        end
        xml:delete()
        return entries
    end, {})
end

function MFC.getHistoryPublic(n)
    local entries = MFC.readHistory(MFC.localFarmId()) or {}
    local out = {}
    for i = 1, math.min(n or 4, #entries) do out[i] = entries[i] end
    return out
end

-- ============================================================
-- Starting, clearing and syncing
-- ============================================================

-- Remove one farm's challenge data. deleteFile may be unavailable or refused,
-- so verify and fall back to an "abandoned" tombstone, which the loader treats
-- as no challenge.
function MFC.clearChallengeFiles(farmId, alsoHistory)
    guard("clearChallengeFiles", function()
        local function nuke(path, root)
            if not fileExists(path) then return end
            pcall(function()
                if deleteFile ~= nil then deleteFile(path) end
            end)
            if fileExists(path) then
                local xml = XMLFile.create("MFCTomb", path, root)
                if xml ~= nil then
                    xml:setBool(root .. "#abandoned", true)
                    xml:save()
                    xml:delete()
                end
            end
        end
        nuke(MFC.challengeFile(farmId), "challenge")
        nuke(MFC.progressFile(farmId), "progress")
        if alsoHistory then nuke(MFC.historyFile(farmId), "history") end
    end)
end

-- Start a challenge for one farm. Only the authority runs this; in multiplayer
-- a client's Create button sends a request that lands here on the server, with
-- the farm id already forced to the requester's own farm.
function MFC.startCampaignAuthoritative(c)
    if c == nil or not isAuthority() then return false end

    local farmId = tonumber(c.farmId) or 0
    if farmId <= 0 then farmId = MFC.localFarmId() end
    if farmId <= 0 then
        log("Refusing to start a challenge with no farm.")
        return false
    end
    c.farmId = farmId

    c.state = "active"
    c.celebrated = false
    c.setupDone = false
    c.setupPending = true
    c.startDay = nil
    c.endYearsUsed = nil
    c.endGoalValue = nil
    c.income = 0
    c.challengeYear = 1
    c.elapsedYears = 0
    c.live = nil
    -- Clear the previous run's snapshot. A fresh one is captured once the
    -- selected starting economy has been applied.
    c.baselineNetWorth = nil
    c.baselineFields = nil
    c.baselineMoney = nil
    c.baselineCaptured = false
    c.repNetWorth = nil
    c.repFields = nil
    for _, m in ipairs(c.milestones or {}) do
        m.completed = false
        m.missed = false
    end

    MFC.campaigns[farmId] = c
    MFC.refreshLocalCampaign()
    MFC.resetVehicleScan()
    MFC.writeCampaign(c)
    MFC.applyRestrictions()
    notifyFarm(farmId, string.format("Challenge started: %s", c.name or ""))
    MFC.networkDirty = true
    if MFC_Network ~= nil then MFC_Network.broadcastState() end
    log(string.format("Farm %d challenge started: %s (seed %d).",
        farmId, c.name or "?", c.seed or 0))
    return true
end

function MFC.startCampaign(c)
    if c == nil then return false end
    if MFC.isMultiplayer() and MFC_Network ~= nil then
        return MFC_Network.requestStart(c)
    end
    return MFC.startCampaignAuthoritative(c)
end

function MFC.abandonCampaignAuthoritative(farmId)
    if not isAuthority() then return false end
    if farmId == nil or farmId <= 0 then farmId = MFC.localFarmId() end
    local c = MFC.getCampaign(farmId)
    if c == nil then return false end
    return guard("abandonCampaign", function()
        local name = c.name or "?"
        local wasActive = (c.state or "active") == "active"
        if wasActive then MFC.appendHistory(c, "abandoned") end
        MFC.clearChallengeFiles(farmId, false)
        MFC.campaigns[farmId] = nil
        MFC.refreshLocalCampaign()
        MFC.resetVehicleScan()
        MFC.applyRestrictions()
        notifyFarm(farmId, wasActive and "Challenge abandoned." or "Result cleared.")
        MFC.networkDirty = true
        if MFC_Network ~= nil then MFC_Network.broadcastState() end
        log(string.format("Farm %d: %s (%s).", farmId,
            wasActive and "challenge abandoned" or "result cleared", name))
        return true
    end, false)
end

function MFC.abandonCampaign()
    if MFC.isMultiplayer() and MFC_Network ~= nil then
        return MFC_Network.requestAbandon()
    end
    return MFC.abandonCampaignAuthoritative(MFC.localFarmId())
end

-- Adopt an authoritative snapshot from the server (clients only). `incoming` is
-- a table of [farmId] = campaign, already carrying its `live` values.
function MFC.applyNetworkState(incoming)
    MFC.networkSynced = true
    MFC.networkSyncAttempts = 0

    local localFarmId = MFC.localFarmId()
    local previous = MFC.campaign
    local previousSeed = previous and previous.seed or nil
    local previousState = previous and (previous.state or "active") or nil
    local previousCompleted = {}
    for _, m in ipairs((previous and previous.milestones) or {}) do
        if m.completed then previousCompleted[m.order or 0] = true end
    end

    MFC.campaigns = incoming or {}
    MFC.refreshLocalCampaign()
    MFC.applyRestrictions()
    MFC.refreshHudCache()

    -- Everything below is about the local player's own farm; other farms'
    -- milestones are their business.
    local current = MFC.campaign
    local newSeed = current and current.seed or nil
    local newState = current and (current.state or "active") or nil

    if newSeed ~= previousSeed then
        if current ~= nil then
            MFC.notify(string.format("Your farm's challenge: %s", current.name or "Challenge"))
        elseif previous ~= nil then
            MFC.notify("Your farm's challenge was cleared.")
        end
        return
    end
    if current == nil then return end

    for _, m in ipairs(current.milestones or {}) do
        if m.completed and not previousCompleted[m.order or 0] and m.kind ~= "FinalGoal" then
            MFC.notify("Milestone complete: " .. (m.title or "Checkpoint"))
        end
    end
    -- Only celebrate a transition witnessed in this session. Joining a server
    -- whose run finished long ago must not pop a completion dialog.
    if previousState ~= nil and newState ~= previousState
        and (newState == "won" or newState == "failed") then
        MFC.pendingCelebration = true
    end
    if localFarmId <= 0 then MFC.pendingCelebration = false end
end

-- ============================================================
-- In-menu challenge page (Escape menu tab)
--
-- Manual insertion into g_inGameMenu.pagingElement, then registerPage +
-- addPageTab + rebuildTabList. Fully guarded: any failure disables the page and
-- logs, leaving the pause menu intact.
-- ============================================================

local function installMenuPage()
    if MFC.menuPageInstalled then return end

    local ok, err = pcall(function()
        if g_gui == nil or g_inGameMenu == nil then return end
        if MFC_MenuPage == nil then
            log("WARN: MFC_MenuPage class missing; menu page skipped.")
            return
        end

        local frame = MFC_MenuPage.new()
        frame.customEnvironment = MFC.MOD_NAME
        guard("loadGuiProfiles", function()
            g_gui:loadProfiles(MFC.MOD_DIR .. "gui/guiProfiles.xml")
        end)
        g_gui:loadGui(MFC.MOD_DIR .. "gui/MFC_MenuPage.xml", "MFC_MenuPage", frame, true)

        local pageName = "mfcChallengePage"
        local insertAfter = "pageStatistics"

        g_inGameMenu.controlIDs[pageName] = nil

        local targetPosition = #g_inGameMenu.pagingElement.elements + 1
        for i = 1, #g_inGameMenu.pagingElement.elements do
            if g_inGameMenu.pagingElement.elements[i] == g_inGameMenu[insertAfter] then
                targetPosition = i + 1
                break
            end
        end

        g_inGameMenu[pageName] = frame
        g_inGameMenu.pagingElement:addElement(g_inGameMenu[pageName])
        g_inGameMenu:exposeControlsAsFields(pageName)

        local function reorder(list, matchField)
            for i = 1, #list do
                local item = list[i]
                local el = (matchField == nil) and item or item.element
                if el == g_inGameMenu[pageName] then
                    table.remove(list, i)
                    table.insert(list, targetPosition, item)
                    break
                end
            end
        end
        reorder(g_inGameMenu.pagingElement.elements, nil)
        reorder(g_inGameMenu.pagingElement.pages, "element")

        g_inGameMenu.pagingElement:updateAbsolutePosition()
        g_inGameMenu.pagingElement:updatePageMapping()
        g_inGameMenu:registerPage(g_inGameMenu[pageName], nil, function() return true end)

        local iconFile = Utils.getFilename("tab_mfc.dds", MFC.MOD_DIR)
        g_inGameMenu:addPageTab(g_inGameMenu[pageName], iconFile,
            GuiUtils.getUVs({ 0, 0, 256, 256 }, { 256, 256 }))

        if g_inGameMenu.pageFrames ~= nil then reorder(g_inGameMenu.pageFrames, nil) end
        g_inGameMenu:rebuildTabList()

        MFC.menuPageInstalled = true
        MFC.menuPage = frame
        log("Menu page installed.")
    end)

    if not ok and not MFC.menuPageErrLogged then
        MFC.menuPageErrLogged = true
        log("WARN: menu page install failed (pause menu unaffected): " .. tostring(err))
    end
end

-- ============================================================
-- Migration
--
-- Two older layouts get copied forward, once, into farm_<id>/:
--   * modSettings/<modName>/save_<slot>/challenge.xml  (one challenge per save)
--   * modSettings/MayflowerFarmChallenge/save_<slot>/  (the pre-rename folder)
-- Files are copied, never moved, so the old data stays put as a backup.
-- ============================================================

-- XMLFile.load prints an engine-level error for a zero-byte file, which no
-- amount of pcall can suppress. Old settings folders can be left holding
-- truncated files, and the migration probe would then dirty log.txt on every
-- single map load, forever. Check for content first.
local function fileHasContent(path)
    return guard("fileHasContent", function()
        if not fileExists(path) then return false end
        local handle = io.open(path, "rb")
        if handle == nil then return false end
        local chunk = handle:read(64)
        handle:close()
        return chunk ~= nil and #chunk > 0
    end, false)
end

local function copyFile(src, dst)
    return guard("copyFile", function()
        if not fileExists(src) then return false end
        local input = io.open(src, "rb")
        if input == nil then return false end
        local data = input:read("*a")
        input:close()
        if data == nil or data == "" then return false end
        local output = io.open(dst, "wb")
        if output == nil then return false end
        output:write(data)
        output:close()
        return true
    end, false)
end

-- Which farm did a flat, pre-per-farm challenge belong to? Newer files record
-- it; older ones predate multiplayer entirely, so they belong to this player.
local function farmIdOfFlatChallenge(path)
    return guard("farmIdOfFlatChallenge", function()
        local xml = XMLFile.load("MFCFlatProbe", path)
        if xml == nil then return nil end
        local farmId = xml:getInt("challenge#farmId")
        local abandoned = xml:getBool("challenge#abandoned") == true
        xml:delete()
        if abandoned then return nil end
        if farmId ~= nil and farmId > 0 then return farmId end
        local localFarmId = MFC.localFarmId()
        return localFarmId > 0 and localFarmId or 1
    end, nil)
end

local function migrateFlatLayout()
    guard("migrateFlatLayout", function()
        local sources = { MFC.saveDir(), string.format("%ssave_%s/", MFC.LEGACY_DIR, savegameIndex()) }
        for _, dir in ipairs(sources) do
            local flat = dir .. "challenge.xml"
            if fileHasContent(flat) then
                local farmId = farmIdOfFlatChallenge(flat)
                if farmId ~= nil and not fileExists(MFC.challengeFile(farmId)) then
                    ensureFarmDir(farmId)
                    local moved = 0
                    for _, name in ipairs({ "challenge.xml", "progress.xml", "history.xml" }) do
                        if copyFile(dir .. name, MFC.farmDir(farmId) .. name) then moved = moved + 1 end
                    end
                    if moved > 0 then
                        log(string.format("Migrated %d file(s) into farm_%d for save %s.",
                            moved, farmId, savegameIndex()))
                    end
                end
            end
        end
    end)
end

-- ============================================================
-- Lifecycle
-- ============================================================

local function loadAllCampaigns()
    MFC.campaigns = {}
    for _, farmId in ipairs(allFarmIds()) do
        local c = loadCampaignFile(MFC.challengeFile(farmId), farmId)
        if c ~= nil then
            c.farmId = farmId
            MFC.campaigns[farmId] = c
            readProgressFor(c)
        end
    end
end

local function onMapLoaded()
    local serverSide = isAuthority()

    if serverSide then
        -- A brand-new game reuses its slot's savegame index, so any challenge
        -- data in the folder belongs to the save that occupied that slot before.
        guard("newGameStaleCheck", function()
            local info = g_currentMission and g_currentMission.missionInfo
            if info == nil or info.isValid ~= false then return end
            for _, farmId in ipairs(allFarmIds()) do
                if fileExists(MFC.challengeFile(farmId)) then
                    MFC.clearChallengeFiles(farmId, true)
                end
            end
            log("New game detected in this slot; cleared stale challenge data.")
        end)

        migrateFlatLayout()
        loadAllCampaigns()
        MFC.refreshLocalCampaign()
        MFC.writeProgress()
    else
        -- Clients never load or judge local files; they wait for the server's
        -- authoritative snapshot.
        MFC.campaigns = {}
        MFC.campaign = nil
        MFC.networkSynced = false
        MFC.networkSyncAttempts = 0
    end

    MFC.resetVehicleScan()
    MFC.applyRestrictions()
    installMenuPage()

    if MFC.isMultiplayer() and MFC_Network ~= nil then
        if serverSide then MFC_Network.broadcastState() else MFC_Network.requestSync() end
    end
end
FSBaseMission.loadMapFinished = Utils.appendedFunction(FSBaseMission.loadMapFinished, onMapLoaded)

-- Deferred end-of-run dialog: retried from the update loop until the player is
-- actually looking (mission running, no GUI open), so it can't fire invisibly
-- during a loading screen and be lost. Only ever about the player's own farm.
function MFC.celebrateIfPending()
    guard("celebrateIfPending", function()
        if not MFC.isClient() then return end
        local c = MFC.campaign
        if c == nil then return end
        local state = c.state or "active"
        if state ~= "won" and state ~= "failed" then return end

        -- The authority tracks this in the challenge file; a client tracks the
        -- transition it witnessed over the network.
        if isAuthority() then
            if c.celebrated == true then return end
        elseif MFC.pendingCelebration ~= true then
            return
        end

        if g_currentMission == nil or g_currentMission.isMissionStarted == false then return end
        if g_gui ~= nil and g_gui.getIsGuiVisible ~= nil and g_gui:getIsGuiVisible() then return end

        MFC.pendingCelebration = false
        if isAuthority() then
            c.celebrated = true
            MFC.writeCampaign(c)
        end

        local function fmt(v)
            return (g_i18n ~= nil and g_i18n.formatMoney ~= nil)
                and g_i18n:formatMoney(v) or tostring(math.floor(v or 0))
        end

        if state == "won" then
            MFC.notify(string.format("CHALLENGE COMPLETE: %s!", c.name or "Challenge"))
            pcall(function()
                if InfoDialog == nil or InfoDialog.show == nil then return end
                local done, total = 0, 0
                for _, m in ipairs(c.milestones or {}) do
                    total = total + 1
                    if m.completed then done = done + 1 end
                end
                local ruleCount = 0
                for _ in pairs(c.restrictions or {}) do ruleCount = ruleCount + 1 end
                local lines = {
                    "CHALLENGE COMPLETE!",
                    "",
                    string.format("%s (%s)", c.name or "Challenge", c.difficulty or ""),
                    string.format("Finished in year %d of %d  -  %d/%d milestones",
                        c.endYearsUsed or (c.challengeYear or 1), c.years or 0, done, total),
                    string.format("Money earned:  %s", fmt(MFC.getIncomePublic())),
                }
                if c.repNetWorth ~= nil then
                    table.insert(lines, string.format("Net worth:  %s  ->  %s",
                        fmt(c.repNetWorth), fmt(MFC.getNetWorthPublic())))
                end
                local fields = MFC.getOwnedFieldsPublic()
                if c.repFields ~= nil and fields ~= c.repFields then
                    table.insert(lines, string.format("Fields owned:  %d  ->  %d", c.repFields, fields))
                end
                if ruleCount > 0 then
                    table.insert(lines, string.format("Completed under %d restriction%s.",
                        ruleCount, ruleCount == 1 and "" or "s"))
                end
                InfoDialog.show(table.concat(lines, "\n"))
            end)
        else
            MFC.notify("Challenge failed - time limit reached.")
            pcall(function()
                if InfoDialog == nil or InfoDialog.show == nil then return end
                local dialogType = (DialogElement ~= nil) and DialogElement.TYPE_WARNING or nil
                InfoDialog.show(string.format(
                    "Challenge failed.\n\n%s (%s)\nThe time limit of %d years was reached.",
                    c.name or "Challenge", c.difficulty or "", c.years or 0), nil, nil, dialogType)
            end)
        end
        log("Challenge end shown to player (" .. state .. ").")
    end)
end

-- ============================================================
-- On-screen HUD readout (the local player's farm only)
-- ============================================================

local function fmtShort(metric, v)
    v = v or 0
    if metric == "OwnFields" then return string.format("%d fields", math.floor(v)) end
    local a = math.abs(v)
    if a >= 1000000 then return string.format("$%.2fM", v / 1000000) end
    if a >= 1000 then return string.format("$%dk", math.floor(v / 1000 + 0.5)) end
    return string.format("$%d", math.floor(v + 0.5))
end

local function metricShortLabel(metric)
    if metric == "OwnFields" then return "Fields" end
    if metric == "Income" then return "Earned" end
    return "Net worth"
end

function MFC.refreshHudCache()
    guard("refreshHudCache", function()
        local c = MFC.campaign
        if c == nil then MFC.hudLines = nil return end
        local state = c.state or "active"
        if state == "won" then
            MFC.hudLines = { string.format("Farm Challenge  -  %s  -  COMPLETE", c.name or "") }
            return
        elseif state == "failed" then
            MFC.hudLines = { string.format("Farm Challenge  -  %s  -  FAILED", c.name or "") }
            return
        end

        local goal, goalMetric, nextLine = 0, "NetWorth", nil
        for _, m in ipairs(c.milestones or {}) do
            if m.kind == "FinalGoal" then
                goal = m.target or 0
                goalMetric = m.metric or "NetWorth"
            elseif nextLine == nil and not m.completed then
                local metric = m.metric or m.kind
                local current = MFC.getChallengeMetricPublic(metric) or 0
                local pct = (m.target or 0) > 0 and math.min(current / m.target, 1) or 0
                nextLine = string.format("Next:  %s %s by year %d  (%d%%)",
                    metricShortLabel(metric), fmtShort(metric, m.target),
                    m.dueYear or 0, math.floor(pct * 100 + 0.5))
            end
        end
        local current = MFC.getChallengeMetricPublic(goalMetric) or 0
        local pct = (goal > 0) and math.min(current / goal, 1) or 0
        MFC.hudLines = {
            string.format("Farm Challenge  %d%%  -  %s %s / %s  -  Year %d of %d",
                math.floor(pct * 100 + 0.5), metricShortLabel(goalMetric),
                fmtShort(goalMetric, current), fmtShort(goalMetric, goal),
                math.min(c.challengeYear or 1, c.years or 1), c.years or 0),
            nextLine,
        }
    end)
end

function MFC.onToggleHud()
    MFC.hudShown = (MFC.hudShown == false)
    MFC.notify(MFC.hudShown and "Challenge HUD shown" or "Challenge HUD hidden")
end

FSBaseMission.draw = Utils.appendedFunction(FSBaseMission.draw, function()
    pcall(function()
        if MFC.hudShown == false then return end
        if MFC.campaign == nil or MFC.hudLines == nil then return end
        if g_gui ~= nil and g_gui.getIsGuiVisible ~= nil and g_gui:getIsGuiVisible() then return end
        setTextBold(false)
        setTextAlignment(RenderText.ALIGN_CENTER)
        setTextColor(1, 1, 1, 0.85)
        renderText(0.5, 0.972, 0.014, MFC.hudLines[1] or "")
        if MFC.hudLines[2] ~= nil then
            setTextColor(1, 1, 1, 0.6)
            renderText(0.5, 0.952, 0.012, MFC.hudLines[2])
        end
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextColor(1, 1, 1, 1)
    end)
end)

-- Note: the first argument of an appended FSBaseMission.update is the mission
-- object, NOT a delta time. The whole body is wrapped in pcall because an error
-- here repeats every frame.
local BROADCAST_MIN_TICKS = 30     -- ~0.5s floor between snapshots
local BROADCAST_MAX_TICKS = 120    -- ~2s heartbeat
local PROGRESS_FLUSH_TICKS = 2700  -- ~60s between progress writes

local function hasAnyCampaign()
    return next(MFC.campaigns) ~= nil
end

local function onUpdate()
    local ok, err = pcall(function()
        -- The tab is useful even with no challenge, so install it regardless.
        if not MFC.menuPageInstalled then
            MFC.menuPageAttempts = (MFC.menuPageAttempts or 0) + 1
            if MFC.menuPageAttempts <= 120 then installMenuPage() end
        end

        -- A client may ask before the server is ready. Retry a few times; the
        -- request is tiny and idempotent.
        if MFC.isMultiplayer() and not MFC.isServer() and MFC.networkSynced ~= true
            and (MFC.networkSyncAttempts or 0) < 8 then
            MFC.networkSyncTimer = (MFC.networkSyncTimer or 0) + 1
            if MFC.networkSyncTimer >= 90 then
                MFC.networkSyncTimer = 0
                MFC.networkSyncAttempts = (MFC.networkSyncAttempts or 0) + 1
                if MFC_Network ~= nil then MFC_Network.requestSync() end
            end
        end

        MFC.hudTicks = (MFC.hudTicks or 0) + 1
        if MFC.hudTicks >= 45 then -- roughly once a second
            MFC.hudTicks = 0
            -- Farm membership can change mid-session, so the local view and the
            -- global restriction state are re-resolved on this tick.
            local before = MFC.campaign
            MFC.refreshLocalCampaign()
            if MFC.campaign ~= before then MFC.applyRestrictions() end
            MFC.evaluateChallenges()
            MFC.refreshHudCache()
            MFC.celebrateIfPending()
        end

        if not isAuthority() or not hasAnyCampaign() then return end

        if MFC_SaveSetup ~= nil then
            for _, c in pairs(MFC.campaigns) do
                if c.setupPending and MFC_SaveSetup.run(c) then
                    -- Capture the post-setup snapshot before any judging.
                    MFC.captureBaselines(c)
                    c.setupPending = false
                    c.setupDone = true
                    MFC.writeCampaign(c)
                    MFC.writeProgress()
                    MFC.networkDirty = true
                end
            end
        end

        scanLeasedVehicles()

        local day = absoluteDay()
        if day ~= MFC.lastDayWritten then
            MFC.lastDayWritten = day
            MFC.writeProgress()
            MFC.networkDirty = true
        else
            -- A day can be a long time to lose. Flush periodically as well, so
            -- quitting mid-day costs at most a minute of earned income rather
            -- than everything since the last day rolled over.
            MFC.progressTicks = (MFC.progressTicks or 0) + 1
            if MFC.progressTicks >= PROGRESS_FLUSH_TICKS then
                MFC.progressTicks = 0
                MFC.writeProgress()
            end
        end

        -- Keep clients on the same numbers. Snapshots are rate-limited: an
        -- unthrottled dirty flag could broadcast every farm's run every frame
        -- while money is flowing.
        if MFC.isMultiplayer() and MFC_Network ~= nil then
            MFC.broadcastTicks = (MFC.broadcastTicks or 0) + 1
            local due = (MFC.networkDirty == true and MFC.broadcastTicks >= BROADCAST_MIN_TICKS)
                or MFC.broadcastTicks >= BROADCAST_MAX_TICKS
            if due then
                MFC.broadcastTicks = 0
                MFC.networkDirty = false
                MFC_Network.broadcastState()
            end
        end
    end)
    if not ok and not MFC.updateErrorLogged then
        MFC.updateErrorLogged = true -- log once, not every frame
        log("ERROR in update (suppressed after first): " .. tostring(err))
    end
end
FSBaseMission.update = Utils.appendedFunction(FSBaseMission.update, onUpdate)

-- Live values the server sends so clients can draw a farm they can't read.
function MFC.buildLiveValues(c)
    return {
        netWorth = getNetWorth(c.farmId),
        fields = getOwnedFields(c.farmId),
        income = MFC.incomeValue(c.farmId),
    }
end

-- ============================================================
-- Load-time hooks
-- ============================================================

-- Teleport overrides must exist before any hotspot is created.
installTeleportClassHooks()

-- The steering-assist hook MUST install at script-load time: vehicle types copy
-- specialization functions into their own tables when types are finalized during
-- startup, so a map-load-time override lands on a table nobody consults anymore.
installSteeringAssistBlock()

-- HUD toggle keybind. Global player hotkeys must be registered inside
-- PlayerInputComponent.registerGlobalPlayerActionEvents, which the input system
-- re-runs on every context rebuild (vehicle enter/exit, menus). A one-shot
-- registration gets wiped at the first context switch.
guard("installHudKeybindHook", function()
    if PlayerInputComponent == nil or PlayerInputComponent.registerGlobalPlayerActionEvents == nil then
        log("WARN: PlayerInputComponent.registerGlobalPlayerActionEvents not found; HUD keybind inactive.")
        return
    end
    PlayerInputComponent.registerGlobalPlayerActionEvents = Utils.overwrittenFunction(
        PlayerInputComponent.registerGlobalPlayerActionEvents,
        function(self, superFunc, ...)
            superFunc(self, ...)
            pcall(function()
                if InputAction == nil or InputAction.MFC_TOGGLE_HUD == nil then
                    if not MFC.hudKeybindWarned then
                        MFC.hudKeybindWarned = true
                        log("WARN: MFC_TOGGLE_HUD action missing; HUD keybind inactive.")
                    end
                    return
                end
                local ok, id = g_inputBinding:registerActionEvent(
                    InputAction.MFC_TOGGLE_HUD, MFC, MFC.onToggleHud, false, true, false, true)
                if ok and id ~= nil then
                    g_inputBinding:setActionEventTextVisibility(id, false)
                end
            end)
        end)
    log("HUD keybind hook installed.")
end)

-- When the GPS rule makes steering assist unavailable, the AI Settings dialog's
-- own controller-focus init fails and the pad goes dead until the mouse hovers.
-- Appending to show() runs after that focus handling, so focus can be taken
-- deterministically. numTexts is re-synced too, because other mods call setTexts
-- on that element without updating it, which breaks controller cycling.
guard("installAIDialogFocusFix", function()
    if AISettingsDialog == nil or AISettingsDialog.show == nil then
        log("WARN: AISettingsDialog.show not found; AI dialog focus fix inactive.")
        return
    end
    AISettingsDialog.show = Utils.appendedFunction(AISettingsDialog.show, function()
        pcall(function()
            local dialog = AISettingsDialog.INSTANCE
            if dialog == nil or dialog.modeElement == nil then return end
            if dialog.modeElement.texts ~= nil then
                dialog.modeElement.numTexts = #dialog.modeElement.texts
            end
            if isRestricted("manualOnly") and FocusManager ~= nil and FocusManager.setFocus ~= nil then
                FocusManager:setFocus(dialog.modeElement)
            end
        end)
    end)
    log("AI dialog focus fix installed.")
end)

-- Leasing block: clear storeItem.allowLeasing so the shop's lease option is
-- removed. The shop is the local player's, so this gates on the local farm.
guard("installLeasingBlock", function()
    if ShopConfigScreen == nil or ShopConfigScreen.updateButtons == nil then
        log("WARN: ShopConfigScreen.updateButtons not found; leasing block inactive.")
        return
    end
    ShopConfigScreen.updateButtons = Utils.prependedFunction(
        ShopConfigScreen.updateButtons,
        function(self, storeItem)
            if storeItem ~= nil and isRestricted("noLeasing") then
                storeItem.allowLeasing = false
            end
        end)
    log("Leasing hook installed.")
end)

log("Mod loaded. Settings dir: " .. MFC.SETTINGS_DIR)
