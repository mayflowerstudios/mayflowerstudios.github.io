--
-- MayflowerFarmChallenge.lua  (v0.2)
--
-- Reads the campaign written by the companion app from
--   <userProfile>/modSettings/MayflowerFarmChallenge/challenge.xml
-- enforces its restrictions in-game, and writes progress back to
--   <userProfile>/modSettings/MayflowerFarmChallenge/progress.xml
-- every in-game day so the app's Progress tab updates.
--
-- Design notes:
--  * Restriction hooks are wrapped so a wrong/renamed API function logs a
--    warning and disables that one restriction, instead of crashing the save.
--    Anything tagged VERIFY below is a function name carried over from FS22
--    that you should confirm against your game log on first run.
--  * Single-player focus. Multiplayer would need event syncing.
--

MayflowerFarmChallenge = {}
local MFC = MayflowerFarmChallenge

MFC.MOD_DIR = g_currentModDirectory
MFC.MOD_NAME = g_currentModName
MFC.SETTINGS_DIR = getUserProfileAppPath() .. "modSettings/MayflowerFarmChallenge/"
-- Legacy (pre-0.16) global locations, kept only for one-time migration.
MFC.LEGACY_CHALLENGE_FILE = MFC.SETTINGS_DIR .. "challenge.xml"
MFC.LEGACY_PROGRESS_FILE = MFC.SETTINGS_DIR .. "progress.xml"

-- Challenges are stored per savegame so each save has its own challenge (or
-- none). Resolved lazily because missionInfo doesn't exist at mod-load time.
local function savegameIndex()
    local info = g_currentMission and g_currentMission.missionInfo
    return tostring((info and info.savegameIndex) or "unknown")
end

function MFC.saveDir()
    return string.format("%ssave_%s/", MFC.SETTINGS_DIR, savegameIndex())
end

function MFC.challengeFile()
    return MFC.saveDir() .. "challenge.xml"
end

function MFC.progressFile()
    return MFC.saveDir() .. "progress.xml"
end

MFC.campaign = nil
MFC.lastDayWritten = -1

-- Diagnostic logging. Off for release builds so a normal session leaves
-- log.txt completely clean; set to true to trace loading, save setup and the
-- challenge lifecycle while troubleshooting. The [setup] and [menu] loggers in
-- the companion scripts read this same flag.
MFC.DEBUG = false

local function log(msg)
    if not MFC.DEBUG then return end
    print(string.format("[MayflowerFarmChallenge] %s", msg))
end

local function guard(label, fn, fallback)
    local ok, result = pcall(fn)
    if not ok then
        log(string.format("WARN: '%s' failed (%s). That feature is disabled.", label, tostring(result)))
        return fallback
    end
    return result
end

-- ============================================================
-- Loading the campaign
-- ============================================================

function MFC.loadCampaign()
    if not fileExists(MFC.challengeFile()) then
        log("No challenge.xml found. Running with no restrictions.")
        return nil
    end

    local xml = XMLFile.load("MFCChallenge", MFC.challengeFile())
    if xml == nil then
        log("Could not open challenge.xml.")
        return nil
    end
    if xml:getBool("challenge#abandoned") == true then
        xml:delete()
        return nil
    end

    local c = {}
    c.seed = xml:getInt("challenge#seed") or 0
    c.name = xml:getString("challenge#name") or "Campaign"
    c.state = xml:getString("challenge#state") or "active"
    c.celebrated = xml:getBool("challenge#celebrated") == true
    c.endYearsUsed = xml:getInt("challenge#endYearsUsed")
    c.endGoalValue = xml:getFloat("challenge#endGoalValue")
    c.startYear = xml:getInt("challenge#startYear")
    c.repNetWorth = xml:getFloat("challenge#repNetWorth")
    c.repFields = xml:getInt("challenge#repFields")
    c.baselineNetWorth = xml:getFloat("challenge.baseline#netWorth")
    c.baselineFields = xml:getInt("challenge.baseline#ownedFields")
    c.baselineMoney = xml:getFloat("challenge.baseline#money")
    c.baselineCaptured = xml:getBool("challenge.baseline#captured") == true
    -- Compatibility with campaigns created before explicit challenge baselines:
    -- repNetWorth/repFields were captured at the start of the run and are the
    -- safest available baseline for those saves.
    if c.baselineNetWorth == nil and c.repNetWorth ~= nil then
        c.baselineNetWorth = c.repNetWorth
    end
    if c.baselineFields == nil and c.repFields ~= nil then
        c.baselineFields = c.repFields
    end
    if c.baselineNetWorth ~= nil and c.baselineFields ~= nil then
        c.baselineCaptured = true
    end
    c.difficulty = xml:getString("challenge#difficulty") or ""
    c.mapId = xml:getString("challenge.map#id") or ""
    c.maxLoan = xml:getInt("challenge.economy#maxLoan") or -1
    c.years = xml:getInt("challenge.economy#years") or 0
    c.startType = xml:getString("challenge.economy#startType") or "withFarm"
    c.setsEconomy = xml:getBool("challenge.economy#setsEconomy") or false
    -- -1 means "leave the player's cash/loan untouched" (the default). A value
    -- >= 0 is an explicit starting amount the player opted into.
    c.startMoney = xml:getInt("challenge.economy#startMoney")
    if c.startMoney == nil then c.startMoney = -1 end
    c.startDebt = xml:getInt("challenge.economy#startDebt")
    if c.startDebt == nil then c.startDebt = -1 end
    c.econDifficulty = xml:getString("challenge.economy#econDifficulty") or ""
    -- How the "Money earned" metric is measured: "gross" = income received
    -- since the challenge began (spending doesn't reduce it); "net" = current
    -- cash minus the balance captured at challenge start.
    c.incomeMode = xml:getString("challenge.economy#incomeMode") or "gross"

    c.restrictions = {}
    local i = 0
    while true do
        local key = string.format("challenge.restrictions.restriction(%d)", i)
        if not xml:hasProperty(key) then break end
        local id = xml:getString(key .. "#id")
        if id ~= nil then c.restrictions[id] = true end
        i = i + 1
    end

    c.blockedCategories = {}
    i = 0
    while true do
        local key = string.format("challenge.shop.blockCategory(%d)", i)
        if not xml:hasProperty(key) then break end
        local name = xml:getString(key .. "#name")
        if name ~= nil then c.blockedCategories[name] = true end
        i = i + 1
    end

    c.brandMode = xml:getString("challenge.brands#mode") or "none"
    c.brandSet = {}
    local brandNames = {}
    i = 0
    while true do
        local key = string.format("challenge.brands.brand(%d)", i)
        if not xml:hasProperty(key) then break end
        local id = xml:getString(key .. "#id")
        if id ~= nil then
            c.brandSet[id:upper()] = true
            table.insert(brandNames, id)
        end
        i = i + 1
    end
    c.brandListStr = table.concat(brandNames, " or ")

    c.milestones = {}
    i = 0
    while true do
        local key = string.format("challenge.milestones.milestone(%d)", i)
        if not xml:hasProperty(key) then break end
        table.insert(c.milestones, {
            order = xml:getInt(key .. "#order") or (i + 1),
            kind = xml:getString(key .. "#kind") or "NetWorth",
            metric = xml:getString(key .. "#metric"),
            target = xml:getFloat(key .. "#target") or 0,
            title = xml:getString(key .. "#title") or "",
            dueYear = xml:getInt(key .. "#dueYear") or 1,
            completed = false,
        })
        i = i + 1
    end

    xml:delete()
    log(string.format("Loaded campaign '%s' (%s, seed %d) with %d milestones.",
        c.name, c.difficulty, c.seed, #c.milestones))
    return c
end

local function isRestricted(id)
    return MFC.campaign ~= nil
        and (MFC.campaign.state or "active") == "active"
        and MFC.campaign.restrictions[id] == true
end

-- Write a campaign table to challenge.xml so it persists and re-loads on restart.
function MFC.writeCampaign(c)
    return guard("writeCampaign", function()
        createFolder(MFC.SETTINGS_DIR)
        createFolder(MFC.saveDir())
        local xml = XMLFile.create("MFCChallengeW", MFC.challengeFile(), "challenge")
        if xml == nil then
            log("WARN: could not create challenge.xml")
            return false
        end
        xml:setInt("challenge#seed", c.seed or 0)
        xml:setString("challenge#name", c.name or "Campaign")
        xml:setString("challenge#state", c.state or "active")
        xml:setBool("challenge#celebrated", c.celebrated == true)
        if c.endYearsUsed ~= nil then xml:setInt("challenge#endYearsUsed", c.endYearsUsed) end
        if c.endGoalValue ~= nil then xml:setFloat("challenge#endGoalValue", c.endGoalValue) end
        if c.startYear ~= nil then xml:setInt("challenge#startYear", c.startYear) end
        if c.repNetWorth ~= nil then xml:setFloat("challenge#repNetWorth", c.repNetWorth) end
        if c.repFields ~= nil then xml:setInt("challenge#repFields", c.repFields) end
        if c.baselineNetWorth ~= nil then xml:setFloat("challenge.baseline#netWorth", c.baselineNetWorth) end
        if c.baselineFields ~= nil then xml:setInt("challenge.baseline#ownedFields", c.baselineFields) end
        if c.baselineMoney ~= nil then xml:setFloat("challenge.baseline#money", c.baselineMoney) end
        xml:setBool("challenge.baseline#captured", c.baselineCaptured == true)
        xml:setString("challenge#difficulty", c.difficulty or "")
        xml:setString("challenge.map#id", c.mapId or "")
        xml:setInt("challenge.economy#startMoney", c.startMoney or -1)
        xml:setInt("challenge.economy#maxLoan", c.maxLoan or -1)
        xml:setInt("challenge.economy#years", c.years or 0)
        xml:setString("challenge.economy#startType", c.startType or "withFarm")
        xml:setBool("challenge.economy#setsEconomy", c.setsEconomy == true)
        xml:setInt("challenge.economy#startDebt", c.startDebt or -1)
        xml:setString("challenge.economy#econDifficulty", c.econDifficulty or "")
        xml:setString("challenge.economy#incomeMode", c.incomeMode or "gross")

        local ri = 0
        for id in pairs(c.restrictions or {}) do
            xml:setString(string.format("challenge.restrictions.restriction(%d)#id", ri), id)
            ri = ri + 1
        end

        xml:setString("challenge.brands#mode", c.brandMode or "none")
        local bi = 0
        for id in pairs(c.brandSet or {}) do
            xml:setString(string.format("challenge.brands.brand(%d)#id", bi), id)
            bi = bi + 1
        end

        for mi, m in ipairs(c.milestones or {}) do
            local k = string.format("challenge.milestones.milestone(%d)", mi - 1)
            xml:setInt(k .. "#order", m.order or mi)
            xml:setString(k .. "#kind", m.kind or "NetWorth")
            if m.metric ~= nil then
                xml:setString(k .. "#metric", m.metric)
            end
            xml:setFloat(k .. "#target", m.target or 0)
            xml:setString(k .. "#title", m.title or "")
            xml:setInt(k .. "#dueYear", m.dueYear or 1)
        end

        xml:save()
        xml:delete()
        log(string.format("Wrote challenge.xml for '%s'.", c.name or "?"))
        return true
    end, false)
end

-- Start a freshly-created campaign (from the in-game tab): persist it, make it
-- live, and arm save setup so the update loop configures the save.
function MFC.startCampaign(c)
    if c == nil then return end
    -- Clear the old run snapshot. A fresh snapshot is captured after the selected
    -- starting economy is applied, but progress conditions use absolute values so
    -- the farm's existing assets, cash and fields still count.
    c.baselineNetWorth = nil
    c.baselineFields = nil
    c.baselineMoney = nil
    c.baselineCaptured = false
    c.repNetWorth = nil
    c.repFields = nil
    for _, m in ipairs(c.milestones or {}) do
        m.completed = false
        m.missed = false
    end
    MFC.writeCampaign(c)
    MFC.campaign = c
    MFC.earnedIncome = 0
    MFC.setupPending = true
    -- Clear the per-save "configured" flag for this save so setup re-runs for
    -- the new campaign (setup is keyed to save index + seed; new seed = re-run).
    MFC.writeProgress()
    if MFC.notify ~= nil then
        MFC.notify(string.format("Challenge started: %s", c.name or ""))
    end
    -- Enforce the new campaign's rules right now, no restart needed.
    if MFC.applyRestrictions ~= nil then
        MFC.applyRestrictions()
    end
    log(string.format("Campaign started in-tab: %s (seed %d).", c.name or "?", c.seed or 0))
end

-- ============================================================
-- Reading live farm state
-- ============================================================

local function getFarm()
    if g_currentMission == nil or g_farmManager == nil then return nil end
    -- Confirmed FS25 path (from LeaseToOwn): farm by the player's user id.
    if g_currentMission.playerUserId ~= nil and g_farmManager.getFarmByUserId ~= nil then
        local farm = g_farmManager:getFarmByUserId(g_currentMission.playerUserId)
        if farm ~= nil then return farm end
    end
    -- Fallback to farm id.
    if g_currentMission.getFarmId ~= nil then
        return g_farmManager:getFarmById(g_currentMission:getFarmId())
    end
    return nil
end

-- Forward declaration because the setup-page projection helper is defined
-- before the owned-field accessor body below.
local getOwnedFields

-- VERIFY: farm.money field vs farm:getBalance()
local function getMoney()
    return guard("getMoney", function()
        local farm = getFarm()
        if farm == nil then return 0 end
        if farm.getBalance ~= nil then return farm:getBalance() end
        return farm.money or 0
    end, 0)
end

-- VERIFY: equity/net-worth accessor. Falls back to cash.
-- Net worth = cash + asset equity - loan. Farm:getEquity() counts owned land
-- and placeables only (no cash), which is why it reads 0 on a fresh farm.
local function getNetWorth()
    return guard("getNetWorth", function()
        local farm = getFarm()
        if farm == nil then return 0 end
        local cash = 0
        if farm.getBalance ~= nil then cash = farm:getBalance() or 0
        else cash = farm.money or 0 end
        local assets = 0
        if farm.getEquity ~= nil then
            local ok, v = pcall(function() return farm:getEquity() end)
            if ok and type(v) == "number" then assets = v end
        end
        local loan = farm.loan or 0
        return cash + assets - loan
    end, 0)
end

-- Public accessors used by the challenge setup page.
function MFC.getNetWorthPublic()
    return getNetWorth()
end

function MFC.getMoneyPublic()
    return getMoney()
end

function MFC.getLoanPublic()
    local farm = getFarm()
    if farm == nil then return 0 end
    if farm.getLoan ~= nil then
        local ok, value = pcall(function() return farm:getLoan() end)
        if ok and type(value) == "number" then return value end
    end
    return farm.loan or 0
end

-- Return the value a metric will have immediately after the selected starting
-- economy is applied. Existing assets and land count; configured starting cash
-- changes cash, and configured debt changes the net-worth liability. Starting
-- cash is deliberately not treated as earned income.
function MFC.getProjectedStartMetricPublic(metric, startMoney, startDebt)
    if metric == "Income" then
        return 0
    elseif metric == "OwnFields" then
        return getOwnedFields()
    end

    local currentNetWorth = getNetWorth()
    local currentMoney = getMoney()
    local currentLoan = MFC.getLoanPublic()
    local targetMoney = tonumber(startMoney) or currentMoney
    local targetDebt = tonumber(startDebt) or currentLoan
    local assetEquity = currentNetWorth - currentMoney + currentLoan
    return assetEquity + targetMoney - targetDebt
end

-- Income: total money earned during the campaign, tracked by hooking addMoney
-- (positive amounts to the player's farm). Persisted in progress.xml.
MFC.earnedIncome = MFC.earnedIncome or 0

-- The live "Money earned" value, honouring the campaign's chosen mode:
--   "gross" (default): income received since the challenge began (spending does
--                      not reduce it) - the addMoney running total.
--   "net":             current cash minus the balance captured at the start,
--                      so it rises and falls with your actual bank balance.
-- Both are dynamic: they update continuously from the real starting point and
-- never depend on the mod forcing the player's balance.
function MFC.incomeValue()
    local c = MFC.campaign
    if c ~= nil and c.incomeMode == "net" then
        -- Until the starting balance is captured (setup still pending), there is
        -- no gain yet - report 0 rather than the whole current balance.
        if c.baselineMoney == nil then return 0 end
        return getMoney() - c.baselineMoney
    end
    return MFC.earnedIncome or 0
end

function MFC.getIncomePublic()
    return MFC.incomeValue()
end

local function installIncomeTracker()
    if MFC.incomeHookInstalled then return end
    guard("installIncomeTracker", function()
        if FSBaseMission == nil or FSBaseMission.addMoney == nil then
            log("WARN: FSBaseMission.addMoney not found; income goals inactive (VERIFY).")
            return
        end
        FSBaseMission.addMoney = Utils.appendedFunction(FSBaseMission.addMoney,
            function(mission, amount, farmId, ...)
                local ok = pcall(function()
                    if MFC.campaign == nil then return end
                    if (MFC.campaign.state or "active") ~= "active" then return end
                    -- Starting-money adjustments happen while save setup is
                    -- pending and must never count as income earned in the run.
                    if MFC.setupPending then return end
                    if type(amount) ~= "number" or amount <= 0 then return end
                    local farm = getFarm()
                    if farm ~= nil and farm.farmId ~= nil and farmId ~= nil and farmId ~= farm.farmId then
                        return
                    end
                    MFC.earnedIncome = (MFC.earnedIncome or 0) + amount
                end)
                if not ok then --[[ never break the money path ]] end
            end)
        MFC.incomeHookInstalled = true
        log("Income tracker installed.")
    end)
end

-- VERIFY: g_farmlandManager owned-farmland accessor
getOwnedFields = function()
    return guard("getOwnedFields", function()
        local farm = getFarm()
        if farm == nil or g_farmlandManager == nil then return 0 end
        local count = 0
        local owned = g_farmlandManager:getOwnedFarmlandIdsByFarmId(farm.farmId)
        if owned ~= nil then
            for _ in pairs(owned) do count = count + 1 end
        end
        return count
    end, 0)
end

-- Public accessor (must be defined after the local it calls).
function MFC.getOwnedFieldsPublic()
    return getOwnedFields()
end

-- Capture a starting snapshot for reports and save compatibility. Challenge
-- conditions themselves use the farm's absolute values, so everything already
-- owned remains part of the challenge progress.
function MFC.captureBaselines()
    local c = MFC.campaign
    if c == nil or c.baselineCaptured == true then return end
    c.baselineNetWorth = getNetWorth()
    c.baselineFields = getOwnedFields()
    c.baselineMoney = getMoney()
    c.baselineCaptured = true
    c.repNetWorth = c.baselineNetWorth
    c.repFields = c.baselineFields
    MFC.writeCampaign(c)
    log(string.format("Challenge starting snapshot captured: net worth %.0f, fields %d.",
        c.baselineNetWorth or 0, c.baselineFields or 0))
end

local function challengeNetWorth(rawValue)
    return math.max(0, rawValue or getNetWorth())
end

local function challengeFields(rawValue)
    return math.max(0, rawValue or getOwnedFields())
end


-- VERIFY: environment day/period accessors
local function getGameDate()
    local y = guard("getGameDate", function()
        local env = g_currentMission and g_currentMission.environment
        if env == nil then return 1 end
        local day = env.currentDay or 1
        return math.max(1, math.floor((day - 1) / 365) + 1)
    end, 1)
    local q = guard("getGameQuarter", function()
        local env = g_currentMission and g_currentMission.environment
        if env == nil then return 1 end
        local period = env.currentPeriod or 1
        return math.max(1, math.min(4, math.ceil(period / 3)))
    end, 1)
    return y, q
end

-- ============================================================
-- Restriction enforcement (all VERIFY-tagged, all guarded)
-- ============================================================

function MFC.notify(msg)
    guard("notify", function()
        if g_currentMission ~= nil and g_currentMission.addIngameNotification ~= nil then
            g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_OK, msg)
        end
    end)
end

local function installWorkerBlock()
    -- Self-gating: install once, check the restriction live, so challenges
    -- started from the in-game tab enforce immediately and a later campaign
    -- without the rule isn't stuck with it.
    if MFC.workerHookInstalled then return end
    guard("installWorkerBlock", function()
        if g_currentMission ~= nil and g_currentMission.aiSystem ~= nil
            and g_currentMission.aiSystem.startJob ~= nil then
            g_currentMission.aiSystem.startJob = Utils.overwrittenFunction(
                g_currentMission.aiSystem.startJob,
                function(self, superFunc, ...)
                    if isRestricted("noWorkers") then
                        MFC.notify("Workers are disabled for this challenge.")
                        return nil
                    end
                    return superFunc(self, ...)
                end)
            MFC.workerHookInstalled = true
            log("Worker hook installed (active only when noWorkers is set).")
        else
            log("WARN: aiSystem.startJob not found; worker block inactive (VERIFY).")
        end
    end)
end

-- Contract machines block. Confirmed approach from FS25_DisableContractMachines:
-- override AbstractFieldMission.hasLeasableVehicles to return false, so contracts
-- stay available but you must use your own equipment. Self-gates live.
local function installContractMachineBlock()
    if MFC.contractMachineHookInstalled then return end
    guard("installContractMachineBlock", function()
        if AbstractFieldMission ~= nil and AbstractFieldMission.hasLeasableVehicles ~= nil then
            AbstractFieldMission.hasLeasableVehicles = Utils.overwrittenFunction(
                AbstractFieldMission.hasLeasableVehicles,
                function(self, superFunc, ...)
                    if isRestricted("noContractMachines") then return false end
                    return superFunc(self, ...)
                end)
            MFC.contractMachineHookInstalled = true
            log("Contract-machine hook installed (active only when noContractMachines is set).")
        else
            log("WARN: AbstractFieldMission.hasLeasableVehicles not found; contract-machine block inactive (VERIFY).")
        end
    end)
end

-- Loan cap. Confirmed approach from FS25_NoCredit: clamp Farm.MIN_LOAN and
-- Farm.MAX_LOAN to 0. Stateful, applied both directions so a later campaign
-- without the rule gets normal loans back.
local function applyLoanCap()
    guard("applyLoanCap", function()
        if Farm == nil then
            log("WARN: Farm class not found; loan block inactive (VERIFY).")
            return
        end
        if MFC.origMinLoan == nil then
            MFC.origMinLoan = Farm.MIN_LOAN or 0
            MFC.origMaxLoan = Farm.MAX_LOAN or 0
        end
        if isRestricted("noLoans") then
            Farm.MIN_LOAN = 0
            Farm.MAX_LOAN = 0
        else
            Farm.MIN_LOAN = MFC.origMinLoan
            Farm.MAX_LOAN = MFC.origMaxLoan
        end
    end)
end

-- Steering-assist / GPS block. Confirmed API (from FS25_BuyableGPS, which
-- gates the same feature): AIAutomaticSteering.getIsAutomaticSteeringAllowed
-- is the real gate the game queries. Both mods chain via overwrittenFunction
-- and only ever force false, so they compose in either load order.
local function installSteeringAssistBlock()
    if MFC.steeringHookInstalled then return end
    guard("installSteeringAssistBlock", function()
        if AIAutomaticSteering == nil or AIAutomaticSteering.getIsAutomaticSteeringAllowed == nil then
            log("WARN: AIAutomaticSteering.getIsAutomaticSteeringAllowed not found yet; will retry at map load (VERIFY).")
            return
        end
        AIAutomaticSteering.getIsAutomaticSteeringAllowed = Utils.overwrittenFunction(
            AIAutomaticSteering.getIsAutomaticSteeringAllowed,
            function(spec, superFunc, ...)
                local allowed = superFunc(spec, ...)
                if allowed == true and isRestricted("manualOnly") then
                    return false
                end
                return allowed
            end)
        MFC.steeringHookInstalled = true
        log("Steering-assist hook installed via getIsAutomaticSteeringAllowed (active only when manualOnly is set).")
    end)
end

-- Apply all restriction state for the current campaign. Called at map load and
-- again whenever a challenge is started from the in-game tab, so rules take
-- effect immediately without a restart.
function MFC.applyRestrictions()
    installWorkerBlock()
    installContractMachineBlock()
    installSteeringAssistBlock()
    installIncomeTracker()
    applyLoanCap()
    guard("teleportToggleState", function()
        if g_currentMission ~= nil then
            g_currentMission.isToggleVehicleAllowed = not isRestricted("noTeleport")
        end
    end)
end

-- Shop enforcement, FS25-robust approach: instead of hooking a buy function
-- (whose name varies), we periodically scan the farm's owned/leased vehicles
-- and reverse anything that violates the rules. Confirmed API: vehicleSystem
-- .vehicles, vehicle:getOwnerFarmId(), vehicle:getPropertyState(),
-- VehiclePropertyState.LEASED.
local function vehicleBrand(v)
    return guard("vehicleBrand", function()
        local storeItem = v.getStoreItem and v:getStoreItem()
        if storeItem == nil then return nil end
        return tostring(storeItem.brandNameRaw or storeItem.brand or ""):upper()
    end, nil)
end

local function vehicleCategory(v)
    return guard("vehicleCategory", function()
        local storeItem = v.getStoreItem and v:getStoreItem()
        if storeItem == nil then return nil end
        return storeItem.categoryName or storeItem.category
    end, nil)
end

-- Is this vehicle a tractor? VERIFY category name; FS25 uses store categories
-- like "tractorsS/M/L". We match any category containing "tractor".
local function isTractor(v)
    return guard("isTractor", function()
        local storeItem = v.getStoreItem and v:getStoreItem()
        if storeItem == nil then return false end
        local cat = tostring(storeItem.categoryName or storeItem.category or ""):lower()
        return cat:find("tractor") ~= nil
    end, false)
end

local function vehicleViolates(v, isLeased)
    if MFC.campaign == nil then return false, nil end
    if isLeased and isRestricted("noLeasing") then
        return true, "Leasing is disabled for this challenge."
    end
    -- Tractor-brand restriction: only tractors are checked. Everything else is
    -- always allowed, so the game stays playable.
    if MFC.campaign.brandMode == "tractorAllow" and isTractor(v) then
        local brand = vehicleBrand(v)
        if brand ~= nil and brand ~= "" then
            if MFC.campaign.brandSet[brand] ~= true then
                local allowed = MFC.campaign.brandListStr or "the allowed brands"
                return true, string.format("Tractors must be %s for this challenge.", allowed)
            end
        end
    end
    return false, nil
end

-- Remove a violating vehicle and refund its full price, so a wrong-brand
-- purchase behaves like a blocked purchase (appears briefly, vanishes, money
-- returned in full). VERIFY: getPrice / sellVehicle names.
local function refundAndRemove(v)
    guard("refundAndRemove", function()
        local farm = getFarm()
        local price = 0
        if v.getPrice ~= nil then
            local ok, p = pcall(function() return v:getPrice() end)
            if ok and p then price = p end
        end
        -- Remove the vehicle.
        if g_currentMission ~= nil and g_currentMission.removeVehicle ~= nil then
            g_currentMission:removeVehicle(v)
        elseif g_currentMission ~= nil and g_currentMission.sellVehicle ~= nil then
            g_currentMission:sellVehicle(v)
        elseif v.delete ~= nil then
            v:delete()
        end
        -- Refund the full price (sellVehicle may already credit part; refunding
        -- the difference keeps it whole without double-paying). We add the price
        -- back and rely on the wrong-brand case being rare enough that exactness
        -- matters less than the purchase not sticking.
        if farm ~= nil and price > 0 and g_currentMission ~= nil and g_currentMission.addMoney ~= nil then
            g_currentMission:addMoney(price, farm.farmId, MoneyType.OTHER, true, true)
        end
    end)
end

-- Scan owned vehicles and reverse violations. Tracks which vehicles we've
-- already OK'd so we don't re-scan everything every tick.
MFC.scannedVehicles = MFC.scannedVehicles or {}
local function scanShopViolations()
    if MFC.campaign == nil then return end
    local needed = isRestricted("noLeasing")
        or MFC.campaign.brandMode ~= "none"

    if not needed then return end

    guard("scanShopViolations", function()
        local farm = getFarm()
        if farm == nil then return end
        local vs = g_currentMission and g_currentMission.vehicleSystem
        local list = vs and vs.vehicles
        if type(list) ~= "table" then return end

        for _, v in pairs(list) do
            if type(v) == "table" and v.getOwnerFarmId ~= nil then
                local ok, owner = pcall(function() return v:getOwnerFarmId() end)
                local id = tostring(v)
                if ok and owner == farm.farmId and not MFC.scannedVehicles[id] then
                    local isLeased = false
                    if v.getPropertyState ~= nil then
                        local ok2, st = pcall(function() return v:getPropertyState() end)
                        isLeased = ok2 and st == VehiclePropertyState.LEASED
                    end
                    local bad, msg = vehicleViolates(v, isLeased)
                    if bad then
                        MFC.notify(msg)
                        refundAndRemove(v)
                    else
                        MFC.scannedVehicles[id] = true
                    end
                end
            end
        end
    end)
end

-- Teleport / fast travel: block the action input. VERIFY the action name; the
-- Tardis mod registers against player action events, so the fast-travel action
-- exists as an input binding we can intercept.
-- Teleport / fast-travel block. Uses the confirmed approach from FS25_NoTeleport:
-- override the hotspot "getBeVisited" methods and Enterable.getIsEnterableFromMenu
-- so the game won't let you visit/teleport, plus disable vehicle toggle-teleport
-- and the map's "visit place" action. The class-method overrides are installed
-- once and check the restriction live, so they only bite when noTeleport is on.
local function teleportBlockActive()
    return MFC.campaign ~= nil and isRestricted("noTeleport")
end

local function installTeleportClassHooks()
    if MFC.teleportHooksInstalled then return end
    guard("installTeleportClassHooks", function()
        local function deny(self, superFunc, ...)
            if teleportBlockActive() then
                return false
            end
            return superFunc(self, ...)
        end

        if PlaceableHotspot ~= nil and PlaceableHotspot.getBeVisited ~= nil then
            PlaceableHotspot.getBeVisited = Utils.overwrittenFunction(PlaceableHotspot.getBeVisited, deny)
        end
        if NPCHotspot ~= nil and NPCHotspot.getBeVisited ~= nil then
            NPCHotspot.getBeVisited = Utils.overwrittenFunction(NPCHotspot.getBeVisited, deny)
        end
        if FerryHotspot ~= nil and FerryHotspot.getBeVisited ~= nil then
            FerryHotspot.getBeVisited = Utils.overwrittenFunction(FerryHotspot.getBeVisited, deny)
        end
        if Enterable ~= nil and Enterable.getIsEnterableFromMenu ~= nil then
            Enterable.getIsEnterableFromMenu = Utils.overwrittenFunction(Enterable.getIsEnterableFromMenu, deny)
        end

        -- Disable the map's "visit place" context action when active.
        if InGameMenuMapFrame ~= nil and InGameMenuMapFrame.setMapInputContext ~= nil
            and InGameMenuMapFrame.ACTIONS ~= nil and InGameMenuMapFrame.ACTIONS.VISIT_PLACE ~= nil then
            InGameMenuMapFrame.setMapInputContext = Utils.appendedFunction(
                InGameMenuMapFrame.setMapInputContext,
                function(mapFrame)
                    if teleportBlockActive() and mapFrame.contextActions ~= nil then
                        local act = mapFrame.contextActions[InGameMenuMapFrame.ACTIONS.VISIT_PLACE]
                        if act ~= nil then
                            act.isActive = false
                            if mapFrame.updateContextInputBarVisibility ~= nil then
                                mapFrame:updateContextInputBarVisibility()
                            end
                        end
                    end
                end)
        end

        MFC.teleportHooksInstalled = true
        log("Teleport hooks installed (active only when noTeleport is set).")
    end)
end

-- (Vehicle toggle-teleport state is set in MFC.applyRestrictions, both
-- directions, so switching campaigns in-session behaves correctly.)

-- ============================================================
-- Progress writeback
-- ============================================================

local function checkMilestones(netWorth, fields, income)
    if MFC.campaign == nil then return end
    for _, m in ipairs(MFC.campaign.milestones) do
        if not m.completed then
            local metric = m.metric or m.kind
            local current
            if metric == "OwnFields" then
                current = fields
            elseif metric == "Income" then
                current = income
            else
                current = netWorth
            end
            if current >= m.target then
                m.completed = true
                MFC.notify(string.format("Milestone complete: %s", m.title))
                log(string.format("Milestone %d complete: %s", m.order, m.title))
            end
        end
    end
end

-- Evaluate the challenge: milestone completion, missed flags, win/fail
-- transitions. Runs every second from the update loop so completion lands the
-- moment a target is crossed (the page shows live percentages; the judge must
-- keep the same pace). Persistence stays on the slower writeProgress cadence.
function MFC.evaluateChallenge()
    if MFC.campaign == nil then return end
    guard("evaluateChallenge", function()
        local netWorth = getNetWorth()
        local money = getMoney()
        local fields = getOwnedFields()
        local year, quarter = getGameDate()

        local c = MFC.campaign

        -- Never judge conditions until save setup has applied the configured
        -- starting economy. The setup page guarantees every selected target is
        -- above the value the farm will have at this point.
        if MFC.setupPending then
            return
        end
        if c.baselineCaptured ~= true then
            MFC.captureBaselines()
        end

        local netWorthProgress = challengeNetWorth(netWorth)
        local fieldsProgress = challengeFields(fields)
        checkMilestones(netWorthProgress, fieldsProgress, MFC.incomeValue())

        -- ---- Challenge lifecycle ----
        -- Anchor the clock the first time we see this campaign in a live game
        -- (also covers campaigns created before startYear existed).
        if c.startYear == nil then
            c.startYear = year
            MFC.writeCampaign(c)
        end
        local elapsed = math.max(0, year - c.startYear)
        MFC.challengeYear = elapsed + 1

        -- Missed markers: display-only, recomputed only while the run is live.
        if (c.state or "active") == "active" then
            for _, m in ipairs(c.milestones) do
                m.missed = (not m.completed) and ((elapsed + 1) > (m.dueYear or math.huge))
            end
        end

        if (c.state or "active") == "active" then
            local finalDone = false
            local goalMetric = "NetWorth"
            for _, m in ipairs(c.milestones) do
                if m.kind == "FinalGoal" then
                    goalMetric = m.metric or "NetWorth"
                    if m.completed then finalDone = true end
                end
            end
            local goalValueNow = netWorthProgress
            if goalMetric == "OwnFields" then goalValueNow = fieldsProgress
            elseif goalMetric == "Income" then goalValueNow = MFC.incomeValue() end
            if finalDone then
                c.state = "won"
                c.celebrated = false
                c.endYearsUsed = elapsed + 1
                c.endGoalValue = goalValueNow
                MFC.writeCampaign(c)
                MFC.applyRestrictions() -- lift the rules; you earned it
                        log(string.format("Challenge WON: %s (year %d of %d). Celebration pending.", c.name or "?", elapsed + 1, c.years or 0))
            elseif elapsed >= (c.years or 1) then
                c.state = "failed"
                c.celebrated = false
                c.endYearsUsed = elapsed + 1
                c.endGoalValue = goalValueNow
                MFC.writeCampaign(c)
                MFC.applyRestrictions()
                        log(string.format("Challenge FAILED (time limit): %s. Notice pending.", c.name or "?"))
            end
        end
        -- ---- end lifecycle ----
    end)
end

function MFC.writeProgress()
    if MFC.campaign == nil then return end
    MFC.evaluateChallenge()
    guard("writeProgress", function()
        if MFC.setupPending then return end
        local netWorth = getNetWorth()
        local money = getMoney()
        local fields = getOwnedFields()
        local year, quarter = getGameDate()

        createFolder(MFC.SETTINGS_DIR)
        createFolder(MFC.saveDir())
        local xml = XMLFile.create("MFCProgress", MFC.progressFile(), "progress")
        if xml == nil then return end
        xml:setInt("progress#seed", MFC.campaign.seed)
        xml:setFloat("progress#netWorth", netWorth)
        xml:setFloat("progress#money", money)
        xml:setInt("progress#ownedFields", fields)
        xml:setFloat("progress#earnedIncome", MFC.earnedIncome or 0)
        xml:setFloat("progress#netWorthGrowth", challengeNetWorth(netWorth))
        xml:setInt("progress#fieldsAcquired", challengeFields(fields))
        if MFC.campaign.baselineNetWorth ~= nil then
            xml:setFloat("progress#baselineNetWorth", MFC.campaign.baselineNetWorth)
        end
        if MFC.campaign.baselineFields ~= nil then
            xml:setInt("progress#baselineFields", MFC.campaign.baselineFields)
        end
        xml:setInt("progress#year", year)
        xml:setInt("progress#quarter", quarter)

        local idx = 0
        for _, m in ipairs(MFC.campaign.milestones) do
            if m.completed then
                xml:setInt(string.format("progress.completed.milestone(%d)#order", idx), m.order)
                idx = idx + 1
            end
        end
        xml:save()
        xml:delete()
    end)
end

-- Metric value for the menu/HUD. Net worth and fields are absolute so existing
-- farm progress counts. Income remains money genuinely earned after starting.
function MFC.getChallengeMetricPublic(metric)
    if MFC.campaign == nil then return 0 end
    if metric == "Income" then
        return MFC.incomeValue()
    elseif metric == "OwnFields" then
        return getOwnedFields()
    end
    return getNetWorth()
end

-- Current challenge year (1-based) for the menu display.
function MFC.getChallengeYearPublic()
    return MFC.challengeYear or 1
end

-- Challenge history: per-save history.xml, appended on win/fail/abandon.
function MFC.appendHistory(c, result)
    guard("appendHistory", function()
        if c == nil then return end
        local entries = MFC.readHistory() or {}
        local goalMetric, goalTarget = "NetWorth", 0
        for _, m in ipairs(c.milestones or {}) do
            if m.kind == "FinalGoal" then
                goalMetric = m.metric or "NetWorth"
                goalTarget = m.target or 0
            end
        end
        local dateStr = ""
        pcall(function() dateStr = getDate("%d.%m.%Y") or "" end)
        table.insert(entries, 1, {
            name = c.name or "Challenge", difficulty = c.difficulty or "",
            result = result or "?", yearsUsed = MFC.challengeYear or 1,
            yearsTotal = c.years or 0, metric = goalMetric,
            target = goalTarget, date = dateStr,
            earned = MFC.incomeValue(),
        })
        createFolder(MFC.SETTINGS_DIR)
        createFolder(MFC.saveDir())
        local xml = XMLFile.create("MFCHistoryW", MFC.saveDir() .. "history.xml", "history")
        if xml == nil then return end
        for i, e in ipairs(entries) do
            if i > 20 then break end
            local k = string.format("history.run(%d)", i - 1)
            xml:setString(k .. "#name", e.name)
            xml:setString(k .. "#difficulty", e.difficulty)
            xml:setString(k .. "#result", e.result)
            xml:setInt(k .. "#yearsUsed", e.yearsUsed or 1)
            xml:setInt(k .. "#yearsTotal", e.yearsTotal or 0)
            xml:setString(k .. "#metric", e.metric)
            xml:setFloat(k .. "#target", e.target or 0)
            xml:setString(k .. "#date", e.date or "")
            xml:setFloat(k .. "#earned", e.earned or 0)
        end
        xml:save()
        xml:delete()
        log(string.format("History: recorded '%s' as %s.", c.name or "?", result or "?"))
    end)
end

function MFC.readHistory()
    return guard("readHistory", function()
        local path = MFC.saveDir() .. "history.xml"
        if not fileExists(path) then return {} end
        local xml = XMLFile.load("MFCHistoryR", path)
        if xml == nil then return {} end
        local entries = {}
        local i = 0
        while true do
            local k = string.format("history.run(%d)", i)
            if not xml:hasProperty(k) then break end
            table.insert(entries, {
                name = xml:getString(k .. "#name") or "Challenge",
                difficulty = xml:getString(k .. "#difficulty") or "",
                result = xml:getString(k .. "#result") or "?",
                yearsUsed = xml:getInt(k .. "#yearsUsed") or 1,
                yearsTotal = xml:getInt(k .. "#yearsTotal") or 0,
                metric = xml:getString(k .. "#metric") or "NetWorth",
                target = xml:getFloat(k .. "#target") or 0,
                date = xml:getString(k .. "#date") or "",
                earned = xml:getFloat(k .. "#earned") or 0,
            })
            i = i + 1
        end
        xml:delete()
        return entries
    end, {})
end

function MFC.getHistoryPublic(n)
    local entries = MFC.readHistory() or {}
    local out = {}
    for i = 1, math.min(n or 4, #entries) do out[i] = entries[i] end
    return out
end

-- Remove challenge data for this save slot. deleteFile may be unavailable or
-- refused, so verify and fall back to overwriting with an abandoned tombstone
-- (which loadCampaign treats as no challenge).
function MFC.clearChallengeFiles(alsoHistory)
    guard("clearChallengeFiles", function()
        local function nuke(path, root)
            if not fileExists(path) then return end
            pcall(function()
                if deleteFile ~= nil then deleteFile(path) end
            end)
            if fileExists(path) then
                local xml = XMLFile.create("MFCTomb", path, root)
                if xml ~= nil then
                    xml:setBool(root .. "#abandoned", true)
                    xml:save()
                    xml:delete()
                end
                log(string.format("Cleared %s via tombstone (deleteFile unavailable).", path))
            else
                log(string.format("Deleted %s.", path))
            end
        end
        nuke(MFC.challengeFile(), "challenge")
        nuke(MFC.progressFile(), "progress")
        if alsoHistory then
            nuke(MFC.saveDir() .. "history.xml", "history")
        end
    end)
end

-- Abandon the active challenge: remove its files for this save, clear state,
-- and reset all restriction side-effects (loan caps, teleport flag).
function MFC.abandonCampaign()
    guard("abandonCampaign", function()
        local name = MFC.campaign and MFC.campaign.name or "?"
        local wasActive = MFC.campaign ~= nil and (MFC.campaign.state or "active") == "active"
        MFC.clearChallengeFiles(false)
        MFC.campaign = nil
        MFC.earnedIncome = 0
        MFC.applyRestrictions()
        MFC.notify(wasActive and "Challenge abandoned." or "Result cleared.")
        log(string.format("%s: %s.", wasActive and "Challenge abandoned" or "Result cleared", name))
    end)
end

-- ============================================================
-- In-menu challenge page (Esc menu tab)
-- ============================================================
-- Injection follows the proven FS25_ImprovedControlsMenu pattern: manually
-- insert into g_inGameMenu.pagingElement, reorder the parallel arrays, then
-- registerPage + addPageTab + rebuildTabList. Fully guarded: any failure
-- disables the page and logs, leaving the pause menu intact.
local function installMenuPage()
    if MFC.menuPageInstalled then return end

    local ok, err = pcall(function()
        if g_gui == nil or g_inGameMenu == nil then
            log("WARN: g_gui or g_inGameMenu unavailable; menu page skipped.")
            return
        end
        if MFC_MenuPage == nil then
            log("WARN: MFC_MenuPage class missing; menu page skipped.")
            return
        end

        -- Build the frame and load its GUI layout.
        local frame = MFC_MenuPage.new()
        frame.customEnvironment = MFC.MOD_NAME
        -- Register our GUI profiles (invisible container, shifted controls)
        -- before the page XML references them. AutoDrive-confirmed API.
        guard("loadGuiProfiles", function()
            g_gui:loadProfiles(MFC.MOD_DIR .. "gui/guiProfiles.xml")
        end)
        g_gui:loadGui(MFC.MOD_DIR .. "gui/MFC_MenuPage.xml", "MFC_MenuPage", frame, true)

        local pageName = "mfcChallengePage"
        local insertAfter = "pageStatistics" -- put our tab near statistics

        g_inGameMenu.controlIDs[pageName] = nil

        -- Find insertion position (after the statistics page if present).
        local targetPosition = #g_inGameMenu.pagingElement.elements + 1
        for i = 1, #g_inGameMenu.pagingElement.elements do
            if g_inGameMenu.pagingElement.elements[i] == g_inGameMenu[insertAfter] then
                targetPosition = i + 1
                break
            end
        end

        g_inGameMenu[pageName] = frame
        g_inGameMenu.pagingElement:addElement(g_inGameMenu[pageName])
        g_inGameMenu:exposeControlsAsFields(pageName)

        -- Reorder element/pages arrays to the target position.
        local function reorder(list, matchField)
            for i = 1, #list do
                local item = list[i]
                local el = (matchField == nil) and item or item.element
                if el == g_inGameMenu[pageName] then
                    table.remove(list, i)
                    table.insert(list, targetPosition, item)
                    break
                end
            end
        end
        reorder(g_inGameMenu.pagingElement.elements, nil)
        reorder(g_inGameMenu.pagingElement.pages, "element")

        g_inGameMenu.pagingElement:updateAbsolutePosition()
        g_inGameMenu.pagingElement:updatePageMapping()

        g_inGameMenu:registerPage(g_inGameMenu[pageName], nil, function() return true end)

        local iconFile = Utils.getFilename("tab_mfc.dds", MFC.MOD_DIR)
        g_inGameMenu:addPageTab(g_inGameMenu[pageName], iconFile, GuiUtils.getUVs({0, 0, 256, 256}, {256, 256}))

        if g_inGameMenu.pageFrames ~= nil then
            reorder(g_inGameMenu.pageFrames, nil)
        end

        g_inGameMenu:rebuildTabList()

        MFC.menuPageInstalled = true
        MFC.menuPage = frame
        log("Menu page installed.")
    end)

    if not ok then
        if not MFC.menuPageErrLogged then
            MFC.menuPageErrLogged = true
            log("WARN: menu page install failed (pause menu unaffected): " .. tostring(err))
        end
    end
end

-- ============================================================
-- Lifecycle wiring
-- ============================================================

-- Restore progress from a previous session: earned income and completed
-- milestone flags (matched by order, only for the same campaign seed).
function MFC.readProgress()
    if MFC.campaign == nil then return end
    guard("readProgress", function()
        if not fileExists(MFC.progressFile()) then return end
        local xml = XMLFile.load("MFCProgressR", MFC.progressFile())
        if xml == nil then return end
        if (xml:getInt("progress#seed") or -1) == (MFC.campaign.seed or 0) then
            MFC.earnedIncome = xml:getFloat("progress#earnedIncome") or 0
            local done = {}
            local idx = 0
            while true do
                local key = string.format("progress.completed.milestone(%d)", idx)
                if not xml:hasProperty(key) then break end
                local order = xml:getInt(key .. "#order")
                if order ~= nil then done[order] = true end
                idx = idx + 1
            end
            for _, m in ipairs(MFC.campaign.milestones or {}) do
                if done[m.order] then m.completed = true end
            end
        else
            -- Different campaign than last session's progress: start income fresh.
            MFC.earnedIncome = 0
        end
        xml:delete()
    end)
end

-- One-time migration from the pre-0.16 global challenge file. Only the save
-- that was actually configured for that campaign (setup flag matches this
-- savegame index + the campaign seed) adopts it; other saves ignore it.
local function migrateLegacyChallenge()
    guard("migrateLegacy", function()
        if fileExists(MFC.challengeFile()) then return end
        if not fileExists(MFC.LEGACY_CHALLENGE_FILE) then return end
        local xml = XMLFile.load("MFCLegacy", MFC.LEGACY_CHALLENGE_FILE)
        if xml == nil then return end
        local seed = xml:getInt("challenge#seed") or 0
        xml:delete()
        local info = g_currentMission and g_currentMission.missionInfo
        local idx = tostring((info and info.savegameIndex) or "unknown")
        local flag = string.format("%sconfigured_save_%s_%s.flag", MFC.SETTINGS_DIR, idx, tostring(seed))
        if not fileExists(flag) then
            log("Legacy global challenge found but it belongs to another save; ignoring here.")
            return
        end
        createFolder(MFC.saveDir())
        local function moveFile(src, dst)
            local fi = io.open(src, "rb")
            if fi == nil then return end
            local data = fi:read("*a")
            fi:close()
            if data == nil then return end
            local fo = io.open(dst, "wb")
            if fo == nil then return end
            fo:write(data)
            fo:close()
            if deleteFile ~= nil then pcall(deleteFile, src) end
        end
        moveFile(MFC.LEGACY_CHALLENGE_FILE, MFC.challengeFile())
        moveFile(MFC.LEGACY_PROGRESS_FILE, MFC.progressFile())
        log("Migrated legacy challenge into per-save storage (save " .. idx .. ").")
    end)
end

local function onMapLoaded()
    -- Multiplayer: the challenge system is singleplayer by design. In MP we
    -- stay fully dormant (no tab, no campaign, all self-gating hooks inert)
    -- rather than half-working.
    local dyn = g_currentMission and g_currentMission.missionDynamicInfo
    if dyn ~= nil and dyn.isMultiplayer == true then
        log("Multiplayer session detected; Farm Challenge is singleplayer-only and stays inactive.")
        return
    end

    -- A brand-new game reuses its slot's savegame index; challenge data in the
    -- folder belongs to the previous (dead) save. missionInfo.isValid is true
    -- only when an existing savegame was loaded from disk.
    guard("newGameStaleCheck", function()
        local info = g_currentMission and g_currentMission.missionInfo
        if info ~= nil and info.isValid == false and fileExists(MFC.challengeFile()) then
            log("New game detected in this slot; clearing stale challenge data.")
            MFC.clearChallengeFiles(true)
        end
    end)

    migrateLegacyChallenge()
    MFC.campaign = MFC.loadCampaign()
    -- Mark setup pending immediately so money events fired during map-load or
    -- restriction initialization cannot be mistaken for challenge income.
    MFC.setupPending = MFC.campaign ~= nil

    -- Always: the tab must exist so a challenge can be created on any save, and
    -- restrictions must be applied (or reset to defaults when this save has no
    -- challenge, e.g. after switching saves within one session).
    MFC.applyRestrictions()
    installMenuPage()

    if MFC.campaign == nil then return end
    MFC.readProgress()

    -- Save setup needs the farm, which may not exist yet at map-load time. It
    -- was flagged above and will run on the update loop until the farm resolves.
    MFC.writeProgress()
end
FSBaseMission.loadMapFinished = Utils.appendedFunction(FSBaseMission.loadMapFinished, onMapLoaded)

-- Deferred celebration: retried from the update loop until the player is
-- actually looking (mission running, no GUI open). Fixes end-of-challenge
-- popups firing invisibly during loading screens or menus and being lost.
function MFC.celebrateIfPending()
    guard("celebrateIfPending", function()
        local c = MFC.campaign
        if c == nil or c.celebrated == true then return end
        local state = c.state or "active"
        if state ~= "won" and state ~= "failed" then return end
        if g_currentMission == nil or g_currentMission.isMissionStarted == false then return end
        if g_gui ~= nil and g_gui.getIsGuiVisible ~= nil and g_gui:getIsGuiVisible() then return end

        c.celebrated = true
        MFC.writeCampaign(c)

        if state == "won" then
            MFC.notify(string.format("CHALLENGE COMPLETE: %s!", c.name or "Challenge"))
            pcall(function()
                if InfoDialog == nil or InfoDialog.show == nil then return end
                local done, total = 0, 0
                for _, m in ipairs(c.milestones or {}) do
                    total = total + 1
                    if m.completed then done = done + 1 end
                end
                local ruleCount = 0
                for _ in pairs(c.restrictions or {}) do ruleCount = ruleCount + 1 end
                local netWorth = getNetWorth()
                local fields = getOwnedFields()
                local lines = {
                    "CHALLENGE COMPLETE!",
                    "",
                    string.format("%s (%s)", c.name or "Challenge", c.difficulty or ""),
                    string.format("Finished in year %d of %d  -  %d/%d milestones",
                        c.endYearsUsed or (MFC.challengeYear or 1), c.years or 0, done, total),
                    string.format("Money earned:  %s",
                        g_i18n and g_i18n:formatMoney(MFC.incomeValue()) or tostring(MFC.incomeValue())),
                }
                if c.repNetWorth ~= nil then
                    table.insert(lines, string.format("Net worth:  %s  ->  %s",
                        g_i18n:formatMoney(c.repNetWorth), g_i18n:formatMoney(netWorth)))
                end
                if c.repFields ~= nil and fields ~= c.repFields then
                    table.insert(lines, string.format("Fields owned:  %d  ->  %d", c.repFields, fields))
                end
                if ruleCount > 0 then
                    table.insert(lines, string.format("Completed under %d restriction%s.",
                        ruleCount, ruleCount == 1 and "" or "s"))
                end
                InfoDialog.show(table.concat(lines, "\n"))
            end)
        else
            MFC.notify("Challenge failed - time limit reached.")
            pcall(function()
                if InfoDialog == nil or InfoDialog.show == nil then return end
                local dtype = (DialogElement ~= nil) and DialogElement.TYPE_WARNING or nil
                InfoDialog.show(string.format(
                    "Challenge failed.\n\n%s (%s)\nThe time limit of %d years was reached.",
                    c.name or "Challenge", c.difficulty or "", c.years or 0), nil, nil, dtype)
            end)
        end
        log("Challenge end shown to player (" .. state .. ").")
    end)
end

-- ============================================================
-- In-game HUD readout: two small text lines at top-center while a challenge is
-- active, hidden whenever any GUI is open. Text is cached once per second in
-- onUpdate; the draw hook only renders strings (never computes).
-- ============================================================
local function fmtShort(metric, v)
    v = v or 0
    if metric == "OwnFields" then
        return string.format("%d fields", math.floor(v))
    end
    local a = math.abs(v)
    if a >= 1000000 then return string.format("$%.2fM", v / 1000000) end
    if a >= 1000 then return string.format("$%dk", math.floor(v / 1000 + 0.5)) end
    return string.format("$%d", math.floor(v + 0.5))
end

local function metricShortLabel(metric)
    if metric == "OwnFields" then return "Fields" end
    if metric == "Income" then return "Earned" end
    return "Net worth"
end

function MFC.refreshHudCache()
    guard("refreshHudCache", function()
        local c = MFC.campaign
        if c == nil then MFC.hudLines = nil return end
        local state = c.state or "active"
        if state == "won" then
            MFC.hudLines = { string.format("Farm Challenge  -  %s  -  COMPLETE", c.name or "") }
            return
        elseif state == "failed" then
            MFC.hudLines = { string.format("Farm Challenge  -  %s  -  FAILED", c.name or "") }
            return
        end
        local goal, goalMetric = 0, "NetWorth"
        local nextLine = nil
        for _, m in ipairs(c.milestones or {}) do
            if m.kind == "FinalGoal" then
                goal = m.target or 0
                goalMetric = m.metric or "NetWorth"
            elseif nextLine == nil and not m.completed then
                local metric = m.metric or m.kind
                local cur = MFC.getChallengeMetricPublic(metric) or 0
                local mpct = (m.target or 0) > 0 and math.min(cur / m.target, 1) or 0
                nextLine = string.format("Next:  %s %s by year %d  (%d%%)",
                    metricShortLabel(metric), fmtShort(metric, m.target),
                    m.dueYear or 0, math.floor(mpct * 100 + 0.5))
            end
        end
        local current = MFC.getChallengeMetricPublic(goalMetric) or 0
        local pct = (goal > 0) and math.min(current / goal, 1) or 0
        MFC.hudLines = {
            string.format("Farm Challenge  %d%%  -  %s %s / %s  -  Year %d of %d",
                math.floor(pct * 100 + 0.5), metricShortLabel(goalMetric),
                fmtShort(goalMetric, current), fmtShort(goalMetric, goal),
                math.min(MFC.challengeYear or 1, c.years or 1), c.years or 0),
            nextLine,
        }
    end)
end

function MFC.onToggleHud()
    MFC.hudShown = not (MFC.hudShown ~= false)
    MFC.notify(MFC.hudShown and "Challenge HUD shown" or "Challenge HUD hidden")
end

FSBaseMission.draw = Utils.appendedFunction(FSBaseMission.draw, function()
    pcall(function()
        if MFC.hudShown == false then return end
        if MFC.campaign == nil or MFC.hudLines == nil then return end
        if g_gui ~= nil and g_gui.getIsGuiVisible ~= nil and g_gui:getIsGuiVisible() then return end
        setTextBold(false)
        setTextAlignment(RenderText.ALIGN_CENTER)
        setTextColor(1, 1, 1, 0.85)
        renderText(0.5, 0.972, 0.014, MFC.hudLines[1] or "")
        if MFC.hudLines[2] ~= nil then
            setTextColor(1, 1, 1, 0.6)
            renderText(0.5, 0.952, 0.012, MFC.hudLines[2])
        end
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextColor(1, 1, 1, 1)
    end)
end)

-- Note: the first arg of an appended FSBaseMission.update is the mission object
-- (self), NOT a numeric delta. Don't treat it as dt. The whole body is wrapped
-- in pcall: a per-frame error is catastrophic because it repeats every frame, so
-- we must never let one escape and spam the log / break the game.
local function onUpdate(_self)
    local ok, err = pcall(function()
        if MFC.campaign == nil then return end

        MFC.hudTicks = (MFC.hudTicks or 0) + 1
        if MFC.hudTicks >= 45 then -- roughly once per second
            MFC.hudTicks = 0
            MFC.evaluateChallenge()
            MFC.refreshHudCache()
            MFC.celebrateIfPending()
        end

        if MFC.setupPending and MFC_SaveSetup ~= nil then
            local done = MFC_SaveSetup.run(MFC.campaign, MFC.SETTINGS_DIR)
            if done then
                -- Capture the post-setup starting snapshot before evaluation.
                -- It is reporting data only; absolute farm values count toward
                -- net-worth and field conditions.
                MFC.captureBaselines()
                MFC.setupPending = false
                MFC.writeProgress()
            end
        end

        scanShopViolations()

        -- Menu page install is retried a bounded number of times (in case
        -- g_inGameMenu wasn't fully built at map-load time). Guarded + idempotent;
        -- stops retrying after a few attempts so a persistent failure can't spam.
        if not MFC.menuPageInstalled then
            MFC.menuPageAttempts = (MFC.menuPageAttempts or 0) + 1
            if MFC.menuPageAttempts <= 120 then
                installMenuPage()
            end
        end

        local env = g_currentMission and g_currentMission.environment
        local day = env and env.currentDay or 0
        if day ~= MFC.lastDayWritten then
            MFC.lastDayWritten = day
            MFC.writeProgress()
        end
    end)
    if not ok and not MFC.updateErrorLogged then
        MFC.updateErrorLogged = true -- log once, not every frame
        log("ERROR in update (suppressed after first): " .. tostring(err))
    end
end
FSBaseMission.update = Utils.appendedFunction(FSBaseMission.update, onUpdate)

-- Install teleport class-method overrides once, at load time (they must be
-- hooked before any hotspot is created; they self-gate on the restriction).
installTeleportClassHooks()

-- The steering-assist hook MUST install at script-load time: vehicle types copy
-- specialization functions into their own tables when types are finalized during
-- startup, so a map-load-time override of AIAutomaticSteering lands on a table
-- nobody consults anymore. FS25_BuyableGPS installs at load time for the same
-- reason. The wrapper self-gates on the live restriction, so early is safe.
installSteeringAssistBlock()

-- HUD toggle keybind: global player hotkeys must be registered inside
-- PlayerInputComponent.registerGlobalPlayerActionEvents, which the input system
-- re-runs on every context rebuild (vehicle enter/exit, menus). A one-shot
-- registration gets wiped at the first context switch. Courseplay-confirmed.
guard("installHudKeybindHook", function()
    if PlayerInputComponent == nil or PlayerInputComponent.registerGlobalPlayerActionEvents == nil then
        log("WARN: PlayerInputComponent.registerGlobalPlayerActionEvents not found; HUD keybind inactive (VERIFY).")
        return
    end
    PlayerInputComponent.registerGlobalPlayerActionEvents = Utils.overwrittenFunction(
        PlayerInputComponent.registerGlobalPlayerActionEvents,
        function(self, superFunc, ...)
            superFunc(self, ...)
            pcall(function()
                if InputAction == nil or InputAction.MFC_TOGGLE_HUD == nil then
                    if not MFC.hudKeybindWarned then
                        MFC.hudKeybindWarned = true
                        log("WARN: MFC_TOGGLE_HUD action missing (modDesc schema?); HUD keybind inactive (VERIFY).")
                    end
                    return
                end
                local ok, id = g_inputBinding:registerActionEvent(
                    InputAction.MFC_TOGGLE_HUD, MFC, MFC.onToggleHud, false, true, false, true)
                if ok and id ~= nil then
                    g_inputBinding:setActionEventTextVisibility(id, false)
                end
            end)
        end)
    log("HUD keybind hook installed (registers with player input context).")
end)

-- When the GPS rule makes steering assist unavailable, the AI Settings dialog's
-- own controller-focus init fails (pad dead until mouse hover). Repair it: we
-- append AISettingsDialog.show, so we run after the dialog's focus handling and
-- can take focus deterministically. Also re-sync modeElement.numTexts, since
-- other mods (e.g. BuyableGPS) call setTexts on it without updating numTexts,
-- which breaks controller cycling on that element.
guard("installAIDialogFocusFix", function()
    if AISettingsDialog == nil or AISettingsDialog.show == nil then
        log("WARN: AISettingsDialog.show not found; AI dialog focus fix inactive (VERIFY).")
        return
    end
    AISettingsDialog.show = Utils.appendedFunction(AISettingsDialog.show, function(...)
        pcall(function()
            local dlg = AISettingsDialog.INSTANCE
            if dlg == nil or dlg.modeElement == nil then return end
            if dlg.modeElement.texts ~= nil then
                dlg.modeElement.numTexts = #dlg.modeElement.texts
            end
            if isRestricted("manualOnly") and FocusManager ~= nil and FocusManager.setFocus ~= nil then
                FocusManager:setFocus(dlg.modeElement)
            end
        end)
    end)
    log("AI dialog focus fix installed.")
end)

-- Leasing block. Confirmed approach from FS25_DisableLeasing: prepend
-- ShopConfigScreen.updateButtons and clear storeItem.allowLeasing, which removes
-- the lease option in the shop. Self-gates on the noLeasing restriction.
if ShopConfigScreen ~= nil and ShopConfigScreen.updateButtons ~= nil then
    ShopConfigScreen.updateButtons = Utils.prependedFunction(
        ShopConfigScreen.updateButtons,
        function(self, storeItem, vehicle, saleItem)
            if MFC.campaign ~= nil and isRestricted("noLeasing") and storeItem ~= nil then
                storeItem.allowLeasing = false
            end
        end)
    log("Leasing hook installed (active only when noLeasing is set).")
else
    log("WARN: ShopConfigScreen.updateButtons not found; leasing block inactive.")
end

log("Mod loaded. Settings dir: " .. MFC.SETTINGS_DIR)
