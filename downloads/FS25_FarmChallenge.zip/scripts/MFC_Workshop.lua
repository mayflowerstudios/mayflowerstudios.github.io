--
-- MFC_Workshop.lua
--
-- The premade challenges offered by the "Premade or custom" row on the Farm
-- Challenge page.
--
-- They are read-only templates: the page copies values out of them into the
-- editor and never writes back, so a premade you load and then modify can't
-- damage the original.
--
-- Targets here are absolute figures. The editor raises any target sitting below
-- the player's current farm value, so a premade loaded onto a large farm stays
-- a challenge instead of completing instantly.
--

MFC_Workshop = {}
local W = MFC_Workshop

local function trim(value)
    return (tostring(value or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

local function cloneMap(source)
    local out = {}
    for key, value in pairs(source or {}) do
        if value == true then out[tostring(key)] = true end
    end
    return out
end

local function cloneMilestones(source)
    local out = {}
    for index, m in ipairs(source or {}) do
        table.insert(out, {
            order = tonumber(m.order) or index,
            kind = tostring(m.kind or "NetWorth"),
            metric = tostring(m.metric or m.kind or "NetWorth"),
            target = tonumber(m.target) or 0,
            title = tostring(m.title or ""),
            dueYear = math.max(1, tonumber(m.dueYear) or 1),
            dueQuarter = math.max(1, math.min(4, tonumber(m.dueQuarter) or 4)),
            completed = false,
            missed = false,
        })
    end
    return out
end

-- Normalise a premade definition into one clean, complete template.
function W.cloneTemplate(source, name)
    source = source or {}
    return {
        seed = 0,
        name = trim(name or source.name or "Workshop Challenge"),
        difficulty = tostring(source.difficulty or "Custom"),
        farmId = 0,
        startMoney = tonumber(source.startMoney) or -1,
        startDebt = tonumber(source.startDebt) or -1,
        maxLoan = tonumber(source.maxLoan) or -1,
        years = math.max(1, tonumber(source.years) or 2),
        econDifficulty = tostring(source.econDifficulty or ""),
        incomeMode = tostring(source.incomeMode or "gross"),
        restrictions = cloneMap(source.restrictions),
        milestones = cloneMilestones(source.milestones),
    }
end

-- ============================================================
-- Premades
-- ============================================================

local PREMADES = {
    {
        name = "Tiny Homestead", difficulty = "Homestead",
        startMoney = 20000, startDebt = 0, maxLoan = -1, years = 3,
        econDifficulty = "easy", incomeMode = "gross",
        restrictions = { noLeasing = true, noLoans = true },
        milestones = {
            { kind = "Income",   target = 100000,  title = "First harvests",       dueYear = 1, dueQuarter = 4 },
            { kind = "OwnFields", target = 3,      title = "Grow the homestead",   dueYear = 2, dueQuarter = 2 },
            { kind = "NetWorth", target = 500000,  title = "A stable little farm", dueYear = 2, dueQuarter = 4 },
            { kind = "FinalGoal", metric = "NetWorth", target = 1000000, title = "Homestead success", dueYear = 3, dueQuarter = 4 },
        },
    },
    {
        name = "The Wren's Rise", difficulty = "Homestead",
        startMoney = 5000, startDebt = 50000, maxLoan = -1, years = 5,
        econDifficulty = "normal", incomeMode = "gross",
        restrictions = { noLeasing = true, noTeleport = true, noLoans = true },
        milestones = {
            { kind = "NetWorth",  target = 250000,  title = "Find your footing", dueYear = 1, dueQuarter = 4 },
            { kind = "OwnFields", target = 5,       title = "Put down roots",    dueYear = 2, dueQuarter = 4 },
            { kind = "Income",    target = 1000000, title = "Rise steadily",     dueYear = 4, dueQuarter = 4 },
            { kind = "FinalGoal", metric = "NetWorth", target = 3000000, title = "Fly higher", dueYear = 5, dueQuarter = 4 },
        },
    },
    {
        name = "Field By Field", difficulty = "Cooperative",
        startMoney = -1, startDebt = -1, maxLoan = -1, years = 5,
        econDifficulty = "normal", incomeMode = "gross",
        restrictions = { noLeasing = true },
        milestones = {
            { kind = "OwnFields", target = 3,  title = "Own three fields", dueYear = 1, dueQuarter = 4 },
            { kind = "OwnFields", target = 6,  title = "Own six fields",   dueYear = 2, dueQuarter = 4 },
            { kind = "OwnFields", target = 10, title = "Own ten fields",   dueYear = 4, dueQuarter = 2 },
            { kind = "FinalGoal", metric = "OwnFields", target = 15, title = "Build a land empire", dueYear = 5, dueQuarter = 4 },
        },
    },
    {
        name = "Cash Only", difficulty = "Cooperative",
        startMoney = 100000, startDebt = 0, maxLoan = -1, years = 4,
        econDifficulty = "normal", incomeMode = "gross",
        restrictions = { noLoans = true },
        milestones = {
            { kind = "Income",   target = 250000,  title = "Earn your first quarter million", dueYear = 1, dueQuarter = 4 },
            { kind = "NetWorth", target = 750000,  title = "Build without borrowing",         dueYear = 2, dueQuarter = 4 },
            { kind = "Income",   target = 1000000, title = "One million earned",              dueYear = 3, dueQuarter = 4 },
            { kind = "FinalGoal", metric = "NetWorth", target = 2000000, title = "Debt-free success", dueYear = 4, dueQuarter = 4 },
        },
    },
    {
        name = "Old-School Farming", difficulty = "Estate",
        -- A real borrowing ceiling rather than an outright ban: you may lean on
        -- the bank, but only so far.
        startMoney = 75000, startDebt = 100000, maxLoan = 100000, years = 5,
        econDifficulty = "normal", incomeMode = "gross",
        restrictions = { noWorkers = true, noLeasing = true, noTeleport = true, manualOnly = true },
        milestones = {
            { kind = "NetWorth",  target = 500000,  title = "Make the old ways work", dueYear = 1, dueQuarter = 4 },
            { kind = "OwnFields", target = 6,       title = "Expand carefully",       dueYear = 3, dueQuarter = 2 },
            { kind = "Income",    target = 1500000, title = "Earn through hard work", dueYear = 4, dueQuarter = 4 },
            { kind = "FinalGoal", metric = "NetWorth", target = 3000000, title = "An old-school success", dueYear = 5, dueQuarter = 4 },
        },
    },
    {
        name = "No Shortcuts", difficulty = "Estate",
        startMoney = -1, startDebt = -1, maxLoan = -1, years = 4,
        econDifficulty = "hard", incomeMode = "gross",
        restrictions = {
            noWorkers = true, noContractMachines = true, noLeasing = true,
            noTeleport = true, manualOnly = true,
        },
        milestones = {
            { kind = "Income",   target = 250000,  title = "Earn it yourself", dueYear = 1, dueQuarter = 4 },
            { kind = "Income",   target = 600000,  title = "Keep grinding",    dueYear = 2, dueQuarter = 4 },
            { kind = "NetWorth", target = 1500000, title = "Hard work pays",   dueYear = 3, dueQuarter = 4 },
            { kind = "FinalGoal", metric = "Income", target = 1500000, title = "No shortcuts taken", dueYear = 4, dueQuarter = 4 },
        },
    },
    {
        name = "One-Year Sprint", difficulty = "Estate",
        startMoney = -1, startDebt = -1, maxLoan = -1, years = 1,
        econDifficulty = "hard", incomeMode = "gross",
        restrictions = {},
        milestones = {
            { kind = "Income", target = 250000, title = "Fast start",   dueYear = 1, dueQuarter = 1 },
            { kind = "Income", target = 500000, title = "Halfway there", dueYear = 1, dueQuarter = 2 },
            { kind = "Income", target = 750000, title = "Final push",    dueYear = 1, dueQuarter = 3 },
            { kind = "FinalGoal", metric = "Income", target = 1000000, title = "Million-dollar year", dueYear = 1, dueQuarter = 4 },
        },
    },
    {
        name = "Millionaire Farmer", difficulty = "Estate",
        startMoney = -1, startDebt = -1, maxLoan = -1, years = 5,
        econDifficulty = "normal", incomeMode = "gross",
        restrictions = {},
        milestones = {
            { kind = "NetWorth", target = 1000000, title = "First million",        dueYear = 1, dueQuarter = 4 },
            { kind = "NetWorth", target = 2000000, title = "Double it",            dueYear = 2, dueQuarter = 4 },
            { kind = "Income",   target = 3000000, title = "Three million earned", dueYear = 4, dueQuarter = 4 },
            { kind = "FinalGoal", metric = "NetWorth", target = 5000000, title = "Five-million farm", dueYear = 5, dueQuarter = 4 },
        },
    },
    {
        name = "Co-op Empire", difficulty = "Empire",
        startMoney = -1, startDebt = -1, maxLoan = -1, years = 6,
        econDifficulty = "normal", incomeMode = "gross",
        restrictions = {},
        milestones = {
            { kind = "Income",    target = 2000000, title = "Team income",       dueYear = 2, dueQuarter = 4 },
            { kind = "OwnFields", target = 15,      title = "Shared expansion",  dueYear = 3, dueQuarter = 4 },
            { kind = "NetWorth",  target = 5000000, title = "Build the company", dueYear = 4, dueQuarter = 4 },
            { kind = "FinalGoal", metric = "NetWorth", target = 10000000, title = "Create an empire", dueYear = 6, dueQuarter = 4 },
        },
    },
    {
        name = "Zero Cash Climb", difficulty = "Empire",
        -- You begin owing the full borrowing limit, so the bank is closed until
        -- you pay it down. Harder than an outright loan ban, and more
        -- interesting: the debt is a lever you have to earn back.
        startMoney = 0, startDebt = 200000, maxLoan = 200000, years = 8,
        econDifficulty = "hard", incomeMode = "gross",
        restrictions = { noWorkers = true, noLeasing = true },
        milestones = {
            { kind = "NetWorth",  target = 250000,  title = "Survive the beginning", dueYear = 2, dueQuarter = 4 },
            { kind = "OwnFields", target = 8,       title = "Build real roots",      dueYear = 4, dueQuarter = 4 },
            { kind = "Income",    target = 5000000, title = "Become established",    dueYear = 6, dueQuarter = 4 },
            { kind = "FinalGoal", metric = "NetWorth", target = 12000000, title = "Build everything from zero cash", dueYear = 8, dueQuarter = 4 },
        },
    },
}

function W.getPremades()
    local out = {}
    for _, source in ipairs(PREMADES) do
        local premade = W.cloneTemplate(source, source.name)
        premade.isPremade = true
        table.insert(out, premade)
    end
    return out
end
