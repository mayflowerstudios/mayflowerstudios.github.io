--
-- MFC_SaveSetup.lua
--
-- One-time-per-save configuration. On the first load of a save while a campaign
-- is active, this:
--   * enforces the campaign's start type (fromScratch strips starting assets)
--   * sets starting money to the campaign value
-- then writes a flag so it never runs again for that save.
--
-- SAFETY: the destructive part (stripping assets) only ever runs once per save,
-- gated by a flag keyed to the savegame index and stored in the mod's own
-- settings folder. It never edits the save files, and never runs on a save it
-- has already configured. If anything looks wrong it logs and bails rather than
-- stripping.
--

MFC_SaveSetup = {}
local SETUP = MFC_SaveSetup

local function log(msg)
    local MFC = MayflowerFarmChallenge
    if MFC == nil or MFC.DEBUG ~= true then return end
    print(string.format("[MayflowerFarmChallenge] [setup] %s", msg))
end

local function guard(label, fn, fallback)
    local ok, result = pcall(fn)
    if not ok then
        log(string.format("WARN: '%s' failed (%s).", label, tostring(result)))
        return fallback
    end
    return result
end

-- Per-save flag path: keyed to the savegame index so each save is tracked
-- independently. Stored in the mod settings folder, NOT in the save.
-- Per-save flag path: keyed to BOTH the savegame index and the campaign seed.
-- Index alone isn't unique — a new save can reuse a slot number that a prior
-- configured save used, which would make the mod wrongly think it's done. The
-- seed makes it specific to this campaign, so a fresh save (or a re-rolled
-- campaign) in a reused slot configures correctly.
local function flagPath(settingsDir, campaign)
    local idx = guard("savegameIndex", function()
        local info = g_currentMission and g_currentMission.missionInfo
        return (info and info.savegameIndex) or "unknown"
    end, "unknown")
    local seed = (campaign and campaign.seed) or 0
    return string.format("%sconfigured_save_%s_%s.flag", settingsDir, tostring(idx), tostring(seed))
end

local function alreadyConfigured(settingsDir, campaign)
    return fileExists(flagPath(settingsDir, campaign))
end

local function markConfigured(settingsDir, campaign)
    guard("markConfigured", function()
        createFolder(settingsDir)
        local f = io.open(flagPath(settingsDir, campaign), "w")
        if f ~= nil then
            f:write(tostring(getDate("%Y-%m-%d %H:%M:%S")))
            f:close()
        end
    end)
end

-- Get the player's farm (same logic as the main script).
local function getFarm()
    if g_currentMission == nil or g_farmManager == nil then return nil end
    if g_currentMission.playerUserId ~= nil and g_farmManager.getFarmByUserId ~= nil then
        local farm = g_farmManager:getFarmByUserId(g_currentMission.playerUserId)
        if farm ~= nil then return farm end
    end
    if g_currentMission.getFarmId ~= nil then
        return g_farmManager:getFarmById(g_currentMission:getFarmId())
    end
    return nil
end

-- Collect this farm's owned vehicles. Confirmed: g_currentMission.vehicleSystem
-- .vehicles holds vehicles; vehicle:getOwnerFarmId() gives the owner.
local function getOwnedVehicles(farmId)
    return guard("getOwnedVehicles", function()
        local out = {}
        local vs = g_currentMission and g_currentMission.vehicleSystem
        local list = vs and vs.vehicles
        if type(list) ~= "table" then return out end
        for _, v in pairs(list) do
            if type(v) == "table" and v.getOwnerFarmId ~= nil then
                local ok, owner = pcall(function() return v:getOwnerFarmId() end)
                if ok and owner == farmId then
                    table.insert(out, v)
                end
            end
        end
        return out
    end, {})
end

-- Does this farm have starting assets (vehicles)? Used to decide whether a
-- "fromScratch" campaign needs to strip anything.
local function hasStartingAssets(farmId)
    local vehicles = getOwnedVehicles(farmId)
    return #vehicles > 0, vehicles
end

-- Sell/remove a vehicle. VERIFY: the sell path. We try the shop controller
-- sell, then a direct delete as fallback. Guarded so a bad call skips that one
-- vehicle rather than aborting the whole strip.
local function removeVehicle(v)
    guard("removeVehicle", function()
        if g_currentMission ~= nil and g_currentMission.sellVehicle ~= nil then
            g_currentMission:sellVehicle(v)
        elseif v.delete ~= nil then
            v:delete()
        end
    end)
end

local function enforceStartType(campaign, farm)
    if campaign.startType ~= "fromScratch" then
        log("Campaign starts with a farm; no stripping needed.")
        return
    end

    local hasAssets, vehicles = hasStartingAssets(farm.farmId)
    if not hasAssets then
        log("From-scratch campaign and no starting assets found. Good.")
        return
    end

    log(string.format("From-scratch campaign but %d starting vehicle(s) present. Stripping.", #vehicles))
    for _, v in ipairs(vehicles) do
        removeVehicle(v)
    end
    if MayflowerFarmChallenge ~= nil and MayflowerFarmChallenge.notify ~= nil then
        MayflowerFarmChallenge.notify("From-scratch challenge: starting equipment removed.")
    end
end

-- Set money to the campaign value AFTER any stripping, so the final balance is
-- exactly the campaign target regardless of sell proceeds. Only runs when the
-- campaign explicitly fixes the economy.
local function setMoney(campaign, farm)
    if not campaign.setsEconomy then
        log("Campaign doesn't fix the economy; leaving money as-is.")
        return
    end
    -- startMoney < 0 means "leave the player's cash untouched" (the default).
    -- An established farm's balance is never overwritten unless the player
    -- deliberately chose an explicit starting amount in the menu.
    if (campaign.startMoney or -1) < 0 then
        log("Starting money left unchanged.")
        return
    end
    guard("setMoney", function()
        local current = 0
        if farm.getBalance ~= nil then current = farm:getBalance() else current = farm.money or 0 end
        local delta = campaign.startMoney - current
        if math.abs(delta) >= 1 and g_currentMission ~= nil and g_currentMission.addMoney ~= nil then
            g_currentMission:addMoney(delta, farm.farmId, MoneyType.OTHER, true, true)
            log(string.format("Starting money set to %d.", campaign.startMoney))
        end
    end)
end

-- Starting debt: a loan balance you begin owing. Set the farm's loan, then
-- (since taking a loan in-game also hands you the cash) remove that cash so you
-- end up owing the debt without the matching windfall.
-- Starting debt: a loan balance you begin owing. Replaces (not adds to) any
-- loan from the new-save screen. The loan is purely a liability figure — it
-- does NOT touch cash, so you keep your full starting money and simply owe the
-- challenge debt against it. Runs after setMoney so cash is already correct.
local function setDebt(campaign, farm)
    if not campaign.setsEconomy then return end
    local target = campaign.startDebt or -1
    -- < 0 means "leave the player's loan standing untouched" (the default), so
    -- an established farm's debt is never rewritten unless the player picked an
    -- explicit starting loan in the menu.
    if target < 0 then
        log("Starting loan left unchanged.")
        return
    end
    guard("setDebt", function()
        local current = 0
        if farm.getLoan ~= nil then
            local ok, v = pcall(function() return farm:getLoan() end)
            if ok and v then current = v end
        elseif farm.loan ~= nil then
            current = farm.loan or 0
        end

        -- Set the loan ledger directly to the target (replacing any existing).
        -- Try the setter first, then the field. We log both before/after so the
        -- log tells us definitively whether the write took.
        if farm.setLoan ~= nil then
            farm:setLoan(target)
        elseif farm.loan ~= nil then
            farm.loan = target
        else
            log("WARN: no farm loan accessor (getLoan/setLoan/loan) found (VERIFY).")
            return
        end

        local after = current
        if farm.getLoan ~= nil then
            local ok, v = pcall(function() return farm:getLoan() end)
            if ok and v then after = v end
        elseif farm.loan ~= nil then
            after = farm.loan or current
        end

        log(string.format("Loan: was %d, target %d, now reads %d.", current, target, after))
        if target > 0 and MayflowerFarmChallenge ~= nil and MayflowerFarmChallenge.notify ~= nil then
            MayflowerFarmChallenge.notify(string.format("You begin owing $%d. Pay it down.", target))
        end
    end)
end

-- In-game economic difficulty (easy/normal/hard). VERIFY: missionInfo difficulty
-- field. This sets prices/income scaling the game itself uses.
local function setEconDifficulty(campaign, farm)
    if not campaign.setsEconomy then return end
    local d = campaign.econDifficulty
    if d == nil or d == "" then return end
    guard("setEconDifficulty", function()
        local idx = ({ easy = 1, normal = 2, hard = 3 })[d]
        if idx == nil then return end
        local info = g_currentMission and g_currentMission.missionInfo
        if info ~= nil then
            -- VERIFY: the difficulty field name on missionInfo.
            if info.economicDifficulty ~= nil then
                info.economicDifficulty = idx
            elseif info.difficulty ~= nil then
                info.difficulty = idx
            else
                log("WARN: econ difficulty field not found on missionInfo (VERIFY).")
                return
            end
            log(string.format("Economic difficulty set to %s (%d).", d, idx))
        end
    end)
end

-- Entry point, called repeatedly from the update loop until it returns true.
-- Returns true when setup is complete (or was already done, or there's nothing
-- to do); false means "farm not ready, call me again."
function SETUP.run(campaign, settingsDir)
    if campaign == nil then return true end

    if alreadyConfigured(settingsDir, campaign) then
        if not SETUP.skipLogged then
            log("This save was already configured; skipping setup (delete the flag in modSettings to redo).")
            SETUP.skipLogged = true
        end
        return true
    end

    local farm = getFarm()
    if farm == nil then
        return false -- not ready; the update loop will retry
    end

    log(string.format("Configuring save for campaign '%s' (startType=%s, startMoney=%d).",
        campaign.name or "?", campaign.startType or "?", campaign.startMoney or -1))

    enforceStartType(campaign, farm)
    setEconDifficulty(campaign, farm)
    setMoney(campaign, farm)
    setDebt(campaign, farm)
    markConfigured(settingsDir, campaign)
    log("Save configured. This will not run again for this save.")
    return true
end
