--
-- MFC_SaveSetup.lua
--
-- Applies a challenge's chosen starting economy once, the first time the run
-- becomes live on a save: economic difficulty, starting cash, starting loan.
--
-- SAFETY: this never edits save files and never touches vehicles or property.
-- The only things it changes are the farm's balance, its loan ledger, and the
-- economic difficulty setting -- all of which the player explicitly selected in
-- the challenge editor. "Leave unchanged" (-1) is the default for both money
-- and loan, so an established farm is never rewritten by accident.
--
-- Runs at most once per challenge: the caller records challenge#setupDone in
-- challenge.xml when this returns true. Starting a new challenge clears that
-- flag, so each run configures itself exactly once.
--

MFC_SaveSetup = {}
local SETUP = MFC_SaveSetup

local function log(msg)
    local MFC = MayflowerFarmChallenge
    if MFC == nil or MFC.DEBUG ~= true then return end
    print(string.format("[FarmChallenge] [setup] %s", msg))
end

local function guard(label, fn, fallback)
    local ok, result = pcall(fn)
    if not ok then
        log(string.format("WARN: '%s' failed (%s).", label, tostring(result)))
        return fallback
    end
    return result
end

-- The farm the challenge belongs to. In multiplayer that is the farm of
-- whoever started the run, which a dedicated server can only resolve by id.
local function getFarm(campaign)
    if g_currentMission == nil or g_farmManager == nil then return nil end
    local farmId = campaign and tonumber(campaign.farmId) or 0
    if farmId > 0 and g_farmManager.getFarmById ~= nil then
        local farm = g_farmManager:getFarmById(farmId)
        if farm ~= nil then return farm end
    end
    if g_currentMission.playerUserId ~= nil and g_farmManager.getFarmByUserId ~= nil then
        local farm = g_farmManager:getFarmByUserId(g_currentMission.playerUserId)
        if farm ~= nil then return farm end
    end
    if g_currentMission.getFarmId ~= nil and g_farmManager.getFarmById ~= nil then
        return g_farmManager:getFarmById(g_currentMission:getFarmId())
    end
    return nil
end

-- In-game economic difficulty (easy / normal / hard): the price and income
-- scaling the game itself applies.
local function setEconDifficulty(campaign)
    local name = campaign.econDifficulty
    if name == nil or name == "" then return end
    guard("setEconDifficulty", function()
        local index = ({ easy = 1, normal = 2, hard = 3 })[name]
        local info = g_currentMission and g_currentMission.missionInfo
        if index == nil or info == nil then return end
        if info.economicDifficulty ~= nil then
            info.economicDifficulty = index
        elseif info.difficulty ~= nil then
            info.difficulty = index
        else
            log("WARN: economic difficulty field not found on missionInfo.")
            return
        end
        log(string.format("Economic difficulty set to %s (%d).", name, index))
    end)
end

-- Set the balance to the challenge's starting figure. Only runs when the player
-- picked an explicit amount; < 0 means "leave the balance alone".
local function setMoney(campaign, farm)
    local target = tonumber(campaign.startMoney) or -1
    if target < 0 then
        log("Starting money left unchanged.")
        return
    end
    guard("setMoney", function()
        local current = 0
        if farm.getBalance ~= nil then current = farm:getBalance() or 0
        else current = farm.money or 0 end
        local delta = target - current
        if math.abs(delta) >= 1 and g_currentMission ~= nil and g_currentMission.addMoney ~= nil then
            g_currentMission:addMoney(delta, farm.farmId, MoneyType.OTHER, true, true)
            log(string.format("Starting money set to %d.", target))
        end
    end)
end

-- Starting debt: a loan balance you begin owing. It replaces (rather than adds
-- to) any loan from the new-save screen, and is purely a liability -- it does
-- NOT hand over the matching cash, so you keep your starting money and simply
-- owe the challenge debt against it. Runs after setMoney so cash is settled.
local function setDebt(campaign, farm)
    local target = tonumber(campaign.startDebt) or -1
    if target < 0 then
        log("Starting loan left unchanged.")
        return
    end
    guard("setDebt", function()
        local before = 0
        if farm.getLoan ~= nil then
            local ok, value = pcall(function() return farm:getLoan() end)
            if ok and type(value) == "number" then before = value end
        elseif farm.loan ~= nil then
            before = farm.loan or 0
        end

        -- Prefer the setter: on a server it marks the farm dirty so clients see
        -- the same loan. Writing the field directly is a last resort and will
        -- not replicate.
        if farm.setLoan ~= nil then
            farm:setLoan(target)
        elseif farm.loan ~= nil then
            farm.loan = target
            log("NOTE: farm.setLoan missing; loan written directly and may not sync to clients.")
        else
            log("WARN: no farm loan accessor found; starting debt not applied.")
            return
        end

        local after = before
        if farm.getLoan ~= nil then
            local ok, value = pcall(function() return farm:getLoan() end)
            if ok and type(value) == "number" then after = value end
        elseif farm.loan ~= nil then
            after = farm.loan or before
        end
        log(string.format("Loan: was %d, target %d, now reads %d.", before, target, after))

        if target > 0 then
            local MFC = MayflowerFarmChallenge
            if MFC ~= nil and MFC.notify ~= nil then
                MFC.notify(string.format("You begin owing $%d. Pay it down.", target))
            end
        end
    end)
end

-- Called repeatedly from the update loop until it returns true.
-- Returns true when setup is complete or there is nothing to do; false means
-- "the farm isn't ready yet, call me again".
function SETUP.run(campaign)
    if campaign == nil then return true end
    if campaign.setupDone == true then return true end

    local farm = getFarm(campaign)
    if farm == nil then
        return false -- not ready; the update loop will retry
    end

    log(string.format("Configuring '%s' (startMoney=%d, startDebt=%d, econ=%s).",
        campaign.name or "?", tonumber(campaign.startMoney) or -1,
        tonumber(campaign.startDebt) or -1, campaign.econDifficulty or "default"))

    setEconDifficulty(campaign)
    setMoney(campaign, farm)
    setDebt(campaign, farm)

    log("Starting economy applied. This will not run again for this challenge.")
    return true
end
