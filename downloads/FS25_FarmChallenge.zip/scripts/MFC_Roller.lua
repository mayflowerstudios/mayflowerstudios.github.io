--
-- MFC_Roller.lua
--
-- Rolls a coherent random challenge for the "Randomize setup" button. It
-- returns the knobs the editor actually exposes -- goal metric and target, time
-- limit, economy difficulty and restrictions -- and lets the editor derive the
-- milestone targets from the player's real farm. That keeps one source of truth
-- for target maths instead of two that can disagree.
--

MFC_Roller = {}

local TONE = { "Patient", "Stubborn", "Quiet", "Frostbitten", "Golden", "Long", "Humble", "Relentless" }
local LAND = { "Harvest", "Acres", "Fields", "Homestead", "Furrow", "Meadow", "Pasture", "Roots" }

local RESTRICTIONS = { "noWorkers", "noContractMachines", "noLeasing", "noTeleport", "noLoans", "manualOnly" }

-- Difficulty tiers, easiest first.
MFC_Roller.TIERS = {
    {
        id = "Homestead", label = "Homestead",
        blurb = "A gentle start. Room to breathe and learn the land.",
        years = 2, goalMin = 750000, goalMax = 1000000,
        fieldsMin = 3, fieldsMax = 5,
        restrictionCount = 0, econDifficulty = "easy", setEconomyChance = 0.20,
    },
    {
        id = "Cooperative", label = "Cooperative",
        blurb = "Tighter margins. A few rules to work around.",
        years = 3, goalMin = 1000000, goalMax = 1500000,
        fieldsMin = 5, fieldsMax = 9,
        restrictionCount = 1, econDifficulty = "normal", setEconomyChance = 0.50,
    },
    {
        id = "Estate", label = "Estate",
        blurb = "Serious discipline. Real restrictions, real deadlines.",
        years = 4, goalMin = 2000000, goalMax = 3000000,
        fieldsMin = 8, fieldsMax = 14,
        restrictionCount = 2, econDifficulty = "hard", setEconomyChance = 0.80,
    },
    {
        id = "Empire", label = "Empire",
        blurb = "No mercy. Hard economy, long horizon, few comforts.",
        years = 5, goalMin = 5000000, goalMax = 8000000,
        fieldsMin = 12, fieldsMax = 22,
        restrictionCount = 3, econDifficulty = "hard", setEconomyChance = 1.00,
    },
}

function MFC_Roller.getTier(id)
    for _, tier in ipairs(MFC_Roller.TIERS) do
        if tier.id == id then return tier end
    end
    return MFC_Roller.TIERS[1]
end

-- A self-contained Park-Miller generator. A mod must never call
-- math.randomseed: that generator is shared with the game and every other mod,
-- so reseeding it makes unrelated systems repeat themselves. Schrage's method
-- keeps every intermediate well inside double precision.
local function makeRng(seed)
    local state = math.floor(math.abs(tonumber(seed) or 1)) % 2147483647
    if state <= 0 then state = 1 end

    local function nextRaw()
        local hi = math.floor(state / 127773)
        local lo = state % 127773
        state = 16807 * lo - 2836 * hi
        if state <= 0 then state = state + 2147483647 end
        return state
    end

    local rng = {}
    function rng.float()
        return (nextRaw() - 1) / 2147483646
    end
    function rng.int(lo, hi)
        if hi <= lo then return lo end
        return lo + (nextRaw() % (hi - lo + 1))
    end
    function rng.pick(list)
        return list[rng.int(1, #list)]
    end
    function rng.shuffled(list)
        local out = {}
        for i = 1, #list do out[i] = list[i] end
        for i = #out, 2, -1 do
            local j = rng.int(1, i)
            out[i], out[j] = out[j], out[i]
        end
        return out
    end
    return rng
end

local function roundTo(value, step)
    return math.floor((value / step) + 0.5) * step
end

-- Roll a challenge for the given tier. `seed` is optional; pass one to
-- reproduce a previous roll exactly.
function MFC_Roller.roll(tierId, seed)
    local tier = MFC_Roller.getTier(tierId)
    seed = tonumber(seed) or math.random(1, 1000000)
    local rng = makeRng(seed)

    local moneyGoal = roundTo(rng.int(tier.goalMin, tier.goalMax), 50000)

    -- Half net worth, a quarter fields, a quarter money earned.
    local goalMetric, goalTarget
    local roll = rng.int(1, 100)
    if roll <= 50 then
        goalMetric, goalTarget = "NetWorth", moneyGoal
    elseif roll <= 75 then
        goalMetric, goalTarget = "OwnFields", rng.int(tier.fieldsMin, tier.fieldsMax)
    else
        goalMetric, goalTarget = "Income", roundTo(moneyGoal * 0.6, 50000)
    end

    local restrictions = {}
    local shuffled = rng.shuffled(RESTRICTIONS)
    for i = 1, tier.restrictionCount do
        if shuffled[i] ~= nil then restrictions[shuffled[i]] = true end
    end

    local setsEconomy = rng.float() < tier.setEconomyChance

    return {
        seed = seed,
        name = rng.pick(TONE) .. " " .. rng.pick(LAND),
        difficulty = tier.label,
        goalMetric = goalMetric,
        goalTarget = goalTarget,
        years = tier.years,
        econDifficulty = setsEconomy and tier.econDifficulty or "",
        restrictions = restrictions,
    }
end
