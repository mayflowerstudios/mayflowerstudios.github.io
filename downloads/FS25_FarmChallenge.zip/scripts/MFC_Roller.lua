--
-- MFC_Roller.lua
--
-- In-game campaign roller, ported faithfully from the app's C# CampaignRoller +
-- DifficultyProfile. Produces a campaign table with the same fields the mod's
-- challenge loader already uses, so the rest of the mod consumes it unchanged.
--

MFC_Roller = {}

local TONE = { "Patient", "Stubborn", "Quiet", "Frostbitten", "Golden", "Long", "Humble", "Relentless" }
local LAND = { "Harvest", "Acres", "Fields", "Homestead", "Furrow", "Meadow", "Pasture", "Roots" }

local RESTRICTIONS = { "noWorkers", "noContractMachines", "noLeasing", "noTeleport", "noLoans", "manualOnly" }

local DEFAULT_TRACTOR_BRANDS = {
    "JOHNDEERE", "CASEIH", "NEWHOLLAND", "FENDT", "MASSEYFERGUSON",
    "DEUTZFAHR", "VALTRA", "KUBOTA", "FORD", "MCCORMICK", "STEYR", "CHALLENGER",
}

-- Difficulty tiers, in order. Matches the app's DifficultyProfile.All.
MFC_Roller.TIERS = {
    {
        id = "Homestead", label = "Homestead",
        blurb = "A gentle start. Room to breathe and learn the land.",
        startMoney = { 600000, 800000, 1000000 },
        years = 2, goalMin = 750000, goalMax = 1000000,
        restrictionCount = 0, intermediate = 3,
        brandChance = 0.10, fromScratchChance = 0.15,
        setEconomyChance = 0.20, maxStartDebt = 0, econDifficulty = "easy",
    },
    {
        id = "Cooperative", label = "Cooperative",
        blurb = "Tighter margins. A few rules to work around.",
        startMoney = { 350000, 500000, 650000 },
        years = 2, goalMin = 1000000, goalMax = 1500000,
        restrictionCount = 1, intermediate = 3,
        brandChance = 0.30, fromScratchChance = 0.40,
        setEconomyChance = 0.50, maxStartDebt = 100000, econDifficulty = "normal",
    },
    {
        id = "Estate", label = "Estate",
        blurb = "Serious discipline. Restrictions shift between stages.",
        startMoney = { 150000, 250000, 350000 },
        years = 3, goalMin = 2000000, goalMax = 3000000,
        restrictionCount = 2, intermediate = 4,
        brandChance = 0.55, fromScratchChance = 0.70,
        setEconomyChance = 0.80, maxStartDebt = 300000, econDifficulty = "hard",
    },
    {
        id = "Empire", label = "Empire",
        blurb = "No mercy. Lean capital, hard caps, long horizon.",
        startMoney = { 20000, 75000, 150000, 250000 },
        years = 4, goalMin = 5000000, goalMax = 8000000,
        restrictionCount = 3, intermediate = 5,
        brandChance = 0.80, fromScratchChance = 0.95,
        setEconomyChance = 1.00, maxStartDebt = 600000, econDifficulty = "hard",
    },
}

function MFC_Roller.getTier(id)
    for _, t in ipairs(MFC_Roller.TIERS) do
        if t.id == id then return t end
    end
    return MFC_Roller.TIERS[1]
end

local function pick(rng, arr)
    return arr[rng(1, #arr)]
end

local function roundTo(v, step)
    return math.floor((v / step) + 0.5) * step
end

local function shuffle(rng, arr)
    local out = {}
    for i = 1, #arr do out[i] = arr[i] end
    for i = #out, 2, -1 do
        local j = rng(1, i)
        out[i], out[j] = out[j], out[i]
    end
    return out
end

-- maps: list of {id=, label=}. tractorBrands: list of brand id strings.
function MFC_Roller.roll(tierId, maps, tractorBrands, seed)
    seed = seed or math.random(1, 1000000)
    -- deterministic-ish rng seeded by the seed; FS Lua has math.random with seed
    math.randomseed(seed)
    local function rng(lo, hi) return math.random(lo, hi) end
    local function rngf() return math.random() end

    local t = MFC_Roller.getTier(tierId)
    maps = (maps and #maps > 0) and maps or { { id = "FS25_MainMap", label = "Riverbend Springs" } }
    tractorBrands = (tractorBrands and #tractorBrands >= 2) and tractorBrands or DEFAULT_TRACTOR_BRANDS

    local map = maps[rng(1, #maps)]
    local name = TONE[rng(1, #TONE)] .. " " .. LAND[rng(1, #LAND)]
    local startMoney = pick(rng, t.startMoney)

    local finalGoal = roundTo(rng(t.goalMin, t.goalMax), 50000)

    -- Goal metric: half net worth, quarter fields, quarter income; target
    -- scaled per tier (fields ranges per tier, income at 60% of net worth).
    local FIELD_RANGES = { Homestead = {3, 5}, Cooperative = {5, 9}, Estate = {8, 14}, Empire = {12, 22} }
    local goalMetric, goalTarget
    local mroll = rng(1, 100)
    if mroll <= 50 then
        goalMetric, goalTarget = "NetWorth", finalGoal
    elseif mroll <= 75 then
        local fr = FIELD_RANGES[t.id] or {3, 8}
        goalMetric, goalTarget = "OwnFields", rng(fr[1], fr[2])
    else
        goalMetric, goalTarget = "Income", roundTo(finalGoal * 0.6, 50000)
    end

    -- Global restrictions
    local restrictions = {}
    local shuffled = shuffle(rng, RESTRICTIONS)
    for i = 1, t.restrictionCount do
        if shuffled[i] then restrictions[shuffled[i]] = true end
    end

    -- Milestones
    local milestones = {}
    local totalQ = t.years * 4
    for i = 1, t.intermediate do
        local frac = i / (t.intermediate + 1)
        local qIndex = math.floor(frac * totalQ + 0.5)
        local year = math.floor(qIndex / 4) + 1
        local quarter = (qIndex % 4) + 1
        local kind, target, title
        if i == 1 then
            kind = "OwnFields"; target = 2 + rng(0, 2)
            title = "Establish the farm"
        elseif i == 2 and rngf() < 0.5 then
            kind = "ProductionValue"; target = roundTo(finalGoal * frac * 0.4, 10000)
            title = "Build a revenue stream"
        else
            kind = "NetWorth"
            target = roundTo(goalTarget * (frac ^ 1.4), 25000)
            title = "Grow net worth"
        end
        table.insert(milestones, {
            order = i, kind = kind, target = target,
            dueYear = year, dueQuarter = quarter, title = title, completed = false,
        })
    end
    -- Final goal milestone
    table.insert(milestones, {
        order = t.intermediate + 1, kind = "FinalGoal", metric = goalMetric, target = goalTarget,
        dueYear = t.years, dueQuarter = 4, title = "Final goal", completed = false,
    })

    -- Brand restriction removed: tractors are never limited.
    local brandMode = "none"
    local brandSet = {}
    local brandNames = {}

    -- Start type: always start with a farm (from-scratch removed).
    local startType = "withFarm"

    local setsEconomy = rngf() < t.setEconomyChance
    local econDiff = setsEconomy and t.econDifficulty or ""
    local startDebt = 0
    if setsEconomy and t.maxStartDebt > 0 and rngf() < 0.6 then
        local raw = rng(math.floor(t.maxStartDebt / 4), t.maxStartDebt)
        startDebt = math.floor(raw / 25000) * 25000
    end

    return {
        seed = seed,
        name = name,
        difficulty = t.label,
        mapId = map.id,
        mapLabel = map.label,
        startMoney = startMoney,
        years = t.years,
        startType = startType,
        startDebt = startDebt,
        econDifficulty = econDiff,
        setsEconomy = setsEconomy,
        restrictions = restrictions,
        brandMode = brandMode,
        brandSet = brandSet,
        brandListStr = table.concat(brandNames, " or "),
        blockedCategories = {},
        milestones = milestones,
        goalMetric = goalMetric,
        goalTarget = goalTarget,
    }
end
