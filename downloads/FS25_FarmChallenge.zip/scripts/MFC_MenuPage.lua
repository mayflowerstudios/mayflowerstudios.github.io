--
-- MFC_MenuPage.lua
--
-- In-game (Esc) menu page that builds challenges using native FS25 settings
-- controls (MultiTextOption pickers + BinaryOption toggles), following the
-- proven FS25_additionalGameSettings pattern. "Roll" randomizes the pickers;
-- "Start" builds a campaign from the current picker/toggle state and applies it.
--

MFC_MenuPage = {}
local MFC_MenuPage_mt = Class(MFC_MenuPage, TabbedMenuFrameElement)

local function plog(msg)
    local MFC = MayflowerFarmChallenge
    if MFC == nil or MFC.DEBUG ~= true then return end
    print(string.format("[MayflowerFarmChallenge] [menu] %s", msg))
end

local function money(v)
    local s = string.format("%d", math.floor((v or 0) + 0.5))
    local out, count = "", 0
    for i = #s, 1, -1 do
        out = s:sub(i, i) .. out
        count = count + 1
        if count % 3 == 0 and i > 1 then out = "," .. out end
    end
    return "$" .. out
end

-- Preset option values for the pickers.
local DIFFICULTIES = { "Homestead", "Cooperative", "Estate", "Empire" }
-- Unique, non-numeric marker for the first money/loan option. Selecting it means
-- "leave the player's cash / loan exactly as it is" - the mod makes no forced
-- economy change. It's the default, so a challenge never overwrites an existing
-- farm's balance or debt unless the player deliberately picks a number.
local UNCHANGED = {}
local MONEY_STEPS = { UNCHANGED, 0, 5000, 10000, 20000, 50000, 75000, 100000, 150000, 250000, 350000, 500000, 650000, 800000, 1000000, 1500000, 2000000 }
local LOAN_STEPS  = { UNCHANGED, 0, 25000, 50000, 100000, 200000, 300000, 450000, 600000, 750000, 1000000 }
local YEARS_STEPS = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
local ECON_STEPS  = { "Default", "Easy", "Normal", "Hard" }
-- "Money earned" measurement modes, matching MFC.incomeValue().
local INCOME_MODES = { "gross", "net" }

-- Goal types: what the final goal (and auto milestones) measure.
local GOAL_TYPES = {
    { id = "NetWorth",  label = "Net worth",
      steps = { 500000, 750000, 1000000, 1500000, 2000000, 3000000, 5000000, 8000000, 10000000, 12000000, 15000000, 20000000, 30000000, 50000000 },
      fmt = money },
    { id = "OwnFields", label = "Fields owned",
      steps = { 3, 5, 8, 10, 12, 15, 20, 25, 30, 40 },
      fmt = function(v) return string.format("%d fields", v) end },
    { id = "Income",    label = "Money earned",
      steps = { 250000, 500000, 750000, 1000000, 1500000, 2500000, 4000000, 6000000, 8000000, 10000000, 15000000 },
      fmt = money },
}

-- Milestone manual targets (index 1 = Auto), per metric.
local MILESTONE_STEPS = { 0, 25000, 50000, 100000, 150000, 250000, 400000, 600000, 800000, 1000000, 1500000, 2000000, 3000000, 4000000, 6000000, 8000000, 10000000, 15000000, 20000000 }
local FIELD_MS_STEPS  = { 0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30 }

local MS_TYPES = {
    { id = "NetWorth",  label = "Net worth",    title = "Grow net worth" },
    { id = "OwnFields", label = "Fields owned", title = "Own fields" },
    { id = "Income",    label = "Money earned", title = "Earn money" },
}

local function msStepsFor(metricId)
    if metricId == "OwnFields" then return FIELD_MS_STEPS end
    return MILESTONE_STEPS
end
local function msFmt(metricId, v)
    if metricId == "OwnFields" then return string.format("%d fields", v) end
    return money(v)
end

local function roundMoneyTarget(v)
    return math.ceil((v or 0) / 25000) * 25000
end

local function generatedTargetAbove(metricId, current)
    current = math.max(0, current or 0)
    if metricId == "OwnFields" then return math.floor(current) + 1 end
    local increment = math.max(250000, roundMoneyTarget(current * 0.10))
    return roundMoneyTarget(current + increment)
end

local TOGGLE_IDS = {
    chkNoWorkers = "noWorkers",
    chkNoContracts = "noContractMachines",
    chkNoLeasing = "noLeasing",
    chkNoTeleport = "noTeleport",
    chkNoLoans = "noLoans",
    chkManualOnly = "manualOnly",
}

function MFC_MenuPage.new(target, custom_mt)
    local self = TabbedMenuFrameElement.new(target, custom_mt or MFC_MenuPage_mt)
    MFC_MenuPage.lastInstance = self
    return self
end

local function setTexts(opt, texts)
    if opt ~= nil and opt.setTexts ~= nil then
        opt:setTexts(texts)
        -- FS25 element bug (documented by FS25_IncomeMod): setTexts does not
        -- update numTexts, desyncing the displayed text from getState. Fix it.
        opt.numTexts = #texts
    end
end
local function setState(opt, i)
    if opt ~= nil and opt.setState ~= nil then opt:setState(i, nil, true) end
end
local function getState(opt)
    if opt ~= nil and opt.getState ~= nil then return opt:getState() end
    return 1
end

local function selectedMappedValue(ctrl, values, fallback)
    if values == nil then return fallback end
    return values[getState(ctrl)] or fallback
end
-- All option/toggle control ids, for state snapshot around layout passes
-- (FS25 layout re-init can wipe element states; documented by FS25_IncomeMod).
local OPTION_IDS = {
    "optDifficulty", "optMoney", "optLoan", "optGoalType", "optGoal", "optIncomeMode",
    "optM1Type", "optM1", "optM2Type", "optM2", "optM3Type", "optM3",
    "optYears", "optEconomy",
    "chkNoWorkers", "chkNoContracts", "chkNoLeasing", "chkNoTeleport",
    "chkNoLoans", "chkManualOnly",
}

-- Toggles are MultiTextOptions with two states: 1 = OFF, 2 = ON. Using state
-- (not setIsChecked) keeps the highlight in bounds.
local function setToggle(ctrl, on)
    setState(ctrl, on and 2 or 1)
end
local function getToggle(ctrl)
    if ctrl ~= nil and ctrl.getIsChecked ~= nil then
        local ok, v = pcall(function() return ctrl:getIsChecked() end)
        if ok and type(v) == "boolean" then return v end
    end
    return getState(ctrl) == 2
end

function MFC_MenuPage:goalType()
    local idx = getState(self.optGoalType)
    return GOAL_TYPES[idx] or GOAL_TYPES[1]
end

function MFC_MenuPage:msType(i)
    local ctrl = self["optM" .. i .. "Type"]
    return MS_TYPES[getState(ctrl)] or MS_TYPES[1]
end

-- Return the chosen starting cash, or nil when "Leave unchanged" is selected
-- (so callers know not to force the balance).
function MFC_MenuPage:selectedStartMoney()
    local v = MONEY_STEPS[getState(self.optMoney)]
    if v == nil or v == UNCHANGED then return nil end
    return v
end

-- Return the chosen starting loan, or nil when "Leave unchanged" is selected.
function MFC_MenuPage:selectedStartDebt()
    local v = LOAN_STEPS[getState(self.optLoan)]
    if v == nil or v == UNCHANGED then return nil end
    return v
end

-- Value the farm will have when the new challenge becomes active. Existing
-- assets/fields count, while the selected starting money and debt are applied.
function MFC_MenuPage:projectedMetric(metricId)
    local MFC = MayflowerFarmChallenge
    if MFC ~= nil and MFC.getProjectedStartMetricPublic ~= nil then
        return MFC.getProjectedStartMetricPublic(metricId,
            self:selectedStartMoney(), self:selectedStartDebt()) or 0
    end
    if metricId == "OwnFields" then
        return (MFC and MFC.getOwnedFieldsPublic and MFC.getOwnedFieldsPublic()) or 0
    elseif metricId == "Income" then
        return 0
    end
    return (MFC and MFC.getNetWorthPublic and MFC.getNetWorthPublic()) or 0
end

function MFC_MenuPage:validTargetsAbove(metricId, sourceSteps)
    local current = self:projectedMetric(metricId)
    local out = {}
    for _, value in ipairs(sourceSteps or {}) do
        if value > current then table.insert(out, value) end
    end
    if #out == 0 then table.insert(out, generatedTargetAbove(metricId, current)) end
    return out, current
end

-- Snapshot / restore picker states around layout invalidation.
function MFC_MenuPage:snapshotStates()
    local snap = {}
    for _, id in ipairs(OPTION_IDS) do
        snap[id] = getState(self[id])
    end
    return snap
end

function MFC_MenuPage:restoreStates(snap)
    if snap == nil then return end
    for _, id in ipairs(OPTION_IDS) do
        if snap[id] ~= nil then setState(self[id], snap[id]) end
    end
end

-- Invalidate the layout without losing user selections.
function MFC_MenuPage:safeInvalidateLayout()
    guard_pcall(function()
        if self.layout == nil or self.layout.invalidateLayout == nil then return end
        local snap = self:snapshotStates()
        self.layout:invalidateLayout()
        self:restoreStates(snap)
    end)
end

-- Refresh a milestone's target picker to match its selected metric.
function MFC_MenuPage:refreshMilestoneTexts(i, keepState)
    guard_pcall(function()
        local ctrl = self["optM" .. i]
        if ctrl == nil then return end
        local mt = self:msType(i)
        self.milestoneValueOptions = self.milestoneValueOptions or {}
        local previous = nil
        if keepState then
            previous = selectedMappedValue(ctrl, self.milestoneValueOptions[i], 0)
        end

        local source = msStepsFor(mt.id)
        local manualSteps = {}
        for k = 2, #source do table.insert(manualSteps, source[k]) end
        local valid = self:validTargetsAbove(mt.id, manualSteps)
        local values = { 0 } -- 0 means Auto
        local texts = { "Auto" }
        for _, value in ipairs(valid) do
            table.insert(values, value)
            table.insert(texts, msFmt(mt.id, value))
        end
        self.milestoneValueOptions[i] = values
        setTexts(ctrl, texts)

        local targetState = 1
        if keepState and previous ~= nil and previous > 0 then
            targetState = self:nearestIndex(values, previous)
        end
        setState(ctrl, math.max(1, math.min(targetState, #texts)))
    end)
end

-- Register the page's rows with the focus system so gamepad navigation works.
-- Must run while the page is visible (correct focus context). One-time.
function MFC_MenuPage:initFocus()
    if self.focusInitialized then return end
    guard_pcall(function()
        if FocusManager == nil or self.layout == nil then return end
        if FocusManager.loadElementFromCustomValues ~= nil then
            for _, el in ipairs(self.layout.elements or {}) do
                FocusManager:loadElementFromCustomValues(el)
            end
        end
        self.focusInitialized = true
    end)
end

function MFC_MenuPage:focusList()
    guard_pcall(function()
        if FocusManager ~= nil and FocusManager.setFocus ~= nil and self.layout ~= nil then
            FocusManager:setFocus(self.layout)
        end
    end)
end

function MFC_MenuPage:onFrameOpen()
    MFC_MenuPage:superClass().onFrameOpen(self)
    -- Wire the docked slider to the scrolling layout (Courseplay pattern).
    guard_pcall(function()
        if self.settingsSlider ~= nil and self.settingsSlider.setDataElement ~= nil and self.layout ~= nil then
            self.settingsSlider:setDataElement(self.layout)
        end
    end)
    if self.layout ~= nil and self.layout.invalidateLayout ~= nil then
        self.layout:invalidateLayout()
    end
    self:populateOptions()
    -- Start at the top of the list so ACTIVE CHALLENGE is what you see first.
    guard_pcall(function()
        if self.layout ~= nil then
            if self.layout.setScrollPosition ~= nil then
                self.layout:setScrollPosition(0)
            elseif self.layout.scrollTo ~= nil then
                self.layout:scrollTo(0)
            end
        end
        if self.pageSlider ~= nil and self.pageSlider.setValue ~= nil then
            self.pageSlider:setValue(self.pageSlider.minValue or 0)
        end
    end)
    self:initFocus()
    self:updateMenuButtons()
    self:updateStatus()
    self:updateStats()
    -- Belt-and-suspenders: bar visibility must match campaign presence even if
    -- anything above hiccuped.
    pcall(function()
        local hasCampaign = MayflowerFarmChallenge ~= nil and MayflowerFarmChallenge.campaign ~= nil
        if self.goalBarBg ~= nil and self.goalBarBg.setVisible ~= nil then
            self.goalBarBg:setVisible(hasCampaign)
        end
    end)
end

-- onFrameOpen doesn't fire reliably for injected pages (tab-cycling vs direct
-- click differ), so refresh from the update loop instead: cheap, throttled,
-- and it keeps progress live while the page is open.
function MFC_MenuPage:update(dt)
    MFC_MenuPage:superClass().update(self, dt)
    -- Deferred initial focus: the base menu does its own focus handling when a
    -- page opens and wins any race with an immediate setFocus. Wait a few
    -- frames after becoming visible, then take focus on the first control.
    local visible = (self.getIsVisible ~= nil) and self:getIsVisible() or true
    if visible and not self.mfcWasVisible then
        self.mfcFocusDelay = 5
    end
    self.mfcWasVisible = visible
    if visible and self.mfcFocusDelay ~= nil then
        self.mfcFocusDelay = self.mfcFocusDelay - 1
        if self.mfcFocusDelay <= 0 then
            self.mfcFocusDelay = nil
            self:initFocus()
            guard_pcall(function()
                if FocusManager ~= nil and FocusManager.setFocus ~= nil and self.optDifficulty ~= nil then
                    FocusManager:setFocus(self.optDifficulty)
                end
            end)
        end
    end
    self.mfcRefreshTimer = (self.mfcRefreshTimer or 0) + (dt or 0)
    if self.mfcRefreshTimer < 500 then return end
    self.mfcRefreshTimer = 0
    guard_pcall(function()
        if not self.initialized then
            self:populateOptions()
        end
        self:updateStatus()
        self:updateStats()
    end)
end

local function setStat(el, text)
    if el ~= nil and el.setText ~= nil then el:setText(text or "") end
end

-- Show/hide a stat row via its wrapper element so the layout reflows.
local function setRowVisible(el, vis)
    pcall(function()
        if el ~= nil and el.parent ~= nil and el.parent.setVisible ~= nil then
            el.parent:setVisible(vis)
        end
    end)
end

-- Size the green fill to a fraction of its background bar. Bitmap sizes are
-- normalized screen units at runtime, so scale the parent's stored width.
local function setBarFill(bg, fill, frac)
    if bg == nil or fill == nil then return end
    frac = math.max(0, math.min(1, frac or 0))
    pcall(function()
        if bg.size ~= nil and fill.setSize ~= nil then
            local w = math.max(bg.size[1] * frac, 0.00001)
            fill:setSize(w, fill.size and fill.size[2] or nil)
        end
    end)
end

-- Fill the compact stats lines from the active campaign.
function MFC_MenuPage:updateStats()
    guard_pcall(function()
        local MFC = MayflowerFarmChallenge
        local c = MFC and MFC.campaign
        local slots = { self.statM1, self.statM2, self.statM3, self.statM4 }
        if c == nil then
            setStat(self.statName, "No active challenge")
            setStat(self.statGoal, "Create one below")
            setStat(self.statCurrent, "")
            setStat(self.statRules, "")
            for _, slot in ipairs(slots) do setStat(slot, "") end
            -- Collapse the rows that carry no information without a campaign.
            -- Only touch visibility/reflow when the state actually changed, so
            -- the 500ms refresh doesn't fight the user's scrolling.
            if self.mfcRowSig ~= "none" then
                self.mfcRowSig = "none"
                setRowVisible(self.statCurrent, false)
                setRowVisible(self.statRules, false)
                for _, slot in ipairs(slots) do setRowVisible(slot, false) end
                for i = 1, 4 do setRowVisible(self["msBar" .. i .. "Bg"], false) end
                pcall(function()
                    if self.goalBarBg ~= nil then
                        self.goalBarBg:setVisible(false)
                        if self.goalBarBg.parent ~= nil then self.goalBarBg.parent:setVisible(false) end
                    end
                end)
                self:safeInvalidateLayout()
            end
            return
        end
        local sig = "c" .. tostring(#(c.milestones or {}))
        local sigChanged = (self.mfcRowSig ~= sig)
        if sigChanged then
            self.mfcRowSig = sig
            setRowVisible(self.statCurrent, true)
            setRowVisible(self.statRules, true)
            pcall(function()
                if self.goalBarBg ~= nil then
                    self.goalBarBg:setVisible(true)
                    if self.goalBarBg.parent ~= nil then self.goalBarBg.parent:setVisible(true) end
                end
            end)
        end

        -- Metric helpers matching the main script's evaluation.
        local function metricValue(metric)
            -- Absolute net worth/fields; earned income remains run-specific.
            if MFC.getChallengeMetricPublic ~= nil then
                return MFC.getChallengeMetricPublic(metric) or 0
            end
            if metric == "OwnFields" then
                return (MFC.getOwnedFieldsPublic and MFC.getOwnedFieldsPublic()) or 0
            elseif metric == "Income" then
                return (MFC.getIncomePublic and MFC.getIncomePublic()) or 0
            end
            return (MFC.getNetWorthPublic and MFC.getNetWorthPublic()) or 0
        end
        local function metricFmt(metric, v)
            if metric == "OwnFields" then return string.format("%d fields", math.floor(v or 0)) end
            return money(v)
        end
        local function metricLabel(metric)
            if metric == "OwnFields" then return "Fields owned" end
            if metric == "Income" then return "Money earned" end
            return "Net worth"
        end

        local goal, goalMetric = 0, "NetWorth"
        local doneCount, total = 0, 0
        for _, m in ipairs(c.milestones or {}) do
            if m.kind == "FinalGoal" then
                goal = m.target
                goalMetric = m.metric or "NetWorth"
            end
            total = total + 1
            if m.completed then doneCount = doneCount + 1 end
        end
        local yrs = c.years or 0
        local state = c.state or "active"
        local live = (state == "active")
        local stateSuffix = ""
        if state == "won" then stateSuffix = "  -  COMPLETED!"
        elseif state == "failed" then stateSuffix = "  -  FAILED (time limit)" end
        setStat(self.statName, string.format("%s  (%s)%s", c.name or "Campaign", c.difficulty or "", stateSuffix))

        if live then
            local current = metricValue(goalMetric)
            local pct = (goal > 0) and math.min(current / goal, 1) or 0
            setStat(self.statGoal, string.format("Goal:  %s %s in %d %s   (%d%%)",
                metricLabel(goalMetric), metricFmt(goalMetric, goal), yrs,
                (yrs == 1) and "year" or "years", math.floor(pct * 100 + 0.5)))
            setBarFill(self.goalBarBg, self.goalBarFill, pct)
            local chYear = (MFC.getChallengeYearPublic and MFC.getChallengeYearPublic()) or 1
            setStat(self.statCurrent, string.format("Now:  %s   (%d of %d milestones done)   Year %d of %d",
                metricFmt(goalMetric, current), doneCount, total,
                math.min(chYear, c.years or chYear), c.years or 0))
            pcall(function()
                if self.goalBarFill.setImageColor ~= nil then
                    self.goalBarFill:setImageColor(nil, 0.4870, 0.6613, 0.0, 1)
                end
            end)
        else
            -- Frozen result card: nothing here moves anymore.
            local won = (state == "won")
            local pct = won and 1
                or ((goal > 0 and c.endGoalValue ~= nil) and math.min(c.endGoalValue / goal, 1) or 0)
            setStat(self.statGoal, string.format("Goal:  %s %s in %d %s   -  %s",
                metricLabel(goalMetric), metricFmt(goalMetric, goal), yrs,
                (yrs == 1) and "year" or "years", won and "ACHIEVED" or "NOT REACHED"))
            setBarFill(self.goalBarBg, self.goalBarFill, pct)
            setStat(self.statCurrent, string.format("Finished in year %d of %d   -   %d of %d milestones   -   Money earned %s",
                c.endYearsUsed or 1, yrs, doneCount, total,
                money((MFC.getIncomePublic and MFC.getIncomePublic()) or 0)))
            pcall(function()
                if self.goalBarFill.setImageColor ~= nil then
                    if won then
                        self.goalBarFill:setImageColor(nil, 0.85, 0.62, 0.08, 1) -- gold
                    else
                        self.goalBarFill:setImageColor(nil, 0.55, 0.16, 0.10, 1) -- muted red
                    end
                end
            end)
        end

        local rules = {}
        local rmap = {
            noWorkers = "no workers", noContractMachines = "no contract machines", noLeasing = "no leasing",
            noTeleport = "no fast travel", noLoans = "no loans", manualOnly = "no GPS",
        }
        for id in pairs(c.restrictions or {}) do table.insert(rules, rmap[id] or id) end
        setStat(self.statRules, "Rules:  " .. (#rules > 0 and table.concat(rules, ", ") or "none"))

        -- Milestone lines with progress percent in text.
        for i = 1, #slots do
            local m = (c.milestones or {})[i]
            if m ~= nil then
                local metric = m.metric or m.kind
                if metric == "FinalGoal" then metric = goalMetric end
                local label = (m.kind == "FinalGoal") and "Final goal" or metricLabel(metric)
                local frac
                if m.completed then frac = 1
                elseif not live then frac = 0
                else frac = ((m.target or 0) > 0 and math.min(metricValue(metric) / m.target, 1) or 0) end
                local statusStr
                if m.completed then statusStr = "DONE"
                elseif (not live) or m.missed then statusStr = "MISSED"
                else statusStr = string.format("%d%%", math.floor(frac * 100 + 0.5)) end
                setStat(slots[i], string.format("%d. %s  %s  -  by year %d  -  %s",
                    i, label, metricFmt(metric, m.target), m.dueYear or 0, statusStr))
                setBarFill(self["msBar" .. i .. "Bg"], self["msBar" .. i .. "Fill"], frac)
                if sigChanged then
                    setRowVisible(slots[i], true)
                    setRowVisible(self["msBar" .. i .. "Bg"], true)
                end
            else
                setStat(slots[i], "")
                if sigChanged then
                    setRowVisible(slots[i], false)
                    setRowVisible(self["msBar" .. i .. "Bg"], false)
                end
            end
        end
        if sigChanged then
            self:safeInvalidateLayout()
        end
    end)
end

-- Refresh the goal-value picker to match the selected goal type, keeping the
-- selection index if possible.
function MFC_MenuPage:refreshGoalTexts(keepState)
    guard_pcall(function()
        local gt = self:goalType()
        local previous = nil
        if keepState then
            previous = selectedMappedValue(self.optGoal, self.goalValueOptions, nil)
        end
        local values, current = self:validTargetsAbove(gt.id, gt.steps)
        local texts = {}
        for _, value in ipairs(values) do table.insert(texts, gt.fmt(value)) end
        self.goalValueOptions = values
        self.goalMinimum = current
        setTexts(self.optGoal, texts)

        local targetState = math.min(4, #texts)
        if keepState and previous ~= nil then
            targetState = self:nearestIndex(values, previous)
        end
        setState(self.optGoal, math.max(1, targetState))
    end)
end

-- Fill the picker option texts once.
function MFC_MenuPage:populateOptions()
    guard_pcall(function()
        setTexts(self.optDifficulty, DIFFICULTIES)
        local function stepText(v)
            if v == UNCHANGED then return "Leave unchanged" end
            return money(v)
        end
        local moneyTexts = {}
        for _, v in ipairs(MONEY_STEPS) do table.insert(moneyTexts, stepText(v)) end
        setTexts(self.optMoney, moneyTexts)
        local loanTexts = {}
        for _, v in ipairs(LOAN_STEPS) do table.insert(loanTexts, stepText(v)) end
        setTexts(self.optLoan, loanTexts)

        local typeTexts = {}
        for _, t in ipairs(GOAL_TYPES) do table.insert(typeTexts, t.label) end
        setTexts(self.optGoalType, typeTexts)
        setTexts(self.optIncomeMode, { "Income earned since start", "Net balance gain" })

        local yearTexts = {}
        for _, v in ipairs(YEARS_STEPS) do
            table.insert(yearTexts, tostring(v) .. ((v == 1) and " year" or " years"))
        end
        setTexts(self.optYears, yearTexts)
        setTexts(self.optEconomy, ECON_STEPS)

        local msTypeTexts = {}
        for _, t in ipairs(MS_TYPES) do table.insert(msTypeTexts, t.label) end
        setTexts(self.optM1Type, msTypeTexts)
        setTexts(self.optM2Type, msTypeTexts)
        setTexts(self.optM3Type, msTypeTexts)

        -- Toggles need their two texts set explicitly; without them the state /
        -- highlight math is undefined and the green marker slides off the control.
        for ctrlId in pairs(TOGGLE_IDS) do
            local ctrl = self[ctrlId]
            setTexts(ctrl, { "OFF", "ON" })
        end

        -- sensible defaults if nothing set yet
        if not self.initialized then
            self.initialized = true
            setState(self.optDifficulty, 2)
            setState(self.optMoney, 1)    -- Leave unchanged (no forced balance)
            setState(self.optLoan, 1)     -- Leave unchanged (no forced loan)
            setState(self.optGoalType, 1) -- Net worth
            setState(self.optIncomeMode, 1) -- Income earned since start
            setState(self.optYears, 2)    -- 2 years
            setState(self.optEconomy, 1)  -- Default
            setState(self.optM1Type, 1)   -- Net worth
            setState(self.optM2Type, 1)
            setState(self.optM3Type, 1)
            setState(self.optM1, 1)       -- Auto
            setState(self.optM2, 1)       -- Auto
            setState(self.optM3, 1)       -- Auto
            for ctrlId in pairs(TOGGLE_IDS) do
                setToggle(self[ctrlId], false)
            end
            self:refreshGoalTexts(false)
            for i = 1, 3 do self:refreshMilestoneTexts(i, false) end
        else
            self:refreshGoalTexts(true)
            for i = 1, 3 do self:refreshMilestoneTexts(i, true) end
        end
    end)
end

-- Native bottom-bar actions (the base-game way): Create on MENU_ACTIVATE,
-- Randomize on MENU_EXTRA_1, Abandon on MENU_EXTRA_2 (only with an active
-- challenge). Courseplay-confirmed construction.
function MFC_MenuPage:updateMenuButtons()
    guard_pcall(function()
        local MFC = MayflowerFarmChallenge
        local hasCampaign = MFC ~= nil and MFC.campaign ~= nil
        local state = hasCampaign and (MFC.campaign.state or "active") or "none"
        -- showWhenPaused is required: the Esc menu pauses the game, and
        -- assignMenuButtonInfo disables (mouse-blocks) buttons without it.
        self.menuButtonInfo = {
            { inputAction = InputAction.MENU_BACK, showWhenPaused = true },
            { inputAction = InputAction.MENU_ACTIVATE, text = "Create and start",
              showWhenPaused = true, callback = function() self:onClickStart() end },
            { inputAction = InputAction.MENU_EXTRA_1, text = "Randomize",
              showWhenPaused = true, callback = function() self:onClickRoll() end },
        }
        if hasCampaign then
            local label = (state == "active") and "Abandon challenge" or "Clear result"
            table.insert(self.menuButtonInfo, {
                inputAction = InputAction.MENU_EXTRA_2, text = label,
                showWhenPaused = true, callback = function() self:onClickAbandon() end })
        end
        self.mfcButtonsSig = state
        if self.setMenuButtonInfoDirty ~= nil then
            self:setMenuButtonInfoDirty()
        end
    end)
end

function MFC_MenuPage:updateStatus()
    guard_pcall(function()
        local MFC = MayflowerFarmChallenge
        local active = MFC and MFC.campaign
        -- Bottom-bar buttons refresh when the campaign state changes.
        local btnSig = (active ~= nil) and (active.state or "active") or "none"
        if self.mfcButtonsSig ~= btnSig then
            self:updateMenuButtons()
        end
        if self.statusText ~= nil then
            if active ~= nil then
                self.statusText:setText("Active: " .. (active.name or ""))
            else
                self.statusText:setText("Set options, then create")
            end
        end
    end)
end

-- Option change handler: the goal-type picker re-populates the goal values;
-- everything else is read on Create.
-- Option change handler. The engine's callback argument order isn't something
-- we can rely on, so rather than identifying which picker changed, refresh all
-- type-dependent target lists (states are preserved, so this is cheap and safe).
function MFC_MenuPage:onChangeOption(...)
    guard_pcall(function()
        -- Any manual edit means the challenge is no longer a pure roll.
        self.builtFromRoll = false
        self:refreshGoalTexts(true)
        for i = 1, 3 do self:refreshMilestoneTexts(i, true) end
    end)
end
function MFC_MenuPage:onToggle() end

function MFC_MenuPage:onClickAbandon()
    guard_pcall(function()
        local MFC = MayflowerFarmChallenge
        if MFC == nil or MFC.campaign == nil then return end
        local state = MFC.campaign.state or "active"
        if state ~= "active" then
            -- Finished run: the result is already recorded in history, so
            -- clearing it is low-stakes - no confirmation needed.
            self:onAbandonConfirmed(true)
            return
        end
        -- Confirmed FS25 API (Courseplay usage): YesNoDialog.show(callback, target, text)
        if YesNoDialog ~= nil and YesNoDialog.show ~= nil then
            YesNoDialog.show(self.onAbandonConfirmed, self,
                "Abandon the current challenge? This cannot be undone.")
        else
            self:onAbandonConfirmed(true)
        end
    end)
end

function MFC_MenuPage:onAbandonConfirmed(yes)
    guard_pcall(function()
        if yes ~= true then return end
        local MFC = MayflowerFarmChallenge
        if MFC ~= nil and MFC.abandonCampaign ~= nil then
            MFC.abandonCampaign()
        end
        if self.statusText ~= nil then self.statusText:setText("Cleared") end
        self:updateStatus()
        self:updateStats()
    end)
end

-- Randomize the pickers/toggles to a coherent random campaign of the
-- currently-selected difficulty (uses the roller, then reflects it into the UI).
function MFC_MenuPage:onClickRoll()
    guard_pcall(function()
        if MFC_Roller == nil then return end
        local MFC = MayflowerFarmChallenge
        local maps = nil -- roller falls back to the base map
        local tierIdx = getState(self.optDifficulty)
        local tierId = DIFFICULTIES[tierIdx] or "Cooperative"
        local rolled = MFC_Roller.roll(tierId, maps, nil)

        -- Reflect rolled values into the pickers/toggles, including the rolled
        -- goal metric and its target.
        local metricIdx = ({ NetWorth = 1, OwnFields = 2, Income = 3 })[rolled.goalMetric or "NetWorth"] or 1
        -- Randomize never forces the player's economy: starting cash and loan
        -- stay on "Leave unchanged" so a rolled challenge begins from the farm's
        -- real balance. The player can still set them by hand afterwards.
        setState(self.optMoney, 1)
        setState(self.optLoan, 1)
        setState(self.optGoalType, metricIdx)
        -- Starting money/debt affect the minimum valid net-worth target, so they
        -- must be reflected before rebuilding the goal list.
        self:refreshGoalTexts(false)
        local goal = rolled.goalTarget
        if goal == nil then
            goal = 0
            for _, m in ipairs(rolled.milestones) do if m.kind == "FinalGoal" then goal = m.target end end
        end
        setState(self.optGoal, self:nearestIndex(self.goalValueOptions or GOAL_TYPES[metricIdx].steps, goal))
        setState(self.optYears, self:nearestIndex(YEARS_STEPS, rolled.years))
        local econMap = { [""] = 1, easy = 2, normal = 3, hard = 4 }
        setState(self.optEconomy, econMap[rolled.econDifficulty] or 1)
        setState(self.optM1Type, metricIdx)
        setState(self.optM2Type, metricIdx)
        setState(self.optM3Type, metricIdx)
        setState(self.optM1, 1)
        setState(self.optM2, 1)
        setState(self.optM3, 1)
        for i = 1, 3 do self:refreshMilestoneTexts(i, false) end

        for ctrlId, rid in pairs(TOGGLE_IDS) do
            setToggle(self[ctrlId], rolled.restrictions[rid] == true)
        end

        self.builtFromRoll = true
        if self.statusText ~= nil then self.statusText:setText("Randomized - tweak or Create & start") end
    end)
end

function MFC_MenuPage:nearestIndex(steps, value)
    local bestI, bestD = 1, math.huge
    for i, v in ipairs(steps) do
        -- Skip non-numeric entries (e.g. the "Leave unchanged" marker).
        if type(v) == "number" then
            local d = math.abs(v - (value or 0))
            if d < bestD then bestD = d; bestI = i end
        end
    end
    return bestI
end

-- Create flow: ask for a name (confirmed FS25 TextInputDialog API), then build.
function MFC_MenuPage:onClickStart()
    guard_pcall(function()
        local prefill = self.lastChallengeName or "Custom Challenge"
        if TextInputDialog ~= nil and TextInputDialog.show ~= nil then
            TextInputDialog.show(self.onNameEntered, self, prefill,
                "Name your challenge", nil, 30, "Create")
        else
            self:onNameEntered(prefill, true)
        end
    end)
end

function MFC_MenuPage:onNameEntered(name, clickOk)
    guard_pcall(function()
        if clickOk ~= true then return end
        name = tostring(name or "")
        name = name:gsub("^%s+", ""):gsub("%s+$", "")
        if name == "" then name = "Custom Challenge" end
        self.lastChallengeName = name
        self:buildAndStart(name)
    end)
end

-- Build a campaign from the current UI state and start it.
function MFC_MenuPage:buildAndStart(challengeName)
    guard_pcall(function()
        local MFC = MayflowerFarmChallenge
        plog(string.format(
            "Create pressed. states: diff=%d money=%d loan=%d goalType=%d goal=%d years=%d econ=%d m1t=%d m1=%d m2t=%d m2=%d m3t=%d m3=%d",
            getState(self.optDifficulty), getState(self.optMoney), getState(self.optLoan),
            getState(self.optGoalType), getState(self.optGoal), getState(self.optYears),
            getState(self.optEconomy),
            getState(self.optM1Type), getState(self.optM1),
            getState(self.optM2Type), getState(self.optM2),
            getState(self.optM3Type), getState(self.optM3)))
        local diffIdx = getState(self.optDifficulty)
        -- nil = "Leave unchanged" -> -1 sentinel, so save setup never overwrites
        -- the player's real cash or loan.
        local money_ = self:selectedStartMoney() or -1
        local loan = self:selectedStartDebt() or -1
        local incomeMode = INCOME_MODES[getState(self.optIncomeMode)] or "gross"
        local gt = self:goalType()
        local goal = selectedMappedValue(self.optGoal, self.goalValueOptions, nil)
        local goalFloor = self:projectedMetric(gt.id)
        if goal == nil or goal <= goalFloor then
            goal = generatedTargetAbove(gt.id, goalFloor)
        end
        local years = YEARS_STEPS[getState(self.optYears)] or 2
        local econIdx = getState(self.optEconomy)
        local econ = ({ "", "easy", "normal", "hard" })[econIdx] or ""

        local restrictions = {}
        for ctrlId, rid in pairs(TOGGLE_IDS) do
            if getToggle(self[ctrlId]) then
                restrictions[rid] = true
            end
        end

        -- Milestones: three checkpoints, each with its own metric and target,
        -- plus the final goal. "Auto" derives the target: from the goal curve
        -- when the milestone metric matches the goal metric, otherwise from a
        -- sensible per-metric default.
        local milestones = {}
        local steps = 3
        for i = 1, steps do
            local frac = i / (steps + 1)
            local mt = self:msType(i)
            local current = self:projectedMetric(mt.id)
            local selected = selectedMappedValue(self["optM" .. i],
                self.milestoneValueOptions and self.milestoneValueOptions[i], 0)
            local target
            if selected ~= nil and selected > current then
                target = selected
            elseif mt.id == gt.id then
                -- Auto checkpoints sit between the farm's starting value and the
                -- final target, so none can be completed the instant it begins.
                if mt.id == "OwnFields" then
                    target = math.floor(current + ((goal - current) * frac) + 0.5)
                else
                    target = roundMoneyTarget(current + ((goal - current) * (frac ^ 1.3)))
                end
            else
                -- Different-metric Auto checkpoints grow outward from that
                -- metric's own starting value.
                if mt.id == "OwnFields" then
                    target = math.floor(current) + math.max(1, math.floor(8 * frac + 0.5))
                else
                    target = roundMoneyTarget(current + (1000000 * frac))
                end
            end
            if target <= current then
                target = generatedTargetAbove(mt.id, current)
            end
            table.insert(milestones, {
                order = i, kind = mt.id, metric = mt.id,
                target = target,
                dueYear = math.max(1, math.floor(frac * years + 0.5)), dueQuarter = 4,
                title = mt.title, completed = false,
            })
        end
        table.insert(milestones, {
            order = steps + 1, kind = "FinalGoal", metric = gt.id, target = goal,
            dueYear = years, dueQuarter = 4, title = "Final goal", completed = false,
        })

        local campaign = {
            seed = math.random(1, 1000000),
            name = challengeName or "Custom Challenge",
            difficulty = self.builtFromRoll and (DIFFICULTIES[diffIdx] or "Custom") or "Custom",
            mapId = "", mapLabel = "",
            startMoney = money_,
            years = years,
            startType = "withFarm",
            startDebt = loan,
            econDifficulty = econ,
            setsEconomy = true,
            incomeMode = incomeMode,
            restrictions = restrictions,
            brandMode = "none", brandSet = {}, brandListStr = "",
            blockedCategories = {},
            milestones = milestones,
        }

        plog(string.format("Built campaign: goalType=%s goal=%s startValue=%s milestones=%d",
            gt.id, tostring(goal), tostring(goalFloor), #milestones))
        if MFC.startCampaign ~= nil then
            MFC.startCampaign(campaign)
            plog("startCampaign returned; campaign active = " .. tostring(MFC.campaign ~= nil))
        else
            plog("ERROR: MFC.startCampaign is nil")
        end
        local statusMsg = "Started: " .. campaign.name
        if self.statusText ~= nil then self.statusText:setText(statusMsg) end
        self:updateStatus()
        self:updateStats()
    end)
end

-- ---- helpers ----
function guard_pcall(fn)
    local ok, err = pcall(fn)
    if not ok then
        plog("action error: " .. tostring(err))
        -- Surface the failure in-game so silent breakage is visible.
        local page = MFC_MenuPage and MFC_MenuPage.lastInstance
        if page ~= nil and page.statusText ~= nil and page.statusText.setText ~= nil then
            pcall(function()
                page.statusText:setText("ERROR: " .. tostring(err):sub(1, 120))
            end)
        end
    end
end
