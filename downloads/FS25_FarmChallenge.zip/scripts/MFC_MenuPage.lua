--
-- MFC_MenuPage.lua
--
-- The Farm Challenge page in the Escape menu.
--
-- The top of the page is a live read-out of the running challenge. Below it is
-- the editor: native FS25 settings controls (MultiTextOption pickers used both
-- as value pickers and as ON/OFF toggles) inside one scrolling list. The first
-- rows are the Workshop, so premades and saved presets load straight into the
-- editor and can be tweaked before starting.
--
-- Targets always sit above what the farm is worth right now, so no challenge
-- can complete the instant it begins.
--

MFC_MenuPage = {}
local MFC_MenuPage_mt = Class(MFC_MenuPage, TabbedMenuFrameElement)

local function plog(msg)
    local MFC = MayflowerFarmChallenge
    if MFC == nil or MFC.DEBUG ~= true then return end
    print(string.format("[FarmChallenge] [menu] %s", msg))
end

-- Local, not global: every FS25 mod shares one Lua environment, so a generic
-- global helper name is a collision waiting to happen.
local function guardPcall(fn)
    local ok, err = pcall(fn)
    if ok then return end
    plog("action error: " .. tostring(err))
    -- Surface the failure on the page so silent breakage is visible.
    local page = MFC_MenuPage.lastInstance
    if page ~= nil and page.statusText ~= nil and page.statusText.setText ~= nil then
        pcall(function()
            page.statusText:setText("ERROR: " .. tostring(err):sub(1, 120))
        end)
    end
end

local function money(v)
    local s = string.format("%d", math.floor(math.abs(v or 0) + 0.5))
    local out, count = "", 0
    for i = #s, 1, -1 do
        out = s:sub(i, i) .. out
        count = count + 1
        if count % 3 == 0 and i > 1 then out = "," .. out end
    end
    return ((v or 0) < 0 and "-$" or "$") .. out
end

-- ============================================================
-- Option tables
-- ============================================================

local DIFFICULTIES = { "Homestead", "Cooperative", "Estate", "Empire" }

-- A unique, non-numeric marker for the first entry of the money/loan pickers.
-- Choosing it means "leave this exactly as it is" -- the mod makes no forced
-- economy change. It is the default, so a challenge never overwrites an
-- existing farm's balance or debt unless the player deliberately picks a value.
local UNCHANGED = {}

local MONEY_STEPS = { UNCHANGED, 0, 5000, 10000, 20000, 50000, 75000, 100000, 150000,
                      250000, 350000, 500000, 650000, 800000, 1000000, 1500000, 2000000 }
local LOAN_STEPS  = { UNCHANGED, 0, 25000, 50000, 100000, 200000, 300000, 450000,
                      600000, 750000, 1000000 }
local LIMIT_STEPS = { UNCHANGED, 0, 50000, 100000, 200000, 300000, 500000, 750000,
                      1000000, 1500000, 2000000 }
local YEARS_STEPS = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
local ECON_STEPS  = { "Default", "Easy", "Normal", "Hard" }
local ECON_IDS    = { "", "easy", "normal", "hard" }
local INCOME_MODES = { "gross", "net" }

-- What the final goal (and any matching auto milestone) measures.
local GOAL_TYPES = {
    { id = "NetWorth", label = "Net worth",
      steps = { 500000, 750000, 1000000, 1500000, 2000000, 3000000, 5000000, 8000000,
                10000000, 12000000, 15000000, 20000000, 30000000, 50000000 } },
    { id = "OwnFields", label = "Fields owned",
      steps = { 3, 5, 8, 10, 12, 15, 20, 25, 30, 40 } },
    { id = "Income", label = "Money earned",
      steps = { 250000, 500000, 750000, 1000000, 1500000, 2500000, 4000000, 6000000,
                8000000, 10000000, 15000000 } },
}

-- Manual milestone targets. Index 1 is always "Auto".
local MONEY_MS_STEPS = { 25000, 50000, 100000, 150000, 250000, 400000, 600000, 800000,
                         1000000, 1500000, 2000000, 3000000, 4000000, 6000000, 8000000,
                         10000000, 15000000, 20000000 }
local FIELD_MS_STEPS = { 1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30 }

local MS_TYPES = {
    { id = "NetWorth",  label = "Net worth",    title = "Grow net worth" },
    { id = "OwnFields", label = "Fields owned", title = "Own fields" },
    { id = "Income",    label = "Money earned", title = "Earn money" },
}

local METRIC_INDEX = { NetWorth = 1, OwnFields = 2, Income = 3 }

local TOGGLE_IDS = {
    chkNoWorkers = "noWorkers",
    chkNoContracts = "noContractMachines",
    chkNoLeasing = "noLeasing",
    chkNoTeleport = "noTeleport",
    chkNoLoans = "noLoans",
    chkManualOnly = "manualOnly",
}

-- Every option/toggle id, for snapshotting state around a layout pass. FS25's
-- layout re-init can otherwise wipe element states.
local OPTION_IDS = {
    "optChallenge", "optDifficulty",
    "optMoney", "optLoan", "optLoanLimit",
    "optGoalType", "optGoal", "optIncomeMode", "optYears", "optEconomy",
    "optM1Type", "optM1", "optM2Type", "optM2", "optM3Type", "optM3",
    "chkNoWorkers", "chkNoContracts", "chkNoLeasing", "chkNoTeleport",
    "chkNoLoans", "chkManualOnly",
}

-- ============================================================
-- Formatting and target maths
-- ============================================================

local function metricLabel(metric)
    if metric == "OwnFields" then return "Fields owned" end
    if metric == "Income" then return "Money earned" end
    return "Net worth"
end

local function metricFmt(metric, v)
    if metric == "OwnFields" then return string.format("%d fields", math.floor(v or 0)) end
    return money(v)
end

local function msStepsFor(metricId)
    if metricId == "OwnFields" then return FIELD_MS_STEPS end
    return MONEY_MS_STEPS
end

local function roundMoneyTarget(v)
    return math.ceil((v or 0) / 25000) * 25000
end

-- The smallest sensible target strictly above `current`, used when every preset
-- step is already below the farm's value.
local function generatedTargetAbove(metricId, current)
    current = math.max(0, current or 0)
    if metricId == "OwnFields" then return math.floor(current) + 1 end
    local increment = math.max(250000, roundMoneyTarget(current * 0.10))
    return roundMoneyTarget(current + increment)
end

local function deadlineText(dueYear, dueQuarter)
    dueQuarter = dueQuarter or 4
    if dueQuarter >= 4 then return string.format("year %d", dueYear or 1) end
    return string.format("year %d Q%d", dueYear or 1, dueQuarter)
end

-- ============================================================
-- Element helpers
-- ============================================================

local function setTexts(opt, texts)
    if opt == nil or opt.setTexts == nil then return end
    opt:setTexts(texts)
    -- FS25 element quirk: setTexts does not update numTexts, which desyncs the
    -- displayed text from getState and breaks controller cycling.
    opt.numTexts = #texts
end

local function setState(opt, i)
    if opt ~= nil and opt.setState ~= nil then opt:setState(i, nil, true) end
end

local function getState(opt)
    if opt ~= nil and opt.getState ~= nil then return opt:getState() end
    return 1
end

local function selectedMappedValue(ctrl, values, fallback)
    if values == nil then return fallback end
    local v = values[getState(ctrl)]
    if v == nil then return fallback end
    return v
end

-- Toggles are MultiTextOptions with two states: 1 = OFF, 2 = ON. Driving them
-- by state (rather than setIsChecked) keeps the highlight in bounds.
local function setToggle(ctrl, on)
    setState(ctrl, on and 2 or 1)
end

local function getToggle(ctrl)
    if ctrl ~= nil and ctrl.getIsChecked ~= nil then
        local ok, v = pcall(function() return ctrl:getIsChecked() end)
        if ok and type(v) == "boolean" then return v end
    end
    return getState(ctrl) == 2
end

local function indexOfValue(values, wanted)
    for index, value in ipairs(values or {}) do
        if type(value) == "number" and math.abs(value - (wanted or 0)) < 0.5 then
            return index
        end
    end
    return nil
end

-- ============================================================
-- Construction
-- ============================================================

function MFC_MenuPage.new(target, custom_mt)
    local self = TabbedMenuFrameElement.new(target, custom_mt or MFC_MenuPage_mt)
    MFC_MenuPage.lastInstance = self
    return self
end

function MFC_MenuPage:nearestIndex(steps, value)
    local bestIndex, bestDistance = 1, math.huge
    for i, v in ipairs(steps or {}) do
        -- Skip non-numeric entries such as the "Leave unchanged" marker.
        if type(v) == "number" then
            local d = math.abs(v - (value or 0))
            if d < bestDistance then bestDistance = d; bestIndex = i end
        end
    end
    return bestIndex
end

-- ============================================================
-- Reading the editor
-- ============================================================

function MFC_MenuPage:goalType()
    return GOAL_TYPES[getState(self.optGoalType)] or GOAL_TYPES[1]
end

function MFC_MenuPage:msType(i)
    return MS_TYPES[getState(self["optM" .. i .. "Type"])] or MS_TYPES[1]
end

-- These return nil for "leave unchanged", so callers know not to force a value.
function MFC_MenuPage:selectedStartMoney()
    local v = MONEY_STEPS[getState(self.optMoney)]
    if v == nil or v == UNCHANGED then return nil end
    return v
end

function MFC_MenuPage:selectedStartDebt()
    local v = LOAN_STEPS[getState(self.optLoan)]
    if v == nil or v == UNCHANGED then return nil end
    return v
end

function MFC_MenuPage:selectedLoanLimit()
    local v = LIMIT_STEPS[getState(self.optLoanLimit)]
    if v == nil or v == UNCHANGED then return nil end
    return v
end

-- What a metric will read the moment this challenge becomes active: existing
-- assets and land count, and the chosen starting money and debt are applied.
function MFC_MenuPage:projectedMetric(metricId)
    local MFC = MayflowerFarmChallenge
    if MFC == nil then return 0 end
    if MFC.getProjectedStartMetricPublic ~= nil then
        return MFC.getProjectedStartMetricPublic(metricId,
            self:selectedStartMoney(), self:selectedStartDebt()) or 0
    end
    if metricId == "OwnFields" then return MFC.getOwnedFieldsPublic() or 0 end
    if metricId == "Income" then return 0 end
    return MFC.getNetWorthPublic() or 0
end

-- Only offer targets the farm has not already reached.
function MFC_MenuPage:validTargetsAbove(metricId, sourceSteps)
    local current = self:projectedMetric(metricId)
    local out = {}
    for _, value in ipairs(sourceSteps or {}) do
        if value > current then table.insert(out, value) end
    end
    if #out == 0 then table.insert(out, generatedTargetAbove(metricId, current)) end
    return out, current
end

-- ============================================================
-- Layout state
-- ============================================================

function MFC_MenuPage:snapshotStates()
    local snap = {}
    for _, id in ipairs(OPTION_IDS) do snap[id] = getState(self[id]) end
    return snap
end

function MFC_MenuPage:restoreStates(snap)
    if snap == nil then return end
    for _, id in ipairs(OPTION_IDS) do
        if snap[id] ~= nil then setState(self[id], snap[id]) end
    end
end

function MFC_MenuPage:safeInvalidateLayout()
    guardPcall(function()
        if self.layout == nil or self.layout.invalidateLayout == nil then return end
        local snap = self:snapshotStates()
        self.layout:invalidateLayout()
        self:restoreStates(snap)
    end)
end

-- ============================================================
-- Target pickers
-- ============================================================

function MFC_MenuPage:refreshGoalTexts(keepState)
    guardPcall(function()
        local gt = self:goalType()
        local previous = keepState and selectedMappedValue(self.optGoal, self.goalValueOptions, nil) or nil
        local values, current = self:validTargetsAbove(gt.id, gt.steps)
        local texts = {}
        for _, value in ipairs(values) do table.insert(texts, metricFmt(gt.id, value)) end
        self.goalValueOptions = values
        self.goalMinimum = current
        setTexts(self.optGoal, texts)

        local targetState = math.min(4, #texts)
        if keepState and previous ~= nil then
            targetState = self:nearestIndex(values, previous)
        end
        setState(self.optGoal, math.max(1, math.min(targetState, #texts)))
    end)
end

function MFC_MenuPage:refreshMilestoneTexts(i, keepState)
    guardPcall(function()
        local ctrl = self["optM" .. i]
        if ctrl == nil then return end
        local mt = self:msType(i)
        self.milestoneValueOptions = self.milestoneValueOptions or {}
        local previous = keepState
            and selectedMappedValue(ctrl, self.milestoneValueOptions[i], 0) or nil

        local valid = self:validTargetsAbove(mt.id, msStepsFor(mt.id))
        local values = { 0 } -- 0 means Auto
        local texts = { "Auto" }
        for _, value in ipairs(valid) do
            table.insert(values, value)
            table.insert(texts, metricFmt(mt.id, value))
        end
        self.milestoneValueOptions[i] = values
        setTexts(ctrl, texts)

        local targetState = 1
        if keepState and previous ~= nil and previous > 0 then
            targetState = self:nearestIndex(values, previous)
        end
        setState(ctrl, math.max(1, math.min(targetState, #texts)))
    end)
end

-- Select an exact value, inserting it into the picker if it isn't a preset
-- step. Returns true when the wanted value had to be raised to stay above the
-- farm's current value.
function MFC_MenuPage:setExactGoalTarget(wanted)
    local gt = self:goalType()
    local minimum = self:projectedMetric(gt.id)
    local raised = false
    if wanted == nil or wanted <= minimum then
        wanted = generatedTargetAbove(gt.id, minimum)
        raised = true
    end

    local values = self.goalValueOptions or {}
    local index = indexOfValue(values, wanted)
    if index == nil then
        table.insert(values, wanted)
        table.sort(values)
        local texts = {}
        for _, value in ipairs(values) do table.insert(texts, metricFmt(gt.id, value)) end
        self.goalValueOptions = values
        setTexts(self.optGoal, texts)
        index = indexOfValue(values, wanted) or 1
    end
    setState(self.optGoal, index)
    return raised
end

function MFC_MenuPage:setExactMilestoneTarget(i, wanted)
    local mt = self:msType(i)
    local minimum = self:projectedMetric(mt.id)
    local raised = false
    if wanted == nil or wanted <= minimum then
        wanted = generatedTargetAbove(mt.id, minimum)
        raised = true
    end

    self.milestoneValueOptions = self.milestoneValueOptions or {}
    local values = self.milestoneValueOptions[i] or { 0 }
    local index = indexOfValue(values, wanted)
    if index == nil then
        local positives = { wanted }
        for _, value in ipairs(values) do
            if type(value) == "number" and value > 0 then table.insert(positives, value) end
        end
        table.sort(positives)
        values = { 0 }
        local texts = { "Auto" }
        for _, value in ipairs(positives) do
            table.insert(values, value)
            table.insert(texts, metricFmt(mt.id, value))
        end
        self.milestoneValueOptions[i] = values
        setTexts(self["optM" .. i], texts)
        index = indexOfValue(values, wanted) or 1
    end
    setState(self["optM" .. i], index)
    return raised
end

-- ============================================================
-- Challenge picker
--
-- One row decides what you are building. Picking a premade applies it to every
-- row below straight away -- choosing it IS loading it, so there is no separate
-- load step. Editing anything afterwards flips the picker back to "Custom
-- setup", because it is no longer that premade.
-- ============================================================

function MFC_MenuPage:refreshChallengeOptions()
    guardPcall(function()
        self.premades = (MFC_Workshop ~= nil) and MFC_Workshop.getPremades() or {}
        local texts = { "Custom setup" }
        for _, premade in ipairs(self.premades) do
            table.insert(texts, premade.name or "Challenge")
        end
        setTexts(self.optChallenge, texts)
        setState(self.optChallenge, math.max(1, math.min(getState(self.optChallenge), #texts)))
    end)
end

-- nil means "Custom setup" is selected.
function MFC_MenuPage:selectedPremade()
    local index = getState(self.optChallenge) - 1
    if index < 1 then return nil end
    return self.premades and self.premades[index] or nil
end

-- Drop back to "Custom setup" without disturbing any of the rows below. Called
-- whenever the player edits something while a premade is selected.
function MFC_MenuPage:markCustom()
    if getState(self.optChallenge) == 1 then return end
    self.applyingPreset = true
    setState(self.optChallenge, 1)
    self.applyingPreset = false
    self.presetDifficulty = nil
end

-- Copy a premade into the editor. Premades are read-only; this only ever reads
-- from them, so an edited premade can never damage the original.
function MFC_MenuPage:applyPremade(premade)
    guardPcall(function()
        if premade == nil then return end
        -- Suppress the change handler while a dozen controls are driven.
        self.applyingPreset = true

        self.lastChallengeName = premade.name or "Challenge"
        self.builtFromRoll = false
        self.presetDifficulty = premade.difficulty or "Custom"
        setState(self.optDifficulty, self:nearestDifficultyIndex(self.presetDifficulty))

        if (premade.startMoney or -1) < 0 then setState(self.optMoney, 1)
        else setState(self.optMoney, self:nearestIndex(MONEY_STEPS, premade.startMoney)) end
        if (premade.startDebt or -1) < 0 then setState(self.optLoan, 1)
        else setState(self.optLoan, self:nearestIndex(LOAN_STEPS, premade.startDebt)) end
        if (premade.maxLoan or -1) < 0 then setState(self.optLoanLimit, 1)
        else setState(self.optLoanLimit, self:nearestIndex(LIMIT_STEPS, premade.maxLoan)) end

        setState(self.optIncomeMode, (premade.incomeMode == "net") and 2 or 1)
        setState(self.optYears, self:nearestIndex(YEARS_STEPS, premade.years or 2))
        local econIndex = 1
        for i, id in ipairs(ECON_IDS) do
            if id == (premade.econDifficulty or "") then econIndex = i break end
        end
        setState(self.optEconomy, econIndex)

        -- Split the premade into checkpoints plus its final goal.
        local finalGoal, checkpoints = nil, {}
        for _, m in ipairs(premade.milestones or {}) do
            if m.kind == "FinalGoal" then finalGoal = m
            elseif #checkpoints < 3 then table.insert(checkpoints, m) end
        end
        finalGoal = finalGoal or { metric = "NetWorth", target = 1000000 }
        self.presetGoalTitle = finalGoal.title
        self.presetGoalMetric = finalGoal.metric or "NetWorth"

        local raised = 0
        setState(self.optGoalType, METRIC_INDEX[finalGoal.metric or "NetWorth"] or 1)
        self:refreshGoalTexts(false)
        if self:setExactGoalTarget(finalGoal.target) then raised = raised + 1 end

        -- Keep the premade's own deadlines, including quarters.
        self.presetSchedule = {}
        for i = 1, 3 do
            local m = checkpoints[i]
            if m ~= nil then
                self.presetSchedule[i] = {
                    dueYear = m.dueYear or 1, dueQuarter = m.dueQuarter or 4,
                    title = m.title, metric = m.metric or m.kind,
                }
                setState(self["optM" .. i .. "Type"], METRIC_INDEX[m.metric or m.kind or "NetWorth"] or 1)
                self:refreshMilestoneTexts(i, false)
                if self:setExactMilestoneTarget(i, m.target) then raised = raised + 1 end
            else
                -- Fewer than three checkpoints: leave the spare slot on Auto.
                self:refreshMilestoneTexts(i, false)
                setState(self["optM" .. i], 1)
            end
        end

        for ctrlId, restrictionId in pairs(TOGGLE_IDS) do
            setToggle(self[ctrlId], premade.restrictions and premade.restrictions[restrictionId] == true)
        end

        self.applyingPreset = false

        local ruleCount = 0
        for _ in pairs(premade.restrictions or {}) do ruleCount = ruleCount + 1 end
        local message = string.format("%s  -  %s, %d %s, %d restriction%s.",
            premade.name or "Challenge", premade.difficulty or "Custom",
            premade.years or 0, (premade.years == 1) and "year" or "years",
            ruleCount, (ruleCount == 1) and "" or "s")
        if raised > 0 then
            message = message .. "  " .. raised
                .. (raised == 1 and " target was" or " targets were")
                .. " raised above your farm's current value."
        end
        self:setStatus(message)
        self:safeInvalidateLayout()
    end)
end

function MFC_MenuPage:nearestDifficultyIndex(label)
    for i, name in ipairs(DIFFICULTIES) do
        if name == label then return i end
    end
    return 2
end

function MFC_MenuPage:onChallengeChanged()
    guardPcall(function()
        if self.applyingPreset then return end
        local premade = self:selectedPremade()
        if premade ~= nil then
            self:applyPremade(premade)
            return
        end
        -- Back to "Custom setup": clear the premade's numbers out so the rows
        -- below visibly change, the same as picking a premade does. Restoring a
        -- previous hand-built setup was tried and dropped: the saved picker
        -- indices point into target lists that get rebuilt per metric, so they
        -- no longer mean the same values once a premade has been through.
        self:resetEditorToDefaults()
        self.presetDifficulty = nil
        self.presetSchedule = nil
        self.presetGoalTitle = nil
        self.presetGoalMetric = nil
        self.builtFromRoll = false
        self.lastChallengeName = nil
        self:setStatus("Custom setup - build the challenge below.")
        self:safeInvalidateLayout()
    end)
end

-- The starting state of the editor: no forced economy, a net-worth goal, two
-- years, no restrictions. Used on first open and whenever the player picks
-- "Custom setup".
function MFC_MenuPage:resetEditorToDefaults()
    guardPcall(function()
        self.applyingPreset = true
        setState(self.optDifficulty, 2)   -- Cooperative
        setState(self.optMoney, 1)        -- Leave unchanged
        setState(self.optLoan, 1)         -- Leave unchanged
        setState(self.optLoanLimit, 1)    -- Game default
        setState(self.optGoalType, 1)     -- Net worth
        setState(self.optIncomeMode, 1)   -- Income earned since start
        setState(self.optYears, 2)        -- 2 years
        setState(self.optEconomy, 1)      -- Default
        for i = 1, 3 do
            setState(self["optM" .. i .. "Type"], 1)
            setState(self["optM" .. i], 1) -- Auto
        end
        for ctrlId in pairs(TOGGLE_IDS) do setToggle(self[ctrlId], false) end
        self:refreshGoalTexts(false)
        for i = 1, 3 do self:refreshMilestoneTexts(i, false) end
        self.applyingPreset = false
    end)
end

-- ============================================================
-- Frame lifecycle
-- ============================================================

function MFC_MenuPage:initFocus()
    if self.focusInitialized then return end
    guardPcall(function()
        if FocusManager == nil or self.layout == nil then return end
        if FocusManager.loadElementFromCustomValues == nil then return end
        for _, el in ipairs(self.layout.elements or {}) do
            FocusManager:loadElementFromCustomValues(el)
        end
        self.focusInitialized = true
    end)
end

function MFC_MenuPage:onFrameOpen()
    MFC_MenuPage:superClass().onFrameOpen(self)
    -- A fresh visit starts from the default status line again.
    self.statusHeld = false

    guardPcall(function()
        if self.settingsSlider ~= nil and self.settingsSlider.setDataElement ~= nil
            and self.layout ~= nil then
            self.settingsSlider:setDataElement(self.layout)
        end
        if self.layout ~= nil and self.layout.invalidateLayout ~= nil then
            self.layout:invalidateLayout()
        end
    end)

    self:populateOptions()

    -- A client that never got an answer during loading gets another chance
    -- whenever the page is opened.
    guardPcall(function()
        local MFC = MayflowerFarmChallenge
        if MFC ~= nil and MFC.isMultiplayer() and not MFC.isServer()
            and MFC.networkSynced ~= true and MFC_Network ~= nil then
            MFC_Network.requestSync()
        end
    end)

    -- Start at the top so the active challenge is what you see first.
    guardPcall(function()
        if self.layout ~= nil then
            if self.layout.setScrollPosition ~= nil then self.layout:setScrollPosition(0)
            elseif self.layout.scrollTo ~= nil then self.layout:scrollTo(0) end
        end
        if self.pageSlider ~= nil and self.pageSlider.setValue ~= nil then
            self.pageSlider:setValue(self.pageSlider.minValue or 0)
        end
    end)

    self:initFocus()
    self:updateMenuButtons()
    self:updateStatus()
    self:updateStats()
end

-- onFrameOpen doesn't fire reliably for injected pages (tab-cycling and direct
-- clicks differ), so the page also refreshes from the update loop. It's cheap,
-- throttled, and keeps progress live while the page is open.
function MFC_MenuPage:update(dt)
    MFC_MenuPage:superClass().update(self, dt)

    -- Note the explicit form: `(a ~= nil) and a() or true` collapses to true
    -- whenever a() returns false, which silently disabled this whole block.
    local visible = (self.getIsVisible == nil) or self:getIsVisible()

    -- Deferred initial focus: the base menu runs its own focus handling when a
    -- page opens and wins any race with an immediate setFocus, so wait a few
    -- frames after becoming visible and then take focus.
    if visible and not self.wasVisible then self.focusDelay = 5 end
    self.wasVisible = visible
    if visible and self.focusDelay ~= nil then
        self.focusDelay = self.focusDelay - 1
        if self.focusDelay <= 0 then
            self.focusDelay = nil
            self:initFocus()
            guardPcall(function()
                if FocusManager ~= nil and FocusManager.setFocus ~= nil
                    and self.optChallenge ~= nil then
                    FocusManager:setFocus(self.optChallenge)
                end
            end)
        end
    end

    if not visible then return end
    self.refreshTimer = (self.refreshTimer or 0) + (dt or 0)
    if self.refreshTimer < 500 then return end
    self.refreshTimer = 0
    guardPcall(function()
        if not self.initialized then self:populateOptions() end
        self:updateStatus()
        self:updateStats()
    end)
end

-- ============================================================
-- The read-out at the top of the page
-- ============================================================

local function setStat(el, text)
    if el ~= nil and el.setText ~= nil then el:setText(text or "") end
end

-- Show/hide a stat row through its wrapper so the layout reflows.
local function setRowVisible(el, visible)
    pcall(function()
        if el ~= nil and el.parent ~= nil and el.parent.setVisible ~= nil then
            el.parent:setVisible(visible)
        end
    end)
end

-- Size the fill to a fraction of its background bar. Bitmap sizes are
-- normalized screen units at runtime, so scale the parent's stored width.
local function setBarFill(bg, fill, frac)
    if bg == nil or fill == nil then return end
    frac = math.max(0, math.min(1, frac or 0))
    pcall(function()
        if bg.size ~= nil and fill.setSize ~= nil then
            fill:setSize(math.max(bg.size[1] * frac, 0.00001), fill.size and fill.size[2] or nil)
        end
    end)
end

local function setBarColor(fill, r, g, b)
    pcall(function()
        if fill ~= nil and fill.setImageColor ~= nil then
            fill:setImageColor(nil, r, g, b, 1)
        end
    end)
end

local function writeStatus(self, text)
    if self.statusText ~= nil and self.statusText.setText ~= nil then
        self.statusText:setText(text or "")
    end
end

-- Anything the player triggered stays on screen until the page is reopened, so
-- the twice-a-second refresh can't wipe out "Saved to Workshop: ..." before it
-- has been read.
function MFC_MenuPage:setStatus(text)
    self.statusHeld = true
    writeStatus(self, text)
end

function MFC_MenuPage:updateStats()
    guardPcall(function()
        local MFC = MayflowerFarmChallenge
        local c = MFC and MFC.campaign
        local slots = { self.statM1, self.statM2, self.statM3, self.statM4 }

        if c == nil then
            local MFCmod = MFC
            local noFarm = MFCmod ~= nil and MFCmod.isMultiplayer()
                and MFCmod.localFarmId() <= 0
            setStat(self.statName, noFarm and "You are not in a farm"
                or "No active challenge for your farm")
            setStat(self.statGoal, noFarm and "Join a farm to run a challenge"
                or "Pick a premade or build your own below")
            setStat(self.statCurrent, "")
            setStat(self.statRules, "")
            for _, slot in ipairs(slots) do setStat(slot, "") end
            -- Only touch visibility when the state actually changed, so the
            -- twice-a-second refresh doesn't fight the player's scrolling.
            if self.rowSignature ~= "none" then
                self.rowSignature = "none"
                setRowVisible(self.statCurrent, false)
                setRowVisible(self.statRules, false)
                for _, slot in ipairs(slots) do setRowVisible(slot, false) end
                for i = 1, 4 do setRowVisible(self["msBar" .. i .. "Bg"], false) end
                setRowVisible(self.goalBarBg, false)
                self:safeInvalidateLayout()
            end
            return
        end

        local signature = "c" .. tostring(#(c.milestones or {}))
        local signatureChanged = (self.rowSignature ~= signature)
        if signatureChanged then
            self.rowSignature = signature
            setRowVisible(self.statCurrent, true)
            setRowVisible(self.statRules, true)
            setRowVisible(self.goalBarBg, true)
        end

        local function metricValue(metric)
            return (MFC.getChallengeMetricPublic and MFC.getChallengeMetricPublic(metric)) or 0
        end

        local goal, goalMetric = 0, "NetWorth"
        local doneCount, total = 0, 0
        for _, m in ipairs(c.milestones or {}) do
            if m.kind == "FinalGoal" then
                goal = m.target or 0
                goalMetric = m.metric or "NetWorth"
            end
            total = total + 1
            if m.completed then doneCount = doneCount + 1 end
        end

        local years = c.years or 0
        local yearWord = (years == 1) and "year" or "years"
        local state = c.state or "active"
        local live = (state == "active")

        local suffix = ""
        if state == "won" then suffix = "  -  COMPLETED!"
        elseif state == "failed" then suffix = "  -  FAILED (time limit)" end
        -- In multiplayer, say plainly whose run this is: the page always shows
        -- the challenge belonging to the farm you are in.
        local scope = MFC.isMultiplayer() and "Your farm:  " or ""
        setStat(self.statName, string.format("%s%s  (%s)%s",
            scope, c.name or "Challenge", c.difficulty or "", suffix))

        if live then
            local current = metricValue(goalMetric)
            local pct = (goal > 0) and math.min(current / goal, 1) or 0
            setStat(self.statGoal, string.format("Goal:  %s %s in %d %s   (%d%%)",
                metricLabel(goalMetric), metricFmt(goalMetric, goal), years, yearWord,
                math.floor(pct * 100 + 0.5)))
            setBarFill(self.goalBarBg, self.goalBarFill, pct)
            setBarColor(self.goalBarFill, 0.4870, 0.6613, 0.0)

            local challengeYear = (MFC.getChallengeYearPublic and MFC.getChallengeYearPublic()) or 1
            setStat(self.statCurrent, string.format(
                "Now:  %s   (%d of %d milestones done)   Year %d of %d",
                metricFmt(goalMetric, current), doneCount, total,
                math.min(challengeYear, years > 0 and years or challengeYear), years))
        else
            -- Frozen result card: nothing here moves any more.
            local won = (state == "won")
            local pct = won and 1
                or ((goal > 0 and c.endGoalValue ~= nil) and math.min(c.endGoalValue / goal, 1) or 0)
            setStat(self.statGoal, string.format("Goal:  %s %s in %d %s   -  %s",
                metricLabel(goalMetric), metricFmt(goalMetric, goal), years, yearWord,
                won and "ACHIEVED" or "NOT REACHED"))
            setBarFill(self.goalBarBg, self.goalBarFill, pct)
            if won then setBarColor(self.goalBarFill, 0.85, 0.62, 0.08)
            else setBarColor(self.goalBarFill, 0.55, 0.16, 0.10) end

            setStat(self.statCurrent, string.format(
                "Finished in year %d of %d   -   %d of %d milestones   -   Money earned %s",
                c.endYearsUsed or 1, years, doneCount, total,
                money((MFC.getIncomePublic and MFC.getIncomePublic()) or 0)))
        end

        local ruleNames = {
            noWorkers = "no workers", noContractMachines = "no contract machines",
            noLeasing = "no leasing", noTeleport = "no fast travel",
            noLoans = "no loans", manualOnly = "no GPS",
        }
        local rules = {}
        for id in pairs(c.restrictions or {}) do table.insert(rules, ruleNames[id] or id) end
        table.sort(rules)
        if (tonumber(c.maxLoan) or -1) >= 0 then
            table.insert(rules, "loan limit " .. money(c.maxLoan))
        end
        setStat(self.statRules, "Rules:  " .. (#rules > 0 and table.concat(rules, ", ") or "none"))

        for i = 1, #slots do
            local m = (c.milestones or {})[i]
            if m == nil then
                setStat(slots[i], "")
                if signatureChanged then
                    setRowVisible(slots[i], false)
                    setRowVisible(self["msBar" .. i .. "Bg"], false)
                end
            else
                local metric = m.metric or m.kind
                if metric == "FinalGoal" then metric = goalMetric end
                local label = (m.kind == "FinalGoal") and "Final goal" or metricLabel(metric)

                local frac
                if m.completed then frac = 1
                elseif not live then frac = 0
                else frac = ((m.target or 0) > 0
                    and math.min(metricValue(metric) / m.target, 1) or 0) end

                local status
                if m.completed then status = "DONE"
                elseif (not live) or m.missed then status = "MISSED"
                else status = string.format("%d%%", math.floor(frac * 100 + 0.5)) end

                setStat(slots[i], string.format("%d. %s  %s  -  by %s  -  %s",
                    i, label, metricFmt(metric, m.target),
                    deadlineText(m.dueYear, m.dueQuarter), status))
                setBarFill(self["msBar" .. i .. "Bg"], self["msBar" .. i .. "Fill"], frac)
                -- Muted red once a deadline has passed, green otherwise.
                if m.missed and not m.completed then
                    setBarColor(self["msBar" .. i .. "Fill"], 0.55, 0.16, 0.10)
                else
                    setBarColor(self["msBar" .. i .. "Fill"], 0.4870, 0.6613, 0.0)
                end
                if signatureChanged then
                    setRowVisible(slots[i], true)
                    setRowVisible(self["msBar" .. i .. "Bg"], true)
                end
            end
        end

        if signatureChanged then self:safeInvalidateLayout() end
    end)
end

-- ============================================================
-- Populating and reacting to the editor
-- ============================================================

function MFC_MenuPage:populateOptions()
    guardPcall(function()
        self:refreshChallengeOptions()
        setTexts(self.optDifficulty, DIFFICULTIES)

        local function stepTexts(steps, unchangedText)
            local texts = {}
            for _, v in ipairs(steps) do
                table.insert(texts, (v == UNCHANGED) and unchangedText or money(v))
            end
            return texts
        end
        setTexts(self.optMoney, stepTexts(MONEY_STEPS, "Leave unchanged"))
        setTexts(self.optLoan, stepTexts(LOAN_STEPS, "Leave unchanged"))
        setTexts(self.optLoanLimit, stepTexts(LIMIT_STEPS, "Game default"))

        local goalTypeTexts = {}
        for _, t in ipairs(GOAL_TYPES) do table.insert(goalTypeTexts, t.label) end
        setTexts(self.optGoalType, goalTypeTexts)
        setTexts(self.optIncomeMode, { "Income earned since start", "Net balance gain" })

        local yearTexts = {}
        for _, v in ipairs(YEARS_STEPS) do
            table.insert(yearTexts, tostring(v) .. ((v == 1) and " year" or " years"))
        end
        setTexts(self.optYears, yearTexts)
        setTexts(self.optEconomy, ECON_STEPS)

        local msTypeTexts = {}
        for _, t in ipairs(MS_TYPES) do table.insert(msTypeTexts, t.label) end
        for i = 1, 3 do setTexts(self["optM" .. i .. "Type"], msTypeTexts) end

        -- Toggles need their two texts set explicitly; without them the state
        -- and highlight maths are undefined and the marker slides off the row.
        for ctrlId in pairs(TOGGLE_IDS) do setTexts(self[ctrlId], { "OFF", "ON" }) end

        if not self.initialized then
            self.initialized = true
            self:resetEditorToDefaults()
        else
            self:refreshGoalTexts(true)
            for i = 1, 3 do self:refreshMilestoneTexts(i, true) end
        end
    end)
end

-- The engine's callback argument order isn't something to rely on, so instead
-- of working out which picker changed, refresh every type-dependent target
-- list. Selections are preserved, so this is cheap and safe.
function MFC_MenuPage:onChangeOption()
    guardPcall(function()
        if self.applyingPreset then return end
        -- A manual edit means this is no longer a pure roll or an untouched
        -- premade, but the loaded deadlines stay until they no longer fit.
        self.builtFromRoll = false
        self:markCustom()
        self:refreshGoalTexts(true)
        for i = 1, 3 do self:refreshMilestoneTexts(i, true) end
    end)
end

function MFC_MenuPage:onToggle()
    if self.applyingPreset then return end
    self.builtFromRoll = false
    self:markCustom()
end

function MFC_MenuPage:onClickRoll()
    guardPcall(function()
        if MFC_Roller == nil then return end
        local rolled = MFC_Roller.roll(DIFFICULTIES[getState(self.optDifficulty)] or "Cooperative")

        self.applyingPreset = true
        setState(self.optChallenge, 1) -- a rolled challenge is a custom one
        -- A roll never forces the player's economy: cash and loan stay on
        -- "leave unchanged" so the challenge starts from the real balance.
        setState(self.optMoney, 1)
        setState(self.optLoan, 1)
        setState(self.optLoanLimit, 1)

        local metricIndex = METRIC_INDEX[rolled.goalMetric] or 1
        setState(self.optGoalType, metricIndex)
        self:refreshGoalTexts(false)
        self:setExactGoalTarget(rolled.goalTarget)

        setState(self.optYears, self:nearestIndex(YEARS_STEPS, rolled.years))
        local econIndex = 1
        for i, id in ipairs(ECON_IDS) do
            if id == (rolled.econDifficulty or "") then econIndex = i break end
        end
        setState(self.optEconomy, econIndex)

        -- Checkpoints follow the goal metric on Auto, spread over the run.
        self.presetSchedule = nil
        self.presetGoalTitle = nil
        self.presetGoalMetric = nil
        for i = 1, 3 do
            setState(self["optM" .. i .. "Type"], metricIndex)
            self:refreshMilestoneTexts(i, false)
            setState(self["optM" .. i], 1)
        end

        for ctrlId, restrictionId in pairs(TOGGLE_IDS) do
            setToggle(self[ctrlId], rolled.restrictions[restrictionId] == true)
        end

        self.applyingPreset = false
        self.builtFromRoll = true
        self.presetDifficulty = nil
        self.lastChallengeName = rolled.name
        self:setStatus(string.format("Rolled '%s' - tweak it, or Create and start.", rolled.name))
        self:safeInvalidateLayout()
    end)
end

-- ============================================================
-- Building a challenge
-- ============================================================

-- A loaded premade keeps its own deadlines (quarters included) as long as they
-- still fit the selected time limit; otherwise checkpoints are spread evenly
-- across the run, in quarter steps.
--
-- Its milestone wording comes along too -- "Find your footing" reads better
-- than the generic "Grow net worth" -- but only while that checkpoint still
-- measures what the premade meant it to. Change the metric and it gets the
-- generic title for the metric you chose.
function MFC_MenuPage:checkpointPlan(i, years, metricId)
    local scheduled = self.presetSchedule and self.presetSchedule[i]
    local title = nil
    if scheduled ~= nil and scheduled.metric == metricId then
        title = scheduled.title
    end
    if title == nil or title == "" then title = nil end

    if scheduled ~= nil and (scheduled.dueYear or 1) <= years then
        return scheduled.dueYear, scheduled.dueQuarter, title
    end
    local quarter = math.max(1, math.floor((i / 4) * (years * 4) + 0.5))
    return math.floor((quarter - 1) / 4) + 1, ((quarter - 1) % 4) + 1, title
end

-- Build a challenge table from the editor. Shared by "Create and start" and
-- "Save current setup", so a saved preset is exactly the challenge that would
-- have been started.
function MFC_MenuPage:buildChallengeFromEditor(challengeName)
    local MFC = MayflowerFarmChallenge
    if MFC == nil then return nil end

    local gt = self:goalType()
    local goalFloor = self:projectedMetric(gt.id)
    local goal = selectedMappedValue(self.optGoal, self.goalValueOptions, nil)
    if goal == nil or goal <= goalFloor then goal = generatedTargetAbove(gt.id, goalFloor) end

    local years = YEARS_STEPS[getState(self.optYears)] or 2

    local restrictions = {}
    for ctrlId, restrictionId in pairs(TOGGLE_IDS) do
        if getToggle(self[ctrlId]) then restrictions[restrictionId] = true end
    end

    local milestones = {}
    for i = 1, 3 do
        local frac = i / 4
        local mt = self:msType(i)
        local current = self:projectedMetric(mt.id)
        local selected = selectedMappedValue(self["optM" .. i],
            self.milestoneValueOptions and self.milestoneValueOptions[i], 0)

        local target
        if selected ~= nil and selected > current then
            target = selected
        elseif mt.id == gt.id then
            -- Auto checkpoints on the goal's own metric sit between the farm's
            -- starting value and the final target, so none can be met the
            -- instant the run begins.
            if mt.id == "OwnFields" then
                target = math.floor(current + ((goal - current) * frac) + 0.5)
            else
                target = roundMoneyTarget(current + ((goal - current) * (frac ^ 1.3)))
            end
        elseif mt.id == "OwnFields" then
            target = math.floor(current) + math.max(1, math.floor(8 * frac + 0.5))
        else
            target = roundMoneyTarget(current + (1000000 * frac))
        end
        if target <= current then target = generatedTargetAbove(mt.id, current) end

        local dueYear, dueQuarter, title = self:checkpointPlan(i, years, mt.id)
        table.insert(milestones, {
            order = i, kind = mt.id, metric = mt.id, target = target,
            dueYear = dueYear, dueQuarter = dueQuarter,
            title = title or mt.title, completed = false, missed = false,
        })
    end
    local goalTitle = "Final goal"
    if self.presetGoalTitle ~= nil and self.presetGoalTitle ~= ""
        and self.presetGoalMetric == gt.id then
        goalTitle = self.presetGoalTitle
    end
    table.insert(milestones, {
        order = 4, kind = "FinalGoal", metric = gt.id, target = goal,
        dueYear = years, dueQuarter = 4,
        title = goalTitle, completed = false, missed = false,
    })

    local farmId = 0
    if g_currentMission ~= nil and g_currentMission.getFarmId ~= nil then
        farmId = g_currentMission:getFarmId() or 0
    end

    local difficulty = "Custom"
    if self.builtFromRoll then difficulty = DIFFICULTIES[getState(self.optDifficulty)] or "Custom"
    elseif self.presetDifficulty ~= nil then difficulty = self.presetDifficulty end

    return {
        seed = math.random(1, 1000000),
        name = challengeName or "Custom Challenge",
        difficulty = difficulty,
        farmId = farmId,
        years = years,
        startMoney = self:selectedStartMoney() or -1,
        startDebt = self:selectedStartDebt() or -1,
        maxLoan = self:selectedLoanLimit() or -1,
        econDifficulty = ECON_IDS[getState(self.optEconomy)] or "",
        incomeMode = INCOME_MODES[getState(self.optIncomeMode)] or "gross",
        restrictions = restrictions,
        milestones = milestones,
    }
end

-- ============================================================
-- Bottom-bar actions
-- ============================================================

function MFC_MenuPage:canManage()
    local MFC = MayflowerFarmChallenge
    if MFC == nil or not MFC.isMultiplayer() then return true end
    if MFC_Network == nil then return true end
    return MFC_Network.canLocalManage()
end

function MFC_MenuPage:updateMenuButtons()
    guardPcall(function()
        local MFC = MayflowerFarmChallenge
        local campaign = MFC and MFC.campaign
        local state = (campaign ~= nil) and (campaign.state or "active") or "none"
        local canManage = self:canManage()

        -- showWhenPaused is required: the Escape menu pauses the game, and
        -- assignMenuButtonInfo mouse-blocks buttons without it.
        self.menuButtonInfo = {
            { inputAction = InputAction.MENU_BACK, showWhenPaused = true },
        }
        if canManage then
            table.insert(self.menuButtonInfo, {
                inputAction = InputAction.MENU_ACTIVATE, text = "Create and start",
                showWhenPaused = true, callback = function() self:onClickStart() end })
        end
        table.insert(self.menuButtonInfo, {
            inputAction = InputAction.MENU_EXTRA_1, text = "Randomize setup",
            showWhenPaused = true, callback = function() self:onClickRoll() end })
        if canManage and campaign ~= nil then
            table.insert(self.menuButtonInfo, {
                inputAction = InputAction.MENU_EXTRA_2,
                text = (state == "active") and "Abandon challenge" or "Clear result",
                showWhenPaused = true, callback = function() self:onClickAbandon() end })
        end

        self.buttonSignature = state .. ":" .. tostring(canManage)
        if self.setMenuButtonInfoDirty ~= nil then self:setMenuButtonInfoDirty() end
    end)
end

function MFC_MenuPage:updateStatus()
    guardPcall(function()
        local MFC = MayflowerFarmChallenge
        local campaign = MFC and MFC.campaign
        local state = (campaign ~= nil) and (campaign.state or "active") or "none"
        local canManage = self:canManage()
        if self.buttonSignature ~= state .. ":" .. tostring(canManage) then
            self:updateMenuButtons()
        end
        -- Don't stomp on a message the player just triggered.
        if self.statusHeld then return end
        local multiplayer = (MFC ~= nil) and MFC.isMultiplayer()
        local noFarm = multiplayer and MFC.localFarmId() <= 0

        if noFarm then
            writeStatus(self, "You are not in a farm - join one to run a challenge.")
        elseif campaign ~= nil and not canManage then
            -- Everyone on the farm follows the run; only a manager ends it.
            writeStatus(self, "Active: " .. (campaign.name or "")
                .. "  -  a farm manager can abandon it.")
        elseif campaign ~= nil then
            writeStatus(self, "Active: " .. (campaign.name or ""))
        elseif not canManage then
            writeStatus(self, "Only a farm manager can start a challenge for your farm.")
        else
            writeStatus(self, "Pick a premade above, or build your own below.")
        end
    end)
end

function MFC_MenuPage:onClickStart()
    guardPcall(function()
        if not self:canManage() then
            self:setStatus("Only a farm manager (or the server admin) can start your farm's challenge.")
            return
        end
        -- A premade already has a name; only a custom setup needs one asked for.
        local premade = self:selectedPremade()
        if premade ~= nil then
            self:startNamed(premade.name or "Challenge")
            return
        end
        local prefill = self.lastChallengeName or "Custom Challenge"
        if TextInputDialog ~= nil and TextInputDialog.show ~= nil then
            TextInputDialog.show(self.onNameEntered, self, prefill,
                "Name your challenge", nil, 30, "Create")
        else
            self:onNameEntered(prefill, true)
        end
    end)
end

function MFC_MenuPage:onNameEntered(name, clickOk)
    guardPcall(function()
        if clickOk ~= true then return end
        name = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
        if name == "" then name = "Custom Challenge" end
        self:startNamed(name)
    end)
end

function MFC_MenuPage:startNamed(name)
    guardPcall(function()
        local MFC = MayflowerFarmChallenge
        if MFC == nil then return end
        self.lastChallengeName = name
        local challenge = self:buildChallengeFromEditor(name)
        if challenge == nil then return end
        MFC.startCampaign(challenge)

        self:setStatus(MFC.isMultiplayer()
            and ("Sent to the server: " .. challenge.name)
            or ("Started: " .. challenge.name))
        self:updateStatus()
        self:updateStats()
    end)
end

function MFC_MenuPage:onClickAbandon()
    guardPcall(function()
        local MFC = MayflowerFarmChallenge
        if MFC == nil or MFC.campaign == nil then return end
        if not self:canManage() then
            self:setStatus("Only a farm manager (or the server admin) can clear your farm's challenge.")
            return
        end
        if (MFC.campaign.state or "active") ~= "active" then
            -- A finished run is already recorded in history, so clearing the
            -- result card is low-stakes.
            self:onAbandonConfirmed(true)
            return
        end
        if YesNoDialog ~= nil and YesNoDialog.show ~= nil then
            YesNoDialog.show(self.onAbandonConfirmed, self,
                "Abandon the current challenge? This cannot be undone.")
        else
            self:onAbandonConfirmed(true)
        end
    end)
end

function MFC_MenuPage:onAbandonConfirmed(yes)
    guardPcall(function()
        if yes ~= true then return end
        local MFC = MayflowerFarmChallenge
        if MFC ~= nil then MFC.abandonCampaign() end
        self:setStatus("Cleared.")
        self:updateStatus()
        self:updateStats()
    end)
end
