using System.IO;
using System.Text.Json;
using MayflowerIdleRPG.Models;

namespace MayflowerIdleRPG.Services;

public class SaveService
{
    private readonly string _saveFolder;
    private readonly string _legacySavePath;
    private string _activeSlot = "Slot 1";

    public SaveService()
    {
        _saveFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "MayflowerIdleRPG");

        _legacySavePath = Path.Combine(_saveFolder, "save.json");
    }

    public string ActiveSlot => _activeSlot;
    public string SaveFolder => _saveFolder;
    public string BackupFolder => Path.Combine(_saveFolder, "Backups");
    public string CorruptSaveFolder => Path.Combine(_saveFolder, "CorruptSaves");
    public string SavePath => Path.Combine(_saveFolder, $"save_{SanitizeSlot(_activeSlot)}.json");
    public string LastLoadMessage { get; private set; } = string.Empty;

    public void SetActiveSlot(string slot)
    {
        _activeSlot = NormalizeSlot(slot);
    }

    public bool ActiveSaveExists(string? slot = null)
    {
        string oldSlot = _activeSlot;
        try
        {
            if (!string.IsNullOrWhiteSpace(slot)) SetActiveSlot(slot);
            return File.Exists(SavePath) || (_activeSlot == "Slot 1" && File.Exists(_legacySavePath));
        }
        finally
        {
            _activeSlot = oldSlot;
        }
    }

    public SaveData Load()
    {
        return Load(_activeSlot);
    }

    public SaveData Load(string slot)
    {
        SetActiveSlot(slot);
        LastLoadMessage = string.Empty;

        string path = SavePath;
        if (!File.Exists(path) && _activeSlot == "Slot 1" && File.Exists(_legacySavePath))
            path = _legacySavePath;

        if (!File.Exists(path))
            return FreshSave();

        try
        {
            return ReadSaveData(path);
        }
        catch (Exception ex)
        {
            string corruptPath = QuarantineCorruptSave(path);
            LastLoadMessage = string.IsNullOrWhiteSpace(corruptPath)
                ? $"The active save could not be read ({ex.Message}). A new chronicle was prepared."
                : $"The active save was damaged and was moved to {corruptPath}.";

            if (RestoreLatestBackup())
            {
                try
                {
                    LastLoadMessage += " The newest backup was restored.";
                    return ReadSaveData(SavePath);
                }
                catch
                {
                    LastLoadMessage += " The newest backup could not be read, so a fresh chronicle was prepared.";
                }
            }
            else
            {
                LastLoadMessage += " No readable backup was found, so a fresh chronicle was prepared.";
            }

            return FreshSave();
        }
    }

    private SaveData FreshSave()
    {
        return new SaveData { Settings = new GameSettings { SaveSlot = _activeSlot } };
    }

    private SaveData ReadSaveData(string path)
    {
        string json = File.ReadAllText(path);
        SaveData? data = JsonSerializer.Deserialize<SaveData>(json);
        data ??= new SaveData();
        data.Settings ??= new GameSettings();
        data.Settings.SaveSlot = _activeSlot;
        return data;
    }

    public void Save(SaveData data)
    {
        Directory.CreateDirectory(_saveFolder);
        data.LastSavedUtc = DateTime.UtcNow;
        data.SaveVersion = Math.Max(1, data.SaveVersion);
        data.Settings ??= new GameSettings();
        data.Settings.SaveSlot = _activeSlot;

        var options = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        string json = JsonSerializer.Serialize(data, options);
        AtomicWrite(SavePath, json);

        // Keep the old save.json path updated for compatibility with earlier builds.
        if (_activeSlot == "Slot 1")
            AtomicWrite(_legacySavePath, json);
    }

    private static void AtomicWrite(string path, string content)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path) ?? Environment.CurrentDirectory);
        string temp = path + ".tmp";
        string previous = path + ".previous";
        File.WriteAllText(temp, content);

        if (File.Exists(path))
        {
            try
            {
                File.Replace(temp, path, previous, ignoreMetadataErrors: true);
                return;
            }
            catch
            {
                // File.Replace can fail on some synced folders. Fall back to a simple replace.
            }
        }

        File.Copy(temp, path, overwrite: true);
        try { File.Delete(temp); } catch { }
    }

    public void BackupCurrentSave(string reason)
    {
        try
        {
            string path = SavePath;
            if (!File.Exists(path) && _activeSlot == "Slot 1" && File.Exists(_legacySavePath))
                path = _legacySavePath;
            if (!File.Exists(path)) return;

            Directory.CreateDirectory(BackupFolder);
            string safeReason = SanitizeSlot(reason).ToLowerInvariant();
            string file = Path.Combine(BackupFolder, $"{SanitizeSlot(_activeSlot)}_{DateTime.UtcNow:yyyyMMdd_HHmmss}_{safeReason}.json");
            File.Copy(path, file, overwrite: true);
            PruneBackups();
        }
        catch
        {
            // Backups are safety helpers. A failed backup should not prevent the app from saving.
        }
    }

    public void CreateBackup(SaveData data, string reason)
    {
        Directory.CreateDirectory(BackupFolder);
        data.Settings ??= new GameSettings();
        data.Settings.SaveSlot = _activeSlot;
        data.SaveVersion = Math.Max(1, data.SaveVersion);

        string safeReason = SanitizeSlot(reason).ToLowerInvariant();
        string file = Path.Combine(BackupFolder, $"{SanitizeSlot(_activeSlot)}_{DateTime.UtcNow:yyyyMMdd_HHmmss}_{safeReason}.json");
        string json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(file, json);
        PruneBackups();
    }

    private void PruneBackups()
    {
        var old = Directory.GetFiles(BackupFolder, $"{SanitizeSlot(_activeSlot)}_*.json")
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .Skip(40)
            .ToList();
        foreach (string path in old)
        {
            try { File.Delete(path); } catch { }
        }
    }

    public bool HasBackup(string? slot = null)
    {
        string oldSlot = _activeSlot;
        try
        {
            if (!string.IsNullOrWhiteSpace(slot)) SetActiveSlot(slot);
            if (!Directory.Exists(BackupFolder)) return false;
            return Directory.GetFiles(BackupFolder, $"{SanitizeSlot(_activeSlot)}_*.json").Any();
        }
        catch
        {
            return false;
        }
        finally
        {
            _activeSlot = oldSlot;
        }
    }

    public bool RestoreLatestBackup()
    {
        try
        {
            if (!Directory.Exists(BackupFolder)) return false;
            string? latest = Directory.GetFiles(BackupFolder, $"{SanitizeSlot(_activeSlot)}_*.json")
                .OrderByDescending(File.GetLastWriteTimeUtc)
                .FirstOrDefault();
            if (string.IsNullOrWhiteSpace(latest)) return false;
            Directory.CreateDirectory(_saveFolder);
            File.Copy(latest, SavePath, overwrite: true);
            if (_activeSlot == "Slot 1") File.Copy(latest, _legacySavePath, overwrite: true);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private string QuarantineCorruptSave(string path)
    {
        try
        {
            Directory.CreateDirectory(CorruptSaveFolder);
            string target = Path.Combine(CorruptSaveFolder, $"{Path.GetFileNameWithoutExtension(path)}_{DateTime.UtcNow:yyyyMMdd_HHmmss}.json");
            File.Copy(path, target, overwrite: false);
            return target;
        }
        catch
        {
            return string.Empty;
        }
    }

    public void DeleteSave()
    {
        if (File.Exists(SavePath))
            File.Delete(SavePath);
        if (_activeSlot == "Slot 1" && File.Exists(_legacySavePath))
            File.Delete(_legacySavePath);
    }

    private static string NormalizeSlot(string? slot)
    {
        if (string.IsNullOrWhiteSpace(slot)) return "Slot 1";
        slot = slot.Trim();
        return slot switch
        {
            "1" => "Slot 1",
            "2" => "Slot 2",
            "3" => "Slot 3",
            "4" => "Slot 4",
            _ => slot
        };
    }

    private static string SanitizeSlot(string value)
    {
        string safe = new(value.Where(ch => char.IsLetterOrDigit(ch) || ch is '-' or '_').ToArray());
        return string.IsNullOrWhiteSpace(safe) ? "Slot1" : safe;
    }
}
