using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;

namespace MayflowerIdleRPG.Services;

public static class ReleaseDiagnostics
{
    public const string AppVersion = "1.0.0";

    public static string AppDataFolder => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "MayflowerIdleRPG");

    public static string LogsFolder => Path.Combine(AppDataFolder, "Logs");

    public static string GetBuildInfo()
    {
        Version? version = Assembly.GetExecutingAssembly().GetName().Version;
        string framework = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
        string os = System.Runtime.InteropServices.RuntimeInformation.OSDescription;
        return $"Mayflower Idle RPG {AppVersion}\nAssembly: {version}\nFramework: {framework}\nOS: {os}\nProcess: {(Environment.Is64BitProcess ? "64-bit" : "32-bit")}\nFolder: {AppContext.BaseDirectory}";
    }

    public static string LogException(Exception exception, string source)
    {
        try
        {
            Directory.CreateDirectory(LogsFolder);
            string path = Path.Combine(LogsFolder, $"crash-{DateTime.Now:yyyyMMdd-HHmmss}.txt");
            var sb = new StringBuilder();
            sb.AppendLine("Mayflower Idle RPG crash report");
            sb.AppendLine("================================");
            sb.AppendLine($"Time: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"Source: {source}");
            sb.AppendLine();
            sb.AppendLine(GetBuildInfo());
            sb.AppendLine();
            sb.AppendLine(exception.ToString());
            File.WriteAllText(path, sb.ToString());
            return path;
        }
        catch
        {
            return string.Empty;
        }
    }


    public static void LogMessage(string message)
    {
        try
        {
            Directory.CreateDirectory(LogsFolder);
            string path = Path.Combine(LogsFolder, $"runtime-{DateTime.Now:yyyyMMdd}.txt");
            File.AppendAllText(path, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}{Environment.NewLine}");
        }
        catch
        {
            // Runtime notes should never interrupt the game.
        }
    }

    public static void OpenLogsFolder()
    {
        Directory.CreateDirectory(LogsFolder);
        Process.Start(new ProcessStartInfo { FileName = LogsFolder, UseShellExecute = true });
    }
}
