using System.Net.Http;
using System.Text;
using System.Text.Json;
using MayflowerIdleRPG.Models;

namespace MayflowerIdleRPG.Services;

public class FirebaseLeaderboardService
{
    private static readonly HttpClient Client = new()
    {
        Timeout = TimeSpan.FromSeconds(8)
    };

    public const string DatabaseUrl = "https://watchtogether-95d7d-default-rtdb.firebaseio.com";
    private const string LeaderboardPath = "leaderboards/mayflowerIdleRPG/entries";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = null,
        WriteIndented = false
    };

    public async Task<LeaderboardSubmitResult> SubmitAsync(LeaderboardEntry entry, CancellationToken cancellationToken = default)
    {
        if (entry == null)
            return new LeaderboardSubmitResult { Success = false, Message = "No leaderboard entry was created." };

        string safeId = MakeSafeFirebaseKey(entry.id);
        if (string.IsNullOrWhiteSpace(safeId))
            return new LeaderboardSubmitResult { Success = false, Message = "Missing leaderboard id." };

        entry.id = safeId;
        entry.updatedAtUtc = DateTime.UtcNow.ToString("O");

        string json = JsonSerializer.Serialize(entry, JsonOptions);
        string url = $"{DatabaseUrl.TrimEnd('/')}/{LeaderboardPath}/{safeId}.json";

        using var content = new StringContent(json, Encoding.UTF8, "application/json");
        using var response = await Client.PutAsync(url, content, cancellationToken).ConfigureAwait(false);
        string responseText = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);

        if (!response.IsSuccessStatusCode)
        {
            string shortResponse = string.IsNullOrWhiteSpace(responseText)
                ? response.ReasonPhrase ?? response.StatusCode.ToString()
                : responseText.Length > 140 ? responseText[..140] : responseText;

            return new LeaderboardSubmitResult
            {
                Success = false,
                Message = $"Leaderboard upload failed: {(int)response.StatusCode} {shortResponse}"
            };
        }

        return new LeaderboardSubmitResult
        {
            Success = true,
            Message = "Leaderboard updated."
        };
    }

    public static string MakeSafeFirebaseKey(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "";
        var builder = new StringBuilder(value.Length);
        foreach (char c in value.Trim())
        {
            if (char.IsLetterOrDigit(c) || c == '-' || c == '_')
                builder.Append(c);
        }
        string key = builder.ToString();
        if (key.Length > 64) key = key[..64];
        return key;
    }
}
