using System.Windows;
using MayflowerIdleRPG.Services;

namespace MayflowerIdleRPG;

public partial class App : System.Windows.Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += (_, args) =>
        {
            string path = ReleaseDiagnostics.LogException(args.Exception, "WPF Dispatcher");
            System.Windows.MessageBox.Show(
                "Mayflower Idle RPG ran into a problem and wrote a crash log." +
                (string.IsNullOrWhiteSpace(path) ? "" : $"\n\nLog: {path}"),
                "Mayflower Idle RPG",
                System.Windows.MessageBoxButton.OK,
                System.Windows.MessageBoxImage.Error);
            args.Handled = true;
            Current.Shutdown();
        };

        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            if (args.ExceptionObject is Exception ex)
                ReleaseDiagnostics.LogException(ex, "AppDomain");
        };
    }
}
