Mayflower Idle RPG - Single File Build

Use Build_Single_File_EXE.bat if you want one EXE that can run on another Windows 64-bit PC without installing .NET.
That EXE will be bigger, but it is the easiest one to share.

Use Build_Single_File_EXE_Framework_Dependent.bat if you want a smaller EXE.
That version still creates one EXE, but the computer running it needs the .NET 8 Desktop Runtime installed.

Output folder:
bin\Release\net8.0-windows\win-x64\publish\

Main command used by the self-contained build:

dotnet publish MayflowerIdleRPG.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:IncludeAllContentForSelfExtract=true -p:EnableCompressionInSingleFile=true -p:PublishTrimmed=false -p:PublishReadyToRun=false

Notes:
- Keep PublishTrimmed=false for WPF. Trimming can break desktop apps that use XAML/reflection.
- The save files will still live outside the EXE, usually under the app's normal AppData save folder.
- Windows may still show SmartScreen warnings until the app is code-signed.
