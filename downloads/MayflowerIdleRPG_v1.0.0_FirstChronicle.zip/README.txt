Mayflower Idle RPG
==================

Mayflower Idle RPG is a fully idle fantasy chronicle. You create or roll a wanderer, then let the world move on its own: travel, towns, rumors, companions, family, danger, recovery, legacy heirs, and long-lived stories unfold without direct control.

Running the app
---------------
Open MayflowerIdleRPG.exe. On first launch, the Character Builder opens automatically. You can either roll a random hero or create your own starting life.

Save location
-------------
Saves, backups, crash logs, bug reports, mods, and corrupt-save quarantine folders are stored in:

%APPDATA%\MayflowerIdleRPG

Useful folders:
- Backups: automatic and manual backups
- CorruptSaves: damaged saves moved aside during recovery
- Logs: crash logs and support logs
- BugReports: generated support zips
- Mods: optional JSON mod content

Release support tools
---------------------
Inside the app, open Menu or Tools to find:
- About / Version
- Reset Window Layout
- Open Logs
- Open Save Folder
- Export World
- Import World
- Bug Report
- Restore Backup

Single-file build
-----------------
This project is configured for single-file Windows publishing. In Visual Studio, publish with:
- Release
- Self-contained
- win-x64
- Produce single file enabled

The publish output should be MayflowerIdleRPG.exe. Some native runtime files may temporarily extract at run time; that is normal for .NET single-file WPF apps.

Reporting bugs
--------------
Use Tools > Bug Report. It creates a zip containing the active save, recent journal, balance details, settings, mods info, build info, and recent logs.

## Living Atlas / Procedural Content
Mayflower Idle RPG can now grow its map over time. The starting world still has handcrafted places, but the chronicle can discover new towns, roads, wilds, dungeons, and legendary locations while the hero travels or completes important work. These generated places are saved with the world, connected into the route map, and can create new rumors, rivals, artifacts, and town records.

Firebase leaderboards
---------------------
This build automatically submits public game stats to the Mayflower Studios Realtime Database leaderboard path:
leaderboards/mayflowerIdleRPG/entries/{installId}

Uploaded fields are gameplay-only: display/character name, bloodline, level, score, age, generation, gold, reputation, quests, artifacts, atlas discoveries, and update time.
It does not upload the save file, email address, private journal text, crash logs, or local file paths.

For the website leaderboard to accept records, publish the included Firebase rules update from the website package.
