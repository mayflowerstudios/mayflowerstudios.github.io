namespace MayflowerIdleRPG.Models;

public class Zone
{
    public required string Name { get; init; }
    public required string[] EnemyNames { get; init; }
    public int UnlockLevel { get; init; }
    public int BaseHp { get; init; }
    public int BaseAttack { get; init; }
    public long BaseGold { get; init; }
    public long BaseXp { get; init; }
}
