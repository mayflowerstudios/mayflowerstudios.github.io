namespace MayflowerIdleRPG.Models;

public class Companion
{
    public string Name { get; set; } = "Mira";
    public string Role { get; set; } = "Healer";
    public int Loyalty { get; set; } = 55;
    public int Bond { get; set; } = 10;
    public int DaysTogether { get; set; } = 0;
    public bool IsActive { get; set; } = true;
    public string PersonalArc { get; set; } = "Still deciding whether this hero is worth the trouble.";

    public int AttackBonus => Role switch
    {
        "Knight" => 8,
        "Rogue" => 5,
        "Mage" => 6,
        "Dog" => 3,
        _ => 2
    } + Bond / 35;

    public int DefenseBonus => Role switch
    {
        "Knight" => 7,
        "Bodyguard" => 6,
        "Healer" => 2,
        "Dog" => 3,
        _ => 1
    } + Loyalty / 45;

    public int SurvivalBonus => Role switch
    {
        "Healer" => 10,
        "Ranger" => 9,
        "Dog" => 8,
        "Merchant" => 5,
        _ => 3
    } + Bond / 25;

    public string Relationship
    {
        get
        {
            int value = (Bond + Loyalty) / 2;
            if (value >= 92) return "sworn companion";
            if (value >= 78) return "family-like bond";
            if (value >= 62) return "trusted friend";
            if (value >= 44) return "traveling partner";
            if (value >= 24) return "uneasy ally";
            return "stranger with baggage";
        }
    }

    public string Summary => $"{Name}, {Role} — {Relationship}, loyalty {Loyalty}, bond {Bond}, {DaysTogether}d together";
}
