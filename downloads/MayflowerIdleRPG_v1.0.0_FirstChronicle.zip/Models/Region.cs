namespace MayflowerIdleRPG.Models;

public class Region
{
    public string Name { get; set; } = "Sunny Meadow";
    public int UnlockLevel { get; set; } = 1;
    public int BaseDanger { get; set; } = 8;
    public int BaseReward { get; set; } = 10;
    public string Flavor { get; set; } = "soft grass, old fences, and suspiciously brave slimes";
    public string[] QuestSeeds { get; set; } = Array.Empty<string>();
    public string[] Trouble { get; set; } = Array.Empty<string>();
    public string[] Discoveries { get; set; } = Array.Empty<string>();
}
