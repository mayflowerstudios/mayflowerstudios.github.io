namespace MayflowerIdleRPG.Models;

public class Quest
{
    public string Name { get; set; } = "No quest";
    public string Type { get; set; } = "Wander";
    public string RegionName { get; set; } = "Sunny Meadow";
    public int Danger { get; set; } = 10;
    public int Progress { get; set; } = 0;
    public int TargetProgress { get; set; } = 4;
    public long RewardGold { get; set; } = 15;
    public long RewardXp { get; set; } = 12;
    public int RewardReputation { get; set; } = 1;
    public int StartedDay { get; set; } = 1;

    public bool IsComplete => Progress >= TargetProgress;
}
