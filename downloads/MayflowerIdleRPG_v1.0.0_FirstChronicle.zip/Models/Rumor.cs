namespace MayflowerIdleRPG.Models;

public class Rumor
{
    public string Title { get; set; } = "a strange light in the woods";
    public string Location { get; set; } = "Brindlewick";
    public string Faction { get; set; } = "Town Guard";
    public int Danger { get; set; } = 10;
    public long Reward { get; set; } = 25;
    public int DaysOld { get; set; } = 0;
    public bool IsResolved { get; set; } = false;
}
