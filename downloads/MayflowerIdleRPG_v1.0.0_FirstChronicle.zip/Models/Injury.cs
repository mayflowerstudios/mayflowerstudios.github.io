namespace MayflowerIdleRPG.Models;

public class Injury
{
    public string Name { get; set; } = "Bruised ribs";
    public string Description { get; set; } = "Every breath files a complaint.";
    public int DaysRemaining { get; set; } = 5;
    public bool IsPermanent { get; set; } = false;
    public bool IsActive => IsPermanent || DaysRemaining > 0;
    public int HpPenalty { get; set; } = 0;
    public int AttackPenalty { get; set; } = 0;
    public int DefensePenalty { get; set; } = 0;
    public int SurvivalPenalty { get; set; } = 0;
}
