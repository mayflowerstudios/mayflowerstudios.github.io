namespace MayflowerIdleRPG.Models;

public class WorldState
{
    public int TownWealth { get; set; } = 52;
    public int RoadSafety { get; set; } = 48;
    public int MonsterPressure { get; set; } = 26;
    public int BanditPower { get; set; } = 20;
    public int FoodSupply { get; set; } = 62;
    public int Plague { get; set; } = 0;
    public int WarTension { get; set; } = 4;
    public int MagicInstability { get; set; } = 8;
    public int Economy { get; set; } = 50;
    public string LastMajorEvent { get; set; } = "The world is quiet, which is never as comforting as it sounds.";
    public int CurrentEra { get; set; } = 1;
    public List<TownRecord> Towns { get; set; } = new();
    public List<WorldHistoryEntry> WorldHistory { get; set; } = new();
    public List<Bloodline> Bloodlines { get; set; } = new();
    public List<Nemesis> Nemeses { get; set; } = new();
    public List<RivalAdventurer> Rivals { get; set; } = new();
    public List<Artifact> WorldArtifacts { get; set; } = new();
    public List<BulletinIssue> Bulletins { get; set; } = new();
    public List<MapNote> MapNotes { get; set; } = new();
    public List<WorldLocation> DiscoveredLocations { get; set; } = new();
    public List<ChronicleMilestone> ChronicleMilestones { get; set; } = new();
    public int ProceduralSeed { get; set; } = 0;
    public int WorldExpansionCount { get; set; } = 0;
    public string DirectorMood { get; set; } = "Balanced";
    public int DirectorPressure { get; set; } = 20;
    public int DifficultyDrift { get; set; } = 0;
    public int RetiredHeroCameos { get; set; } = 0;

    public void Clamp()
    {
        TownWealth = Math.Clamp(TownWealth, 0, 100);
        RoadSafety = Math.Clamp(RoadSafety, 0, 100);
        MonsterPressure = Math.Clamp(MonsterPressure, 0, 100);
        BanditPower = Math.Clamp(BanditPower, 0, 100);
        FoodSupply = Math.Clamp(FoodSupply, 0, 100);
        Plague = Math.Clamp(Plague, 0, 100);
        WarTension = Math.Clamp(WarTension, 0, 100);
        MagicInstability = Math.Clamp(MagicInstability, 0, 100);
        Economy = Math.Clamp(Economy, 0, 100);
        CurrentEra = Math.Max(1, CurrentEra);
        DirectorPressure = Math.Clamp(DirectorPressure, 0, 100);
        DifficultyDrift = Math.Clamp(DifficultyDrift, -50, 80);
        if (DiscoveredLocations == null) DiscoveredLocations = new List<WorldLocation>();
        WorldExpansionCount = Math.Max(0, WorldExpansionCount);
        foreach (var town in Towns) town.Clamp();
        foreach (var nemesis in Nemeses) { nemesis.Threat = Math.Clamp(nemesis.Threat, 0, 150); nemesis.Grudge = Math.Clamp(nemesis.Grudge, 0, 150); }
        foreach (var rival in Rivals) { rival.Level = Math.Max(1, rival.Level); rival.Fame = Math.Clamp(rival.Fame, -100, 9999); }
        foreach (var bloodline in Bloodlines) { bloodline.GenerationCount = Math.Max(1, bloodline.GenerationCount); bloodline.Reputation = Math.Clamp(bloodline.Reputation, -1000, 1000); bloodline.Wealth = Math.Clamp(bloodline.Wealth, 0, 1000000); }
    }
}
