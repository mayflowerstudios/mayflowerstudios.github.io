namespace MayflowerIdleRPG.Models;

public class Player
{
    public string Name { get; set; } = "Adventurer";
    public int Generation { get; set; } = 1;
    public bool IsAlive { get; set; } = true;
    public bool IsRetired { get; set; } = false;
    public string CauseOfEnd { get; set; } = "";
    public string FinalTitle { get; set; } = "";

    public int AgeYears { get; set; } = 18;
    public int AgeDays { get; set; } = 0;
    public bool IsImmortal { get; set; } = false;
    public string ImmortalityPath { get; set; } = "Mortal";
    public int MythicPathProgress { get; set; } = 0;
    public string BloodlineName { get; set; } = "Wanderer";
    public string HeirName { get; set; } = "";
    public bool HasChild { get; set; } = false;
    public string ChildName { get; set; } = "";
    public int ChildAgeYears { get; set; } = 0;
    public int ChildAgeDays { get; set; } = 0;
    public bool ChildIsAdopted { get; set; } = false;
    public string ChildStatus { get; set; } = "No child yet";
    public string FamilyStatus { get; set; } = "Alone on the road";

    public string Difficulty { get; set; } = "Endless Legend";
    public string LifePhilosophy { get; set; } = "Seek Balance";
    public string Background { get; set; } = "Village Runaway";
    public List<string> Traits { get; set; } = new();

    public int StoryDay { get; set; } = 1;
    public int StoryHour { get; set; } = 6;
    public int StoryMinute { get; set; } = 0;
    public string Season { get; set; } = "Spring";
    public int SeasonDay { get; set; } = 1;
    public string Weather { get; set; } = "Mild";

    public int Level { get; set; } = 1;
    public long Xp { get; set; } = 0;
    public long XpToNextLevel { get; set; } = 80;
    public long Gold { get; set; } = 55;
    public int Reputation { get; set; } = 0;
    public int CurrentHp { get; set; } = 140;
    public int Energy { get; set; } = 88;
    public int Hunger { get; set; } = 12;
    public int Morale { get; set; } = 74;
    public int Supplies { get; set; } = 12;
    public int Potions { get; set; } = 3;
    public int Luck { get; set; } = 12;

    public int WeaponTier { get; set; } = 1;
    public int ArmorTier { get; set; } = 1;
    public int CampTier { get; set; } = 1;
    public int GuildRank { get; set; } = 0;

    public int GuildHallTier { get; set; } = 0;
    public int InfirmaryTier { get; set; } = 0;
    public int StableTier { get; set; } = 0;
    public int LibraryTier { get; set; } = 0;
    public int ShrineTier { get; set; } = 0;
    public int BlacksmithTier { get; set; } = 0;
    public int MemorialGardenTier { get; set; } = 0;

    public string Location { get; set; } = "Brindlewick";
    public string Destination { get; set; } = "";
    public string CurrentActivity { get; set; } = "waking up in a cheap room above the tavern";
    public string ActivityType { get; set; } = "Idle";
    public string ActivityName { get; set; } = "Waking up";
    public int ActivityMinutesRemaining { get; set; } = 0;
    public int ActivityTotalMinutes { get; set; } = 0;
    public int ActivityDanger { get; set; } = 0;
    public long ActivityRewardGold { get; set; } = 0;
    public long ActivityRewardXp { get; set; } = 0;
    public string ActivityFaction { get; set; } = "";
    public string ActivityRumor { get; set; } = "";
    public string ActivityArc { get; set; } = "";
    public string ActivityLocation { get; set; } = "Brindlewick";

    public double HungerCarry { get; set; } = 0;
    public double EnergyCarry { get; set; } = 0;
    public double HpCarry { get; set; } = 0;
    public double MoraleCarry { get; set; } = 0;

    public List<Companion> Companions { get; set; } = new();
    public List<Injury> Injuries { get; set; } = new();
    public List<Rumor> Rumors { get; set; } = new();
    public List<StoryArc> StoryArcs { get; set; } = new();
    public Dictionary<string, int> Factions { get; set; } = new();
    public List<string> Timeline { get; set; } = new();
    public List<Artifact> Artifacts { get; set; } = new();
    public List<PetMount> PetsMounts { get; set; } = new();
    public List<DiseaseCondition> Diseases { get; set; } = new();
    public List<EmotionalScar> EmotionalScars { get; set; } = new();
    public DivineFaith Faith { get; set; } = new();
    public MagicResearch Research { get; set; } = new();
    public List<DreamOmen> Dreams { get; set; } = new();

    public int HomeTier { get; set; } = 0;
    public string HomeName { get; set; } = "rented room";
    public int HomeComfort { get; set; } = 0;
    public int GardenTier { get; set; } = 0;
    public int TrophyCount { get; set; } = 0;
    public int FamilyMembers { get; set; } = 0;
    public int Apprentices { get; set; } = 0;

    public long TotalGoldEarned { get; set; } = 0;
    public long TotalEvents { get; set; } = 0;
    public int QuestsCompleted { get; set; } = 0;
    public int QuestsFailed { get; set; } = 0;
    public int AdventuresSurvived { get; set; } = 0;
    public int NearDeaths { get; set; } = 0;
    public int TimesRested { get; set; } = 0;
    public int ShopVisits { get; set; } = 0;
    public int CompanionsMet { get; set; } = 0;
    public int CompanionsLost { get; set; } = 0;
    public int RumorsFollowed { get; set; } = 0;
    public int LegendaryEventsSeen { get; set; } = 0;
    public int RetirementsOffered { get; set; } = 0;
    public int FestivalsAttended { get; set; } = 0;
    public int ArtifactsFound { get; set; } = 0;
    public int NemesisEncounters { get; set; } = 0;
    public int RivalEncounters { get; set; } = 0;
    public int DreamsSeen { get; set; } = 0;
    public int ResearchBreakthroughs { get; set; } = 0;
    public int PetsMet { get; set; } = 0;
    public int MysteryEventsSeen { get; set; } = 0;
    public int FamilyMilestones { get; set; } = 0;


    // Story Director / Map / Storybook update
    public string OriginSeed { get; set; } = "Random Hero";
    public string StartingBurden { get; set; } = "None";
    public string StartingBlessing { get; set; } = "None";
    public string VisualArchetype { get; set; } = "Hooded traveler";
    public int DailyRoutineCount { get; set; } = 0;
    public int IdleCraftingCount { get; set; } = 0;
    public int CompanionDramaCount { get; set; } = 0;
    public int RetiredCameos { get; set; } = 0;
    public int MajorPauses { get; set; } = 0;
    public string LastEventReplay { get; set; } = "No replay recorded yet.";
    public List<StoryChapter> StoryChapters { get; set; } = new();
    public List<EventReplay> EventReplays { get; set; } = new();
    public List<DailyRoutineRecord> DailyRoutines { get; set; } = new();
    public List<CraftProject> CraftingProjects { get; set; } = new();
    public List<CompanionMemory> CompanionPetMemories { get; set; } = new();

    // Polish / safety systems
    public List<string> MemoryTags { get; set; } = new();
    public List<string> CauseEffectThreads { get; set; } = new();
    public int RescueLayersUsed { get; set; } = 0;
    public int BackupRestores { get; set; } = 0;

    public int MaxHp
    {
        get
        {
            int traitBonus = 0;
            if (IsImmortal) traitBonus += 45;
            if (HasTrait("Hardy")) traitBonus += 28;
            if (HasTrait("Frail")) traitBonus -= 14;
            int injuryPenalty = Injuries.Where(i => i.IsActive).Sum(i => i.HpPenalty);
            int diseasePenalty = Diseases.Where(d => d.IsActive).Sum(d => Math.Max(0, d.Severity / 8));
            int agePenalty = IsImmortal ? 0 : Math.Max(0, AgeYears - 55) / 3;
            return Math.Max(55, 135 + Level * 11 + ArmorTier * 11 + CampTier * 4 + InfirmaryTier * 5 + HomeComfort / 3 + traitBonus - injuryPenalty - diseasePenalty - agePenalty);
        }
    }

    public int Attack
    {
        get
        {
            int companionBonus = Companions.Where(c => c.IsActive).Sum(c => c.AttackBonus);
            int injuryPenalty = Injuries.Where(i => i.IsActive).Sum(i => i.AttackPenalty);
            int traitBonus = HasTrait("Reckless") ? 5 : 0;
            int artifactBonus = Artifacts.Where(a => !a.IsLost && a.Kind is "Weapon" or "Relic").Sum(a => a.PowerLevel);
            int ageBonus = AgeYears >= 35 && AgeYears <= 55 ? 2 : 0;
            return Math.Max(1, 6 + Level * 3 + WeaponTier * 7 + BlacksmithTier * 3 + GuildRank + companionBonus + traitBonus + artifactBonus + ageBonus - injuryPenalty);
        }
    }

    public int Defense
    {
        get
        {
            int companionBonus = Companions.Where(c => c.IsActive).Sum(c => c.DefenseBonus);
            int injuryPenalty = Injuries.Where(i => i.IsActive).Sum(i => i.DefensePenalty);
            int petBonus = PetsMounts.Where(p => p.IsAlive).Sum(p => p.Utility / 5);
            int artifactBonus = Artifacts.Where(a => !a.IsLost && a.Kind is "Armor" or "Relic").Sum(a => a.PowerLevel);
            return Math.Max(0, 3 + ArmorTier * 6 + Level / 2 + CampTier + GuildHallTier * 2 + companionBonus + petBonus + artifactBonus - injuryPenalty);
        }
    }

    public int SurvivalBonus
    {
        get
        {
            int companionBonus = Companions.Where(c => c.IsActive).Sum(c => c.SurvivalBonus);
            int injuryPenalty = Injuries.Where(i => i.IsActive).Sum(i => i.SurvivalPenalty);
            int traitBonus = 0;
            if (HasTrait("Lucky")) traitBonus += 9;
            if (HasTrait("Cowardly")) traitBonus += 11;
            if (HasTrait("Practical")) traitBonus += 6;
            if (HasTrait("Reckless")) traitBonus -= 4;
            int petBonus = PetsMounts.Where(p => p.IsAlive).Sum(p => p.Utility);
            int artifactBonus = Artifacts.Where(a => !a.IsLost).Sum(a => a.PowerLevel / 2);
            int faithBonus = Faith.Blessing != "None" && Faith.BlessingDaysRemaining > 0 ? 5 : 0;
            int diseasePenalty = Diseases.Where(d => d.IsActive).Sum(d => d.Severity / 6);
            int emotional = EmotionalScars.Where(e => e.IsActive).Sum(e => e.IsPositive ? e.Intensity / 8 : -e.Intensity / 7);
            return companionBonus + traitBonus + petBonus + artifactBonus + faithBonus + StableTier * 3 + ShrineTier * 2 + LibraryTier + HomeTier * 2 + GardenTier - injuryPenalty - diseasePenalty + emotional;
        }
    }

    public int SurvivalScore => Math.Max(0,
        (StoryDay - 1) * 16 + Level * 90 + QuestsCompleted * 50 + AdventuresSurvived * 14 + Reputation * 10 +
        CompanionsMet * 36 + RumorsFollowed * 20 + LegendaryEventsSeen * 180 + GuildHallTier * 160 +
        ArtifactsFound * 220 + ResearchBreakthroughs * 120 + PetsMet * 70 + FamilyMilestones * 90 +
        StoryArcs.Sum(a => a.IsResolved ? 140 : a.Progress * 3) + (int)Math.Min(900, Gold / 2));

    public bool HasTrait(string trait) => Traits.Any(t => string.Equals(t, trait, StringComparison.OrdinalIgnoreCase));

    public int FactionStanding(string faction)
    {
        if (string.IsNullOrWhiteSpace(faction)) return 0;
        return Factions.TryGetValue(faction, out int value) ? value : 0;
    }

    public void AddFaction(string faction, int amount)
    {
        if (string.IsNullOrWhiteSpace(faction)) return;
        if (!Factions.ContainsKey(faction)) Factions[faction] = 0;
        Factions[faction] = Math.Clamp(Factions[faction] + amount, -100, 100);
    }

    public void Clamp()
    {
        if (CurrentHp > MaxHp) CurrentHp = MaxHp;
        if (CurrentHp < 0) CurrentHp = 0;
        Energy = Math.Clamp(Energy, 0, 100);
        Hunger = Math.Clamp(Hunger, 0, 100);
        Morale = Math.Clamp(Morale, 0, 100);
        Supplies = Math.Clamp(Supplies, 0, 999);
        Potions = Math.Clamp(Potions, 0, 999);
        Luck = Math.Clamp(Luck, 0, 100);
        WeaponTier = Math.Max(1, WeaponTier);
        ArmorTier = Math.Max(1, ArmorTier);
        CampTier = Math.Max(1, CampTier);
        StoryDay = Math.Max(1, StoryDay);
        StoryHour = Math.Clamp(StoryHour, 0, 23);
        StoryMinute = Math.Clamp(StoryMinute, 0, 59);
        SeasonDay = Math.Clamp(SeasonDay, 1, 90);
        ActivityMinutesRemaining = Math.Max(0, ActivityMinutesRemaining);
        ActivityTotalMinutes = Math.Max(0, ActivityTotalMinutes);
        ActivityDanger = Math.Max(0, ActivityDanger);
        if (XpToNextLevel <= 0) XpToNextLevel = 80;
        foreach (var injury in Injuries) injury.DaysRemaining = Math.Max(0, injury.DaysRemaining);
        foreach (var companion in Companions) { companion.Loyalty = Math.Clamp(companion.Loyalty, 0, 100); companion.Bond = Math.Clamp(companion.Bond, 0, 100); }
        foreach (var arc in StoryArcs) { arc.Progress = Math.Clamp(arc.Progress, 0, 100); arc.Threat = Math.Clamp(arc.Threat, 0, 100); }
        AgeYears = Math.Clamp(AgeYears, 1, 9999);
        AgeDays = Math.Clamp(AgeDays, 0, 359);
        ChildAgeYears = Math.Clamp(ChildAgeYears, 0, 9999);
        ChildAgeDays = Math.Clamp(ChildAgeDays, 0, 359);
        if (!HasChild)
        {
            ChildName = string.Empty;
            ChildAgeYears = 0;
            ChildAgeDays = 0;
            ChildIsAdopted = false;
            ChildStatus = "No child yet";
        }
        MythicPathProgress = Math.Clamp(MythicPathProgress, 0, 100);
        HomeTier = Math.Clamp(HomeTier, 0, 10);
        HomeComfort = Math.Clamp(HomeComfort, 0, 100);
        GardenTier = Math.Clamp(GardenTier, 0, 10);
        TrophyCount = Math.Clamp(TrophyCount, 0, 9999);
        FamilyMembers = Math.Clamp(FamilyMembers, 0, 999);
        Apprentices = Math.Clamp(Apprentices, 0, 999);
        foreach (var pet in PetsMounts) { pet.Bond = Math.Clamp(pet.Bond, 0, 100); pet.Utility = Math.Clamp(pet.Utility, 0, 100); }
        foreach (var disease in Diseases) { disease.Severity = Math.Clamp(disease.Severity, 0, 100); disease.DaysRemaining = Math.Max(0, disease.DaysRemaining); }
        foreach (var craft in CraftingProjects) { craft.Progress = Math.Clamp(craft.Progress, 0, 100); }
        foreach (var scar in EmotionalScars) { scar.Intensity = Math.Clamp(scar.Intensity, 0, 100); scar.DaysRemaining = Math.Max(0, scar.DaysRemaining); }
        Faith.Favor = Math.Clamp(Faith.Favor, -100, 100);
        Faith.BlessingDaysRemaining = Math.Max(0, Faith.BlessingDaysRemaining);
        Research.Progress = Math.Clamp(Research.Progress, 0, 100);
    }
}
