namespace MayflowerIdleRPG.Models;

public class Enemy
{
    public string Name { get; set; } = "Slime";
    public int MaxHp { get; set; } = 20;
    public int CurrentHp { get; set; } = 20;
    public int Attack { get; set; } = 2;
    public long GoldReward { get; set; } = 5;
    public long XpReward { get; set; } = 4;

    public bool IsDefeated => CurrentHp <= 0;
}
