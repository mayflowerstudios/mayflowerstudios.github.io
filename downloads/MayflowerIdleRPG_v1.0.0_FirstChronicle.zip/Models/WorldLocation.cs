namespace MayflowerIdleRPG.Models;

public class WorldLocation
{
    public string Name { get; set; } = "Brindlewick";
    public string Kind { get; set; } = "Town";
    public int Danger { get; set; } = 5;
    public int Reward { get; set; } = 20;
    public int InnQuality { get; set; } = 50;
    public int ShopQuality { get; set; } = 50;
    public string Flavor { get; set; } = "a town trying its best";
    public string[] Routes { get; set; } = Array.Empty<string>();
    public string[] QuestSeeds { get; set; } = Array.Empty<string>();
    public string[] RumorSeeds { get; set; } = Array.Empty<string>();
}
