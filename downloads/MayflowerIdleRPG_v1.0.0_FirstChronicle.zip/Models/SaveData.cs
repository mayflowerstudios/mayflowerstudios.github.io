namespace MayflowerIdleRPG.Models;

public class SaveData
{
    public int SaveVersion { get; set; } = 1;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public Player Player { get; set; } = new();
    public WorldState World { get; set; } = new();
    public List<string> StoryLog { get; set; } = new();
    public List<LegacyEntry> HallOfLegends { get; set; } = new();
    public List<ModEventDefinition> CustomEvents { get; set; } = new();
    public GameSettings Settings { get; set; } = new();
    public List<Achievement> Achievements { get; set; } = new();
    public List<StatSnapshot> StatHistory { get; set; } = new();
    public List<string> PatchNotes { get; set; } = new();
    public List<EventTestResult> EventTests { get; set; } = new();
    public List<ImportExportRecord> Transfers { get; set; } = new();
    public DateTime LastSavedUtc { get; set; } = DateTime.UtcNow;
}
