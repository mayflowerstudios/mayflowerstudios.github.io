namespace MayflowerIdleRPG.Models;

public class StoryArc
{
    public string Name { get; set; } = "The Road Grows Restless";
    public string Description { get; set; } = "Bandits, beasts, and bad omens seem connected.";
    public string Stage { get; set; } = "Rumor";
    public int Progress { get; set; } = 0;
    public int Threat { get; set; } = 10;
    public bool IsResolved { get; set; } = false;
    public string Ending { get; set; } = "";
}
