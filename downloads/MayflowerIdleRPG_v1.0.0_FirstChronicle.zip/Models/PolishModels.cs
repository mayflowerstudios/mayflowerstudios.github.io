namespace MayflowerIdleRPG.Models;

public class GameSettings
{
    public string SaveSlot { get; set; } = "Slot 1";
    public string JournalPacing { get; set; } = "Normal";
    public bool PauseOnDeath { get; set; } = true;
    public bool PauseOnLegendaryEvents { get; set; } = false;
    public bool MajorNotifications { get; set; } = true;
    public bool AutoBackups { get; set; } = true;
    public bool WatchMode { get; set; } = false;
    public bool ShowMainMenu { get; set; } = true;
    public bool PauseOnMajorEvents { get; set; } = false;
    public bool SoundEnabled { get; set; } = false;
    public string ThemeName { get; set; } = "Moonlit";
    public string NotificationLevel { get; set; } = "Major Only";
    public bool MiniMode { get; set; } = false;
    public bool StorybookMode { get; set; } = false;
    public bool FirstLaunchComplete { get; set; } = false;
    public string LastKnownAppVersion { get; set; } = "";

    // Public Mayflower website leaderboard. Only game stats are uploaded; no email, save file, or private notes.
    public bool LeaderboardAutoUpload { get; set; } = true;
    public string LeaderboardInstallId { get; set; } = "";
    public string LeaderboardDisplayName { get; set; } = "";
    public DateTime? LastLeaderboardUploadUtc { get; set; }
    public string LastLeaderboardStatus { get; set; } = "Not submitted yet";
}

public class Achievement
{
    public string Id { get; set; } = "achievement";
    public string Name { get; set; } = "Achievement";
    public string Description { get; set; } = "Do something noteworthy.";
    public int Progress { get; set; } = 0;
    public int Target { get; set; } = 1;
    public bool Unlocked { get; set; } = false;
    public DateTime? UnlockedUtc { get; set; }

    public string Summary => Unlocked
        ? $"✓ {Name} — {Description}"
        : $"□ {Name} — {Progress}/{Target}: {Description}";
}

public class StatSnapshot
{
    public int Year { get; set; } = 1;
    public int Day { get; set; } = 1;
    public int StoryDay { get; set; } = 1;
    public int Level { get; set; } = 1;
    public int Score { get; set; } = 0;
    public long Gold { get; set; } = 0;
    public int HpPercent { get; set; } = 100;
    public int WorldDanger { get; set; } = 0;
    public int TownSafety { get; set; } = 50;
    public int Companions { get; set; } = 0;
    public int Artifacts { get; set; } = 0;
    public int QuestsCompleted { get; set; } = 0;

    public string Summary => $"Y{Year} D{Day}: lvl {Level}, score {Score}, gold {Gold}, HP {HpPercent}%, danger {WorldDanger}, town safety {TownSafety}, companions {Companions}, artifacts {Artifacts}, quests {QuestsCompleted}";
}

public class EventTestResult
{
    public string Name { get; set; } = "Event Test";
    public string Result { get; set; } = "No result yet.";
    public DateTime TestedUtc { get; set; } = DateTime.UtcNow;
}


public class MapNote
{
    public string Location { get; set; } = "Brindlewick";
    public string Icon { get; set; } = "•";
    public string Note { get; set; } = "A quiet place on the map.";
    public int Year { get; set; } = 1;
    public int Danger { get; set; } = 0;
    public string Summary => $"{Icon} {Location} — {Note} (Y{Year}, danger {Danger})";
}

public class ChronicleMilestone
{
    public int Year { get; set; } = 1;
    public string Title { get; set; } = "Milestone";
    public string Text { get; set; } = "The world remembers something.";
    public string Summary => $"Year {Year}: {Title} — {Text}";
}

public class StoryChapter
{
    public string Title { get; set; } = "Chapter";
    public int StartYear { get; set; } = 1;
    public int StartDay { get; set; } = 1;
    public List<string> Lines { get; set; } = new();
    public string Summary => $"{Title} (Y{StartYear} D{StartDay})\n" + string.Join("\n", Lines.TakeLast(8));
}

public class EventReplay
{
    public string Title { get; set; } = "Major Event";
    public int Year { get; set; } = 1;
    public int Day { get; set; } = 1;
    public List<string> Steps { get; set; } = new();
    public string Outcome { get; set; } = "Recorded.";
    public string Summary => $"{Title} — Y{Year} D{Day}\n" + string.Join("\n", Steps.Select((s, i) => $"Round {i + 1}: {s}")) + $"\nOutcome: {Outcome}";
}

public class DailyRoutineRecord
{
    public int Year { get; set; } = 1;
    public int Day { get; set; } = 1;
    public string Routine { get; set; } = "A normal day.";
    public string Result { get; set; } = "The hero keeps going.";
    public string Summary => $"Y{Year} D{Day}: {Routine} — {Result}";
}

public class CraftProject
{
    public string Name { get; set; } = "Road repair kit";
    public string Kind { get; set; } = "Utility";
    public int Progress { get; set; } = 0;
    public string Benefit { get; set; } = "Small survival bonus.";
    public bool Completed { get; set; } = false;
    public string Summary => Completed ? $"✓ {Name} ({Kind}) — {Benefit}" : $"□ {Name} ({Kind}) — {Progress}% — {Benefit}";
}

public class CompanionMemory
{
    public string Name { get; set; } = "Unknown";
    public string Kind { get; set; } = "Companion";
    public int YearsTogether { get; set; } = 0;
    public int Bond { get; set; } = 0;
    public string FavoriteMemory { get; set; } = "No memory yet.";
    public string Status { get; set; } = "Active";
    public string Summary => $"{Kind}: {Name} — {Status}, bond {Bond}, years {YearsTogether}. {FavoriteMemory}";
}

public class ImportExportRecord
{
    public DateTime WhenUtc { get; set; } = DateTime.UtcNow;
    public string Action { get; set; } = "Export";
    public string Path { get; set; } = "";
    public string Summary => $"{WhenUtc:u} — {Action}: {Path}";
}
