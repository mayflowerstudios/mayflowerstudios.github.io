namespace MayflowerIdleRPG.Models;

public class Bloodline
{
    public string Name { get; set; } = "Wanderer";
    public int GenerationCount { get; set; } = 1;
    public int Reputation { get; set; } = 0;
    public int Wealth { get; set; } = 0;
    public string KnownFor { get; set; } = "surviving strange roads";
    public string InheritedTrait { get; set; } = "Road Memory";
    public string EstateLocation { get; set; } = "Brindlewick";
    public int EstateTier { get; set; } = 0;
    public List<string> FamilyHistory { get; set; } = new();

    public string Summary => $"House {Name} — gen {GenerationCount}, reputation {Reputation}, wealth {Wealth}, estate tier {EstateTier}, known for {KnownFor}, inherited trait: {InheritedTrait}";
}

public class Artifact
{
    public string Name { get; set; } = "Moonlit Thorn";
    public string Kind { get; set; } = "Relic";
    public string Power { get; set; } = "minor luck";
    public int PowerLevel { get; set; } = 1;
    public int AgeYears { get; set; } = 0;
    public bool IsCursed { get; set; } = false;
    public bool IsLost { get; set; } = false;
    public string CurrentHolder { get; set; } = "Unknown";
    public List<string> History { get; set; } = new();

    public string Summary => $"{Name} ({Kind}) — power {PowerLevel}, {Power}{(IsCursed ? ", cursed" : "")}{(IsLost ? ", lost" : "")}, holder: {CurrentHolder}";
}

public class Nemesis
{
    public string Name { get; set; } = "Varric the Red";
    public string Kind { get; set; } = "Bandit Captain";
    public int Threat { get; set; } = 20;
    public int Grudge { get; set; } = 10;
    public bool IsActive { get; set; } = true;
    public bool IsDefeated { get; set; } = false;
    public string LastSeen { get; set; } = "Old Kingsroad";
    public string Signature { get; set; } = "leaves a silver coin behind";
    public List<string> Encounters { get; set; } = new();

    public string Summary => IsDefeated ? $"{Name}, defeated {Kind.ToLowerInvariant()}" : $"{Name}, {Kind} — threat {Threat}, grudge {Grudge}, last seen near {LastSeen}; {Signature}";
}

public class RivalAdventurer
{
    public string Name { get; set; } = "Iris Vale";
    public string Role { get; set; } = "Treasure Hunter";
    public int Level { get; set; } = 1;
    public int Fame { get; set; } = 0;
    public int Luck { get; set; } = 10;
    public bool IsAlive { get; set; } = true;
    public bool IsRetired { get; set; } = false;
    public string Location { get; set; } = "Brindlewick";
    public string RelationshipToHero { get; set; } = "stranger";
    public string CurrentGoal { get; set; } = "looking for easy work";
    public List<string> History { get; set; } = new();

    public string Summary => $"{Name}, lvl {Level} {Role} — fame {Fame}, {RelationshipToHero}, {Location}, {(IsAlive ? IsRetired ? "retired" : CurrentGoal : "dead")}";
}

public class TownRecord
{
    public string Name { get; set; } = "Brindlewick";
    public int Population { get; set; } = 920;
    public int Wealth { get; set; } = 50;
    public int Safety { get; set; } = 50;
    public int Food { get; set; } = 60;
    public int Medicine { get; set; } = 35;
    public int Morale { get; set; } = 55;
    public int Walls { get; set; } = 10;
    public string FactionControl { get; set; } = "Common Folk";
    public bool IsDestroyed { get; set; } = false;
    public bool IsHaunted { get; set; } = false;
    public string Nickname { get; set; } = "the stubborn village";
    public List<string> LocalHistory { get; set; } = new();

    public void Clamp()
    {
        Population = Math.Clamp(Population, 0, 200000);
        Wealth = Math.Clamp(Wealth, 0, 100);
        Safety = Math.Clamp(Safety, 0, 100);
        Food = Math.Clamp(Food, 0, 100);
        Medicine = Math.Clamp(Medicine, 0, 100);
        Morale = Math.Clamp(Morale, 0, 100);
        Walls = Math.Clamp(Walls, 0, 100);
    }

    public string Summary => IsDestroyed
        ? $"{Name}, ruined {Nickname} — haunted: {IsHaunted}, old control: {FactionControl}"
        : $"{Name}, {Nickname} — pop {Population}, wealth {Wealth}, safety {Safety}, food {Food}, medicine {Medicine}, morale {Morale}, walls {Walls}, controlled by {FactionControl}";
}

public class WorldHistoryEntry
{
    public int Year { get; set; } = 1;
    public int Day { get; set; } = 1;
    public string Category { get; set; } = "History";
    public string Text { get; set; } = "Something happened.";
}

public class PetMount
{
    public string Name { get; set; } = "Moss";
    public string Species { get; set; } = "Dog";
    public int Bond { get; set; } = 20;
    public int Utility { get; set; } = 5;
    public bool IsAlive { get; set; } = true;
    public bool IsMount { get; set; } = false;
    public string Quirk { get; set; } = "judges strangers";

    public string Summary => $"{Name} the {Species} — bond {Bond}, utility {Utility}, {(IsMount ? "mount" : "pet")}, {Quirk}";
}

public class DiseaseCondition
{
    public string Name { get; set; } = "Winter fever";
    public int Severity { get; set; } = 10;
    public int DaysRemaining { get; set; } = 6;
    public bool IsCurse { get; set; } = false;
    public string Description { get; set; } = "A long fever that turns blankets into enemies.";
    public bool IsActive => DaysRemaining > 0 || IsCurse;

    public string Summary => $"{Name} — severity {Severity}, {(IsCurse ? "curse" : DaysRemaining + "d left")}: {Description}";
}

public class EmotionalScar
{
    public string Name { get; set; } = "Homesickness";
    public int Intensity { get; set; } = 10;
    public int DaysRemaining { get; set; } = 30;
    public bool IsPositive { get; set; } = false;
    public string Description { get; set; } = "The road feels too long tonight.";
    public bool IsActive => DaysRemaining > 0;

    public string Summary => $"{Name} — intensity {Intensity}, {DaysRemaining}d: {Description}";
}

public class DivineFaith
{
    public string God { get; set; } = "The Lantern Saint";
    public int Favor { get; set; } = 0;
    public string Blessing { get; set; } = "None";
    public int BlessingDaysRemaining { get; set; } = 0;
    public string Omen { get; set; } = "No omen yet.";

    public string Summary => $"{God}: favor {Favor}, blessing {Blessing} ({BlessingDaysRemaining}d), omen: {Omen}";
}

public class MagicResearch
{
    public string Field { get; set; } = "Healing Magic";
    public int Progress { get; set; } = 0;
    public int Breakthroughs { get; set; } = 0;
    public bool IsForbidden { get; set; } = false;
    public string CurrentTheory { get; set; } = "Notes, ink stains, and several wrong diagrams.";

    public string Summary => $"{Field}: {Progress}% progress, {Breakthroughs} breakthrough(s){(IsForbidden ? ", forbidden" : "")}. {CurrentTheory}";
}

public class BulletinIssue
{
    public int Year { get; set; } = 1;
    public int Day { get; set; } = 1;
    public string Title { get; set; } = "The Brindlewick Bell";
    public List<string> Lines { get; set; } = new();

    public string Summary => $"{Title} — Year {Year}, Day {Day}\n- " + string.Join("\n- ", Lines);
}

public class DreamOmen
{
    public string Symbol { get; set; } = "Black Tower";
    public int Strength { get; set; } = 1;
    public bool CameTrue { get; set; } = false;
    public string Meaning { get; set; } = "Nobody knows yet.";

    public string Summary => $"{Symbol} — strength {Strength}, {(CameTrue ? "fulfilled" : "unfulfilled")}: {Meaning}";
}

public class ModEventDefinition
{
    public string Name { get; set; } = "Custom Event";
    public string Rarity { get; set; } = "Rare";
    public string Text { get; set; } = "A custom event happens.";
    public string Location { get; set; } = "Any";
    public string Effect { get; set; } = "Luck:+1";
    public int MinimumYear { get; set; } = 1;
}
