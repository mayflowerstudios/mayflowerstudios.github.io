namespace MayflowerIdleRPG.Models;

public class LeaderboardEntry
{
    public string id { get; set; } = "";
    public string displayName { get; set; } = "";
    public string characterName { get; set; } = "";
    public string bloodlineName { get; set; } = "";
    public string location { get; set; } = "";
    public string status { get; set; } = "Alive";
    public string finalTitle { get; set; } = "";
    public string appVersion { get; set; } = "";
    public string uploadReason { get; set; } = "autosave";
    public string updatedAtUtc { get; set; } = DateTime.UtcNow.ToString("O");

    public int score { get; set; }
    public int level { get; set; }
    public int generation { get; set; }
    public int ageYears { get; set; }
    public int storyDay { get; set; }
    public int currentYear { get; set; }
    public int daysSurvived { get; set; }
    public long gold { get; set; }
    public long totalGoldEarned { get; set; }
    public int reputation { get; set; }
    public int questsCompleted { get; set; }
    public int questsFailed { get; set; }
    public int adventuresSurvived { get; set; }
    public int artifactsFound { get; set; }
    public int companionsMet { get; set; }
    public int generatedPlaces { get; set; }
    public int worldExpansionCount { get; set; }
    public int legendaryEventsSeen { get; set; }
}

public class LeaderboardSubmitResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = "";
    public DateTime WhenUtc { get; set; } = DateTime.UtcNow;
}
