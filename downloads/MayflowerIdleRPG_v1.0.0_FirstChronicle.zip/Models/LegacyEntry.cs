namespace MayflowerIdleRPG.Models;

public class LegacyEntry
{
    public string Name { get; set; } = "Adventurer";
    public string Title { get; set; } = "The Road-Worn";
    public string EndType { get; set; } = "Death";
    public string CauseOfEnd { get; set; } = "the road collected its debt";
    public string FinalLocation { get; set; } = "Brindlewick";
    public string Background { get; set; } = "Unknown";
    public string Traits { get; set; } = "";
    public int Generation { get; set; } = 1;
    public int DaysSurvived { get; set; } = 0;
    public int Level { get; set; } = 1;
    public int AgeYears { get; set; } = 18;
    public string BloodlineName { get; set; } = "Wanderer";
    public string HeirName { get; set; } = "";
    public string ImmortalityPath { get; set; } = "Mortal";
    public string Artifacts { get; set; } = "";
    public string Pets { get; set; } = "";
    public int Score { get; set; } = 0;
    public int QuestsCompleted { get; set; } = 0;
    public int CompanionsMet { get; set; } = 0;
    public string StorySummary { get; set; } = "";
    public DateTime EndedUtc { get; set; } = DateTime.UtcNow;
}
