using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using System.Windows;
using Forms = System.Windows.Forms;
using Drawing = System.Drawing;
using System.Windows.Controls;
using System.Windows.Threading;
using MayflowerIdleRPG.Models;
using MayflowerIdleRPG.Services;

namespace MayflowerIdleRPG;

public partial class MainWindow : Window
{
    private readonly SaveService _saveService = new();
    private readonly FirebaseLeaderboardService _leaderboardService = new();
    private readonly DispatcherTimer _gameTimer = new();
    private readonly DispatcherTimer _autoSaveTimer = new();
    private readonly Random _random = new();
    private readonly List<WorldLocation> _locations = new();
    private readonly List<string> _storyLog = new();
    private readonly List<ModEventDefinition> _customEvents = new();
    private Forms.NotifyIcon? _trayIcon;
    private Window? _miniWindow;
    private TextBlock? _miniText;
    private bool _suppressMiniWindowClosed;

    private SaveData _saveData = new();
    private bool _isPaused;
    private bool _legacySavedForThisEnd;
    private bool _builderClearLegends;
    private bool _isFirstRun;
    private string _lastSaveStatus = "Not saved yet";
    private int _speedIndex = 0;
    private DateTime _lastBackupUtc = DateTime.MinValue;
    private DateTime _lastLeaderboardSubmitUtc = DateTime.MinValue;
    private bool _leaderboardSubmitInFlight;

    private sealed class CharacterBuildChoice
    {
        public string Name { get; set; } = "";
        public int? AgeYears { get; set; }
        public string OriginSeed { get; set; } = "";
        public string Background { get; set; } = "";
        public string Difficulty { get; set; } = "";
        public string LifePhilosophy { get; set; } = "";
        public string BloodlineName { get; set; } = "";
        public string StartingBurden { get; set; } = "";
        public string StartingBlessing { get; set; } = "";
        public string VisualArchetype { get; set; } = "";
        public string StartingFocus { get; set; } = "Balanced";
        public List<string> Traits { get; set; } = new();
    }

    private sealed class OfflineSnapshot
    {
        public string Location { get; set; } = "";
        public string Destination { get; set; } = "";
        public string Activity { get; set; } = "";
        public int Level { get; set; }
        public long Xp { get; set; }
        public long Gold { get; set; }
        public int Reputation { get; set; }
        public int CurrentHp { get; set; }
        public int Energy { get; set; }
        public int Hunger { get; set; }
        public int Morale { get; set; }
        public int Supplies { get; set; }
        public int Potions { get; set; }
        public int StoryDay { get; set; }
        public int QuestsCompleted { get; set; }
        public int QuestsFailed { get; set; }
        public int AdventuresSurvived { get; set; }
        public int RumorsFollowed { get; set; }
        public int ArtifactsFound { get; set; }
        public int CompanionsMet { get; set; }
        public int CompanionsLost { get; set; }
        public int NearDeaths { get; set; }
        public int MapNotes { get; set; }
        public int KnownPlaces { get; set; }
        public int GeneratedPlaces { get; set; }
        public int WorldExpansions { get; set; }
        public bool IsAlive { get; set; }
        public bool IsRetired { get; set; }
        public string CauseOfEnd { get; set; } = "";
        public string FinalTitle { get; set; } = "";
    }

    private readonly int[] _storyMinutesPerTick = { 1, 10, 60 };
    private readonly string[] _speedNames = { "Realistic", "Fast Forward", "Accelerated" };
    private readonly string[] _seasons = { "Spring", "Summer", "Autumn", "Winter" };
    private readonly string[] _factions = { "Town Guard", "Merchant Guild", "Temple Order", "Mage Circle", "Monster Hunters", "Noble House", "Bandit Clans", "Common Folk" };
    private readonly string[] _gods = { "The Lantern Saint", "Mother Harvest", "The Road-Walker", "Moonflower Queen", "The Forge Father", "Keeper of Last Doors", "Storm-Eyed Orra" };
    private readonly string[] _festivals = { "Lantern Night", "Harvest Week", "First Snow Feast", "Founder's Day", "Moonflower Bloom", "Hero Remembrance Day" };
    private readonly string[] _placePrefixes = { "Amber", "Ash", "Autumn", "Black", "Briar", "Bright", "Candle", "Cloud", "Crow", "Dawn", "Deep", "Dusk", "Elder", "Fallow", "Frost", "Golden", "Green", "Grey", "Hallow", "Hearth", "Hollow", "Iron", "Ivory", "Lantern", "Last", "Little", "Mist", "Moon", "Moss", "Old", "Pale", "Red", "River", "Rose", "Salt", "Silver", "Snow", "Star", "Stone", "Sun", "Thorn", "Velvet", "Whisper", "White", "Wild", "Willow", "Witch" };
    private readonly string[] _placeSuffixes = { "Abbey", "Ash", "Barrow", "Bridge", "Brook", "Cairn", "Chapel", "Crossing", "Crown", "Dale", "Deep", "Downs", "Fen", "Field", "Ford", "Gate", "Glen", "Grove", "Harbor", "Haven", "Hollow", "Keep", "Landing", "Market", "Marsh", "Meadow", "Mill", "Moor", "Pass", "Pines", "Reach", "Rest", "Ridge", "Road", "Run", "Sanctum", "Shore", "Spire", "Spring", "Vale", "Vault", "Watch", "Well", "Wick", "Wood" };
    private readonly string[] _npcFirstNames = { "Alden", "Amara", "Bryn", "Cala", "Corin", "Della", "Elian", "Eira", "Fen", "Garrick", "Hale", "Iris", "Jory", "Kael", "Liora", "Maren", "Nell", "Orin", "Pip", "Quill", "Rhea", "Sable", "Tamsin", "Una", "Vale", "Wren", "Yara" };
    private readonly string[] _npcLastNames = { "Ashhand", "Bellweather", "Briar", "Candlewick", "Dusk", "Emberly", "Foxglove", "Glass", "Hawthorn", "Ironmere", "Lantern", "Moonwell", "Nightjar", "Oak", "Pine", "Quill", "River", "Stonefist", "Sunwhisper", "Thorn", "Vale", "Whisper", "Willow" };
    private readonly string[] _newLocationFlavors = { "old road markers, half-true maps, and windows that glow too late", "rain-polished stones, nervous birds, and people who lower their voices at sunset", "lantern smoke, broken fences, and rumors that keep finding new owners", "quiet wells, crooked paths, and a local rule nobody explains until too late", "mossy statues, cold tea, and a chapel bell that rings when nobody pulls it", "silver grass, careful bridges, and a tavern where strangers are counted twice", "salt wind, black pine, and paths that seem shorter when someone lies", "warm hearths, shuttered shrines, and a market that sells exactly one impossible thing" };
    private readonly string[] _questFragments = { "recovering a stolen heirloom", "guarding a nervous caravan", "finding a lost apprentice", "settling a guild argument", "searching a flooded cellar", "lighting old road lanterns", "following strange tracks", "carrying sealed letters", "repairing a shrine gate", "hunting a creature everyone describes differently", "rescuing goats from a place goats should not be", "mapping a path that keeps moving" };
    private readonly string[] _rumorFragments = { "a door appearing only after rain", "a merchant paying too much for silence", "a pale hound leading travelers home", "a well whispering names at dawn", "a noble hiding under a false name", "bells ringing underground", "a field where shadows point the wrong way", "a shrine answering one question badly", "a child drawing maps of places they never saw", "a lost crown buried under roots" };

    private Player Player => _saveData.Player;
    private WorldState World => _saveData.World;

    public MainWindow()
    {
        InitializeComponent();
        BuildWorld();
        LoadCustomModEvents();
        ConfigureTimers();
        ConfigureTrayIcon();
        _isFirstRun = !_saveService.ActiveSaveExists();
        LoadGame();
        ApplyOfflineProgress();
        Render();

        if (_isFirstRun && !_saveData.Settings.FirstLaunchComplete)
        {
            _saveData.Settings.ShowMainMenu = false;
            AddJournal("Welcome to Mayflower Idle RPG. Create a wanderer or roll a random life to begin the chronicle.", major: true);
            OpenCharacterBuilder(clearLegends: false);
            Render();
        }
    }

    private void BuildWorld()
    {
        _locations.Clear();
        _locations.Add(new WorldLocation
        {
            Name = "Brindlewick", Kind = "Town", Danger = 4, Reward = 18, InnQuality = 70, ShopQuality = 62,
            Flavor = "warm windows, muddy boots, suspiciously heroic job boards, and one tavern that knows everyone's business",
            Routes = new[] { "Sunny Meadow", "Old Kingsroad", "Moonlit Woods" },
            QuestSeeds = new[] { "repairing the mill bridge", "guarding the apothecary's cart", "finding a missing goat with suspicious eyes", "escorting a baker through beetle country" },
            RumorSeeds = new[] { "blue fire above the old well", "a merchant's locked strongbox east of town", "bandits marking doors with white chalk" }
        });
        _locations.Add(new WorldLocation
        {
            Name = "Sunny Meadow", Kind = "Wilds", Danger = 10, Reward = 24, InnQuality = 0, ShopQuality = 16,
            Flavor = "soft grass, broken fences, harmless-looking monsters, and flowers that absolutely know secrets",
            Routes = new[] { "Brindlewick", "Old Kingsroad", "Moonlit Woods" },
            QuestSeeds = new[] { "clearing slimes from a sheep path", "searching the bee chapel", "mapping a flooded footbridge", "recovering charms from a scarecrow field" },
            RumorSeeds = new[] { "a silver fox leading travelers to coin", "a scarecrow moving at noon", "a harmless hill that hums after rain" }
        });
        _locations.Add(new WorldLocation
        {
            Name = "Old Kingsroad", Kind = "Road", Danger = 16, Reward = 34, InnQuality = 35, ShopQuality = 28,
            Flavor = "mossy milestones, abandoned toll huts, wandering caravans, and too many places for ambushes",
            Routes = new[] { "Brindlewick", "Sunny Meadow", "Moonlit Woods", "Riverglass Port", "Ashen Ruins" },
            QuestSeeds = new[] { "joining a caravan for three rough days", "tracking a toll-bandit gang", "carrying sealed letters north", "searching a vanished campsite" },
            RumorSeeds = new[] { "three caravans vanishing after the same shortcut", "a black carriage traveling without horses", "a roadside shrine answering one question per year" }
        });
        _locations.Add(new WorldLocation
        {
            Name = "Moonlit Woods", Kind = "Wilds", Danger = 25, Reward = 48, InnQuality = 0, ShopQuality = 8,
            Flavor = "silver leaves, owl calls, crooked paths, and things that follow from just out of sight",
            Routes = new[] { "Brindlewick", "Sunny Meadow", "Old Kingsroad", "Crystal Caves" },
            QuestSeeds = new[] { "following the lantern trail", "bargaining at a witch's mossy well", "recovering bells from wolf-priest ruins", "finding children lost near a mushroom ring" },
            RumorSeeds = new[] { "a deer with candle-antlers appearing before disasters", "the witch of the well remembering every lie", "moonberries curing wounds before dawn" }
        });
        _locations.Add(new WorldLocation
        {
            Name = "Riverglass Port", Kind = "Town", Danger = 12, Reward = 40, InnQuality = 62, ShopQuality = 78,
            Flavor = "salt air, bright sails, expensive rope, cheap rumors, and sailors who swear they saw worse",
            Routes = new[] { "Old Kingsroad", "Crystal Caves", "Starfall Keep" },
            QuestSeeds = new[] { "loading a cursed cargo", "guarding a pearl-diver crew", "hunting river eels under the docks", "settling a guild debt quietly" },
            RumorSeeds = new[] { "the harbor bell ringing under the water", "a noble heir arriving under a false name", "smugglers hiding medicine in fish barrels" }
        });
        _locations.Add(new WorldLocation
        {
            Name = "Crystal Caves", Kind = "Dungeon", Danger = 40, Reward = 95, InnQuality = 0, ShopQuality = 10,
            Flavor = "glittering tunnels, brittle ledges, cold springs, and treasure that hums like it wants to be found",
            Routes = new[] { "Moonlit Woods", "Riverglass Port", "Ashen Ruins" },
            QuestSeeds = new[] { "finding the singing cavern", "recovering a miner's sealed pack", "mapping the glasswater pool", "repairing the buried lift" },
            RumorSeeds = new[] { "a crystal vein singing louder near blood", "miners finding a door with no handle", "a lost guide selling maps in dreams" }
        });
        _locations.Add(new WorldLocation
        {
            Name = "Ashen Ruins", Kind = "Dungeon", Danger = 58, Reward = 160, InnQuality = 0, ShopQuality = 5,
            Flavor = "black stone, red dust, dead banners, and doors that should have stayed shut",
            Routes = new[] { "Old Kingsroad", "Crystal Caves", "Starfall Keep" },
            QuestSeeds = new[] { "searching the sunken barracks", "recovering a burned knight-banner", "entering the bell tower without a bell", "opening the ash gate" },
            RumorSeeds = new[] { "bone soldiers marching when nobody watches", "a ghost remembering a safe road", "the ash gate opening only for cowards" }
        });
        _locations.Add(new WorldLocation
        {
            Name = "Starfall Keep", Kind = "Legendary", Danger = 86, Reward = 360, InnQuality = 0, ShopQuality = 0,
            Flavor = "fallen stars, royal ghosts, sideways staircases, and treasure that changes endings",
            Routes = new[] { "Riverglass Port", "Ashen Ruins" },
            QuestSeeds = new[] { "reaching the observatory crown", "stealing a comet shard", "entering the silent royal hall", "facing the starforged guard" },
            RumorSeeds = new[] { "a window showing tomorrow's death", "the comet throne choosing a fool every century", "royal ghosts trading secrets for memories" }
        });
    }


    private void EnsureLivingWorldSeeds()
    {
        if (World.Towns.Count == 0)
        {
            World.Towns.AddRange(new[]
            {
                new TownRecord { Name = "Brindlewick", Population = 920, Wealth = 52, Safety = 55, Food = 64, Medicine = 38, Morale = 62, Walls = 14, FactionControl = "Common Folk", Nickname = "the stubborn village" },
                new TownRecord { Name = "Riverglass Port", Population = 4200, Wealth = 68, Safety = 47, Food = 58, Medicine = 45, Morale = 55, Walls = 22, FactionControl = "Merchant Guild", Nickname = "the salt-bright port" },
                new TownRecord { Name = "Starfall Keep", Population = 120, Wealth = 40, Safety = 18, Food = 25, Medicine = 15, Morale = 35, Walls = 66, FactionControl = "Noble House", Nickname = "the broken keep" }
            });
        }

        if (World.Rivals.Count == 0)
        {
            World.Rivals.AddRange(new[]
            {
                new RivalAdventurer { Name = "Iris Vale", Role = "Treasure Hunter", Level = 2, Fame = 8, Location = "Old Kingsroad", CurrentGoal = "hunting old coins" },
                new RivalAdventurer { Name = "Hale Ashhand", Role = "Monster Hunter", Level = 3, Fame = 12, Location = "Moonlit Woods", CurrentGoal = "tracking wolves" },
                new RivalAdventurer { Name = "Pip Quill", Role = "Charm Broker", Level = 1, Fame = 3, Location = "Riverglass Port", CurrentGoal = "selling questionable maps" }
            });
        }

        if (World.Nemeses.Count == 0)
        {
            World.Nemeses.Add(new Nemesis
            {
                Name = "Varric the Red",
                Kind = "Bandit Captain",
                Threat = 24,
                Grudge = 8,
                LastSeen = "Old Kingsroad",
                Signature = "leaves a silver coin where a warning should be"
            });
        }

        if (World.WorldArtifacts.Count == 0)
        {
            World.WorldArtifacts.AddRange(new[]
            {
                new Artifact { Name = "Moonlit Thorn", Kind = "Weapon", Power = "grows sharper after near-death events", PowerLevel = 3, CurrentHolder = "Lost" },
                new Artifact { Name = "Saint Orra's Bell", Kind = "Relic", Power = "softens disease and plague outcomes", PowerLevel = 2, CurrentHolder = "Temple Order" },
                new Artifact { Name = "The Foxglass Ring", Kind = "Relic", Power = "improves luck but invites strange dreams", PowerLevel = 2, IsCursed = true, CurrentHolder = "Unknown" },
                new Artifact { Name = "The Black Lantern", Kind = "Relic", Power = "reveals hidden paths at a morale cost", PowerLevel = 4, IsCursed = true, CurrentHolder = "Lost" }
            });
        }

        foreach (var town in World.Towns) town.Clamp();
    }

    private void MergeDiscoveredLocationsIntoMap()
    {
        World.DiscoveredLocations ??= new List<WorldLocation>();
        foreach (var loc in World.DiscoveredLocations.Where(l => !string.IsNullOrWhiteSpace(l.Name)))
        {
            if (_locations.All(existing => !string.Equals(existing.Name, loc.Name, StringComparison.OrdinalIgnoreCase)))
                _locations.Add(loc);
        }

        foreach (var loc in World.DiscoveredLocations.Where(l => !string.IsNullOrWhiteSpace(l.Name)))
        {
            foreach (string route in loc.Routes ?? Array.Empty<string>())
            {
                AddRoute(loc.Name, route);
                AddRoute(route, loc.Name);
            }
        }
    }

    private void MaybeExpandWorld(string reason, int chance)
    {
        if (!Percent(chance)) return;
        if (_locations.Count >= 80) return;
        var current = CurrentLocation();
        var newLoc = GenerateProceduralLocation(current);
        if (newLoc == null) return;

        AddDiscoveredLocation(newLoc, current, reason);
    }

    private WorldLocation? GenerateProceduralLocation(WorldLocation current)
    {
        string name = GenerateUniqueLocationName();
        if (string.IsNullOrWhiteSpace(name)) return null;

        int roll = _random.Next(100);
        string kind = roll switch
        {
            < 22 => "Town",
            < 50 => "Wilds",
            < 70 => "Road",
            < 91 => "Dungeon",
            _ => "Legendary"
        };

        int baseDanger = kind switch
        {
            "Town" => _random.Next(4, 20),
            "Road" => _random.Next(10, 34),
            "Wilds" => _random.Next(14, 48),
            "Dungeon" => _random.Next(34, 76),
            "Legendary" => _random.Next(62, 98),
            _ => _random.Next(10, 40)
        };
        int danger = Math.Clamp((baseDanger + current.Danger) / 2 + _random.Next(-7, 12) + World.DifficultyDrift / 8, 2, 110);
        int reward = Math.Max(12, danger * _random.Next(2, 5) + _random.Next(8, 45));
        string flavor = Pick(_newLocationFlavors);
        var routeSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { current.Name };

        var nearby = _locations
            .Where(l => l.Name != current.Name)
            .OrderBy(l => Math.Abs(l.Danger - danger) + _random.Next(0, 30))
            .Take(_random.Next(1, 3))
            .ToList();
        foreach (var loc in nearby)
        {
            if (Percent(55)) routeSet.Add(loc.Name);
        }

        return new WorldLocation
        {
            Name = name,
            Kind = kind,
            Danger = danger,
            Reward = reward,
            InnQuality = kind == "Town" ? _random.Next(28, 86) : kind == "Road" ? _random.Next(0, 32) : 0,
            ShopQuality = kind == "Town" ? _random.Next(28, 88) : kind == "Road" ? _random.Next(0, 22) : _random.Next(0, 12),
            Flavor = flavor,
            Routes = routeSet.ToArray(),
            QuestSeeds = GenerateSeedArray(_questFragments, _random.Next(3, 6)),
            RumorSeeds = GenerateSeedArray(_rumorFragments, _random.Next(3, 5))
        };
    }

    private string GenerateUniqueLocationName()
    {
        for (int attempt = 0; attempt < 120; attempt++)
        {
            string name = Pick(_placePrefixes) + " " + Pick(_placeSuffixes);
            if (_locations.All(l => !string.Equals(l.Name, name, StringComparison.OrdinalIgnoreCase)))
                return name;
        }
        World.WorldExpansionCount++;
        return $"Unnamed Reach {World.WorldExpansionCount}";
    }

    private string[] GenerateSeedArray(string[] source, int count)
    {
        var picked = new List<string>();
        for (int i = 0; i < count && picked.Count < source.Length; i++)
        {
            string item = Pick(source);
            if (!picked.Contains(item)) picked.Add(item);
        }
        return picked.ToArray();
    }

    private void AddDiscoveredLocation(WorldLocation newLoc, WorldLocation source, string reason)
    {
        if (_locations.Any(l => string.Equals(l.Name, newLoc.Name, StringComparison.OrdinalIgnoreCase))) return;

        _locations.Add(newLoc);
        World.DiscoveredLocations ??= new List<WorldLocation>();
        World.DiscoveredLocations.Add(newLoc);
        World.WorldExpansionCount++;

        AddRoute(source.Name, newLoc.Name);
        foreach (string route in newLoc.Routes)
            AddRoute(newLoc.Name, route);

        if (newLoc.Kind == "Town" || newLoc.Kind == "Legendary")
        {
            EnsureTownRecordFor(newLoc);
        }

        if (Percent(35)) CreateProceduralRival(newLoc.Name);
        if (Percent(newLoc.Kind == "Dungeon" || newLoc.Kind == "Legendary" ? 38 : 13)) CreateProceduralArtifact(newLoc.Name);
        if (Percent(70)) MaybeCreateRumor("new place");

        string note = $"{newLoc.Name} discovered from {source.Name}: {newLoc.Kind.ToLowerInvariant()}, danger {newLoc.Danger}, reward {newLoc.Reward}.";
        World.MapNotes.Add(new MapNote { Year = CurrentYear(), Location = newLoc.Name, Icon = "✦", Danger = newLoc.Danger, Note = $"Discovered from {source.Name}: {newLoc.Kind.ToLowerInvariant()}, reward {newLoc.Reward}." });
        World.WorldHistory.Add(new WorldHistoryEntry { Year = CurrentYear(), Day = Player.StoryDay, Category = "Discovery", Text = note });
        AddJournal($"The map grows: {Player.Name} learns of {newLoc.Name}, {newLoc.Flavor}. It is now connected to {source.Name}. Reason: {reason}.", major: true);
    }

    private void AddRoute(string from, string to)
    {
        if (string.IsNullOrWhiteSpace(from) || string.IsNullOrWhiteSpace(to) || from == to) return;
        var loc = GetLocation(from);
        if (loc == null) return;
        var routes = loc.Routes?.ToList() ?? new List<string>();
        if (!routes.Any(r => string.Equals(r, to, StringComparison.OrdinalIgnoreCase)))
        {
            routes.Add(to);
            loc.Routes = routes.ToArray();
        }
    }

    private void EnsureTownRecordFor(WorldLocation loc)
    {
        if (World.Towns.Any(t => string.Equals(t.Name, loc.Name, StringComparison.OrdinalIgnoreCase))) return;
        int safety = Math.Clamp(88 - loc.Danger + _random.Next(-8, 12), 8, 92);
        World.Towns.Add(new TownRecord
        {
            Name = loc.Name,
            Population = loc.Kind == "Legendary" ? _random.Next(60, 900) : _random.Next(260, 7600),
            Wealth = Math.Clamp(35 + loc.Reward / 12 + _random.Next(-10, 18), 8, 95),
            Safety = safety,
            Food = _random.Next(30, 88),
            Medicine = _random.Next(18, 78),
            Morale = _random.Next(30, 86),
            Walls = loc.Kind == "Legendary" ? _random.Next(35, 92) : _random.Next(8, 58),
            FactionControl = Pick(_factions),
            Nickname = Pick(new[] { "the newly marked place", "the map-edge town", "the rumor-built settlement", "the lantern stop", "the hard-to-find haven" })
        });
    }

    private void CreateProceduralRival(string location)
    {
        string name = GenerateUniquePersonName();
        if (World.Rivals.Any(r => string.Equals(r.Name, name, StringComparison.OrdinalIgnoreCase))) return;
        string role = Pick(new[] { "Cartographer", "Relic Hunter", "Monster Hunter", "Road Warden", "Charm Broker", "Scout", "Trouble-Solver", "Guild Runner" });
        World.Rivals.Add(new RivalAdventurer
        {
            Name = name,
            Role = role,
            Level = Math.Max(1, Player.Level + _random.Next(-2, 3)),
            Fame = _random.Next(1, 30) + Player.Level,
            Luck = _random.Next(6, 18),
            Location = location,
            RelationshipToHero = "stranger",
            CurrentGoal = Pick(new[] { "mapping roads", "chasing an old rumor", "looking for paid work", "studying local trouble", "seeking a relic" })
        });
    }

    private void CreateProceduralArtifact(string location)
    {
        string name = Pick(new[] { "Lantern", "Bell", "Thorn", "Compass", "Needle", "Mask", "Key", "Crown", "Mirror", "Blade" });
        string prefix = Pick(new[] { "Moon", "Ash", "Silver", "Black", "Elder", "Rose", "Star", "Hollow", "Fox", "Saint" });
        string fullName = $"The {prefix} {name}";
        if (World.WorldArtifacts.Any(a => string.Equals(a.Name, fullName, StringComparison.OrdinalIgnoreCase))) return;
        World.WorldArtifacts.Add(new Artifact
        {
            Name = fullName,
            Kind = Pick(new[] { "Relic", "Weapon", "Charm", "Map", "Crown", "Tool" }),
            Power = Pick(new[] { "reveals safer roads at a cost", "improves luck after failure", "softens wounds near shrines", "attracts difficult rumors", "helps heirs remember old lessons", "makes hidden places easier to find" }),
            PowerLevel = _random.Next(1, 5),
            AgeYears = _random.Next(12, 900),
            IsCursed = Percent(22),
            CurrentHolder = location
        });
    }

    private string GenerateUniquePersonName()
    {
        for (int i = 0; i < 80; i++)
        {
            string name = Pick(_npcFirstNames) + " " + Pick(_npcLastNames);
            if (World.Rivals.All(r => !string.Equals(r.Name, name, StringComparison.OrdinalIgnoreCase)) &&
                Player.Companions.All(c => !string.Equals(c.Name, name, StringComparison.OrdinalIgnoreCase)))
                return name;
        }
        return Pick(_npcFirstNames) + " " + Pick(_npcLastNames) + " " + _random.Next(2, 99);
    }

    private Drawing.Icon LoadTrayIcon()
    {
        try
        {
            var resource = System.Windows.Application.GetResourceStream(new Uri("pack://application:,,,/Assets/AppIcon.ico"));
            if (resource?.Stream != null)
            {
                using var icon = new Drawing.Icon(resource.Stream);
                return (Drawing.Icon)icon.Clone();
            }
        }
        catch
        {
            // Fall back to the default app icon if the embedded icon cannot be read.
        }

        return Drawing.SystemIcons.Application;
    }

    private void ConfigureTrayIcon()
    {
        try
        {
            _trayIcon = new Forms.NotifyIcon
            {
                Icon = LoadTrayIcon(),
                Text = "Mayflower Idle RPG",
                Visible = true,
                ContextMenuStrip = new Forms.ContextMenuStrip()
            };
            _trayIcon.ContextMenuStrip.Items.Add("Show", null, (_, _) => { Show(); WindowState = WindowState.Normal; Activate(); });
            _trayIcon.ContextMenuStrip.Items.Add("Pause/Resume", null, (_, _) => { _isPaused = !_isPaused; Render(); });
            _trayIcon.ContextMenuStrip.Items.Add("Save", null, (_, _) => SaveGame(false));
            _trayIcon.ContextMenuStrip.Items.Add("Exit", null, (_, _) =>
            {
                var tray = _trayIcon;
                if (tray != null)
                {
                    try { tray.Visible = false; } catch { }
                }
                System.Windows.Application.Current.Shutdown();
            });
            _trayIcon.DoubleClick += (_, _) => { Show(); WindowState = WindowState.Normal; Activate(); };
        }
        catch
        {
            _trayIcon = null;
        }
    }

    protected override void OnStateChanged(EventArgs e)
    {
        base.OnStateChanged(e);
        var tray = _trayIcon;
        if (WindowState == WindowState.Minimized && tray != null)
        {
            Hide();
            try
            {
                tray.BalloonTipTitle = "Mayflower Idle RPG";
                tray.BalloonTipText = "The chronicle is still running in the background.";
                tray.ShowBalloonTip(1800);
            }
            catch
            {
                // Tray notifications are optional. Never let them crash shutdown/minimize.
            }
        }
    }

    protected override void OnClosed(EventArgs e)
    {
        try { SaveGame(false); } catch { }
        DisposeTrayIconSafely();
        base.OnClosed(e);
    }

    private void DisposeTrayIconSafely()
    {
        var tray = _trayIcon;
        _trayIcon = null;
        if (tray == null) return;

        try { tray.Visible = false; } catch { }
        try { tray.ContextMenuStrip?.Dispose(); } catch { }
        try { tray.Dispose(); } catch { }
    }

    private void LoadCustomModEvents()
    {
        try
        {
            string root = Path.Combine(Path.GetDirectoryName(_saveService.SavePath) ?? Environment.CurrentDirectory, "Mods");
            Directory.CreateDirectory(root);
            foreach (string sub in new[] { "Events", "Companions", "Artifacts", "Towns", "Gods", "Traits", "Backgrounds", "Diseases", "StoryArcs" })
                Directory.CreateDirectory(Path.Combine(root, sub));

            string path = Path.Combine(root, "Events", "events.sample.json");
            if (!File.Exists(path))
            {
                var sample = new List<ModEventDefinition>
                {
                    new() { Name = "The Crying Statue", Rarity = "Rare", Location = "Any", MinimumYear = 1, Text = "A statue cries clean rainwater into a dry fountain. Nobody agrees what that means.", Effect = "Faith:+3;Morale:+2" },
                    new() { Name = "Mayflower Bloom", Rarity = "Epic", Location = "Brindlewick", MinimumYear = 2, Text = "A white mayflower blooms out of season by the road. The hero keeps walking, but softer.", Effect = "Luck:+2;Reputation:+2" }
                };
                File.WriteAllText(path, JsonSerializer.Serialize(sample, new JsonSerializerOptions { WriteIndented = true }));
            }

            _customEvents.Clear();
            foreach (string file in Directory.GetFiles(root, "*.json", SearchOption.AllDirectories))
            {
                try
                {
                    var events = JsonSerializer.Deserialize<List<ModEventDefinition>>(File.ReadAllText(file));
                    if (events != null) _customEvents.AddRange(events.Where(e => !string.IsNullOrWhiteSpace(e.Name)));
                }
                catch { }
            }
        }
        catch { }
    }

    private void ConfigureTimers()
    {
        _gameTimer.Interval = TimeSpan.FromSeconds(1);
        _gameTimer.Tick += (_, _) =>
        {
            if (!_isPaused && Player.IsAlive && !Player.IsRetired)
            {
                SimulateStoryMinutes(_storyMinutesPerTick[_speedIndex], false);
                Render();
            }
        };
        _gameTimer.Start();

        _autoSaveTimer.Interval = TimeSpan.FromSeconds(30);
        _autoSaveTimer.Tick += (_, _) => SaveGame(false);
        _autoSaveTimer.Start();
    }

    private void LoadGame()
    {
        _saveData = _saveService.Load();
        EnsureSaveData();
        string loadMessage = _saveService.LastLoadMessage;

        if (string.IsNullOrWhiteSpace(Player.Background) || Player.Traits.Count == 0)
            GenerateNewCharacter(keepName: false, clearLegends: false);

        _storyLog.Clear();
        if (_saveData.StoryLog.Count > 0)
            _storyLog.AddRange(_saveData.StoryLog.TakeLast(280));
        else
            AddJournal("The chronicle opens. Create or continue a life, then let the world move on its own.");

        if (!string.IsNullOrWhiteSpace(loadMessage))
            AddJournal(loadMessage, major: true);

        PlayerNameBox.Text = Player.Name;
        SelectCombo(DifficultyBox, Player.Difficulty);
        SelectCombo(PhilosophyBox, Player.LifePhilosophy);
        SelectCombo(PacingBox, _saveData.Settings.JournalPacing);
        SelectCombo(SaveSlotBox, _saveService.ActiveSlot);
        SelectCombo(ThemeBox, _saveData.Settings.ThemeName);
        SelectCombo(OriginBox, Player.OriginSeed);
        _legacySavedForThisEnd = !Player.IsAlive || Player.IsRetired;
    }

    private void EnsureSaveData()
    {
        _saveData ??= new SaveData();
        _saveData.Player ??= new Player();
        _saveData.World ??= new WorldState();
        _saveData.StoryLog ??= new List<string>();
        _saveData.HallOfLegends ??= new List<LegacyEntry>();
        _saveData.CustomEvents ??= new List<ModEventDefinition>();
        _saveData.Settings ??= new GameSettings();
        _saveData.Achievements ??= new List<Achievement>();
        _saveData.StatHistory ??= new List<StatSnapshot>();
        _saveData.PatchNotes ??= new List<string>();
        _saveData.EventTests ??= new List<EventTestResult>();
        _saveData.Transfers ??= new List<ImportExportRecord>();
        if (_saveData.SaveVersion <= 0) _saveData.SaveVersion = 1;
        if (_saveData.CreatedUtc == default) _saveData.CreatedUtc = DateTime.UtcNow;
        if (string.IsNullOrWhiteSpace(_saveData.Settings.SaveSlot)) _saveData.Settings.SaveSlot = _saveService.ActiveSlot;
        if (string.IsNullOrWhiteSpace(_saveData.Settings.JournalPacing)) _saveData.Settings.JournalPacing = "Normal";
        if (string.IsNullOrWhiteSpace(_saveData.Settings.ThemeName)) _saveData.Settings.ThemeName = "Moonlit";
        if (string.IsNullOrWhiteSpace(_saveData.Settings.NotificationLevel)) _saveData.Settings.NotificationLevel = "Major Only";
        if (string.IsNullOrWhiteSpace(_saveData.Settings.LeaderboardInstallId)) _saveData.Settings.LeaderboardInstallId = Guid.NewGuid().ToString("N");
        if (string.IsNullOrWhiteSpace(_saveData.Settings.LastLeaderboardStatus)) _saveData.Settings.LastLeaderboardStatus = "Not submitted yet";
        EnsurePatchNotes();
        EnsureAchievementSeeds();
        World.Towns ??= new List<TownRecord>();
        World.WorldHistory ??= new List<WorldHistoryEntry>();
        World.Bloodlines ??= new List<Bloodline>();
        World.Nemeses ??= new List<Nemesis>();
        World.Rivals ??= new List<RivalAdventurer>();
        World.WorldArtifacts ??= new List<Artifact>();
        World.Bulletins ??= new List<BulletinIssue>();
        World.MapNotes ??= new List<MapNote>();
        World.DiscoveredLocations ??= new List<WorldLocation>();
        World.ChronicleMilestones ??= new List<ChronicleMilestone>();
        if (World.ProceduralSeed == 0) World.ProceduralSeed = _random.Next(100000, 999999);
        World.DirectorMood = string.IsNullOrWhiteSpace(World.DirectorMood) ? "Balanced" : World.DirectorMood;
        EnsureLivingWorldSeeds();
        MergeDiscoveredLocationsIntoMap();
        EnsureStoryDirectorSeeds();

        Player.Name = string.IsNullOrWhiteSpace(Player.Name) ? "Adventurer" : Player.Name;
        Player.Difficulty = string.IsNullOrWhiteSpace(Player.Difficulty) ? "Endless Legend" : Player.Difficulty;
        Player.LifePhilosophy = string.IsNullOrWhiteSpace(Player.LifePhilosophy) ? "Seek Balance" : Player.LifePhilosophy;
        Player.Background = Player.Background ?? "";
        Player.FinalTitle ??= "";
        Player.CauseOfEnd ??= "";
        Player.Location = string.IsNullOrWhiteSpace(Player.Location) ? "Brindlewick" : Player.Location;
        Player.Destination ??= "";
        Player.Season = string.IsNullOrWhiteSpace(Player.Season) ? "Spring" : Player.Season;
        Player.Weather = string.IsNullOrWhiteSpace(Player.Weather) ? "Mild" : Player.Weather;
        Player.ActivityType = string.IsNullOrWhiteSpace(Player.ActivityType) ? "Idle" : Player.ActivityType;
        Player.ActivityName = string.IsNullOrWhiteSpace(Player.ActivityName) ? "Deciding" : Player.ActivityName;
        Player.CurrentActivity = string.IsNullOrWhiteSpace(Player.CurrentActivity) ? "deciding what the road wants next" : Player.CurrentActivity;
        Player.ActivityLocation = string.IsNullOrWhiteSpace(Player.ActivityLocation) ? Player.Location : Player.ActivityLocation;
        Player.ActivityFaction ??= "";
        Player.ActivityRumor ??= "";
        Player.ActivityArc ??= "";

        Player.Traits ??= new List<string>();
        Player.Companions ??= new List<Companion>();
        Player.Injuries ??= new List<Injury>();
        Player.Rumors ??= new List<Rumor>();
        Player.StoryArcs ??= new List<StoryArc>();
        Player.Factions ??= new Dictionary<string, int>();
        Player.Timeline ??= new List<string>();
        Player.Artifacts ??= new List<Artifact>();
        Player.PetsMounts ??= new List<PetMount>();
        Player.Diseases ??= new List<DiseaseCondition>();
        Player.EmotionalScars ??= new List<EmotionalScar>();
        Player.Faith ??= new DivineFaith();
        Player.Research ??= new MagicResearch();
        Player.Dreams ??= new List<DreamOmen>();
        Player.MemoryTags ??= new List<string>();
        Player.CauseEffectThreads ??= new List<string>();
        Player.StoryChapters ??= new List<StoryChapter>();
        Player.EventReplays ??= new List<EventReplay>();
        Player.DailyRoutines ??= new List<DailyRoutineRecord>();
        Player.CraftingProjects ??= new List<CraftProject>();
        Player.CompanionPetMemories ??= new List<CompanionMemory>();
        Player.OriginSeed = string.IsNullOrWhiteSpace(Player.OriginSeed) ? "Random Hero" : Player.OriginSeed;
        Player.StartingBurden = string.IsNullOrWhiteSpace(Player.StartingBurden) ? "None" : Player.StartingBurden;
        Player.StartingBlessing = string.IsNullOrWhiteSpace(Player.StartingBlessing) ? "None" : Player.StartingBlessing;
        Player.VisualArchetype = string.IsNullOrWhiteSpace(Player.VisualArchetype) ? "Hooded traveler" : Player.VisualArchetype;
        Player.LastEventReplay = string.IsNullOrWhiteSpace(Player.LastEventReplay) ? "No replay recorded yet." : Player.LastEventReplay;
        Player.HomeName = string.IsNullOrWhiteSpace(Player.HomeName) ? "rented room" : Player.HomeName;
        if (string.IsNullOrWhiteSpace(Player.Faith.God)) Player.Faith.God = Pick(_gods);
        if (string.IsNullOrWhiteSpace(Player.Faith.Blessing)) Player.Faith.Blessing = "None";
        if (string.IsNullOrWhiteSpace(Player.Research.Field)) Player.Research.Field = "Healing Magic";

        foreach (string faction in _factions)
            if (!Player.Factions.ContainsKey(faction)) Player.Factions[faction] = 0;

        if (GetLocation(Player.Location) == null)
            Player.Location = "Brindlewick";
        if (Player.CurrentHp <= 0 && Player.IsAlive && !Player.IsRetired)
            Player.CurrentHp = Player.MaxHp;

        Player.Clamp();
        World.Clamp();
    }

    private void EnsurePatchNotes()
    {
        var notes = _saveData.PatchNotes;
        void AddNote(string note)
        {
            if (!notes.Contains(note)) notes.Insert(0, note);
        }
        AddNote("Version 1.1 - Legacy Heirs Update: children can be born or adopted through home life, grow over time, and inherit the chronicle if the parent dies.");
        AddNote("Version 1.0 - Story Director, Map, and Storybook Update: main menu, origin seeds, map view, storybook chapters, event replays, director AI pacing, pause-on-major-events, mini mode, companion/pet memory books, mod manager tools, import/export, bug report zips, map milestones, economy drift, daily routines, idle crafting, newspaper archive, retired hero cameos, and richer themes.");
        AddNote("Version 0.9 - Polish, Safety, and Watch Update: balance details, pacing settings, save slots, backups, achievements, watch mode, stats, event checks, memory callbacks, peaceful life events, and layered death prevention.");
        AddNote("Version 0.8 - Living World Update: bloodlines, aging, mythic paths, towns, artifacts, rivals, nemeses, bulletins, gods, research, pets, festivals, tray mode, and JSON mods.");
        while (notes.Count > 30) notes.RemoveAt(notes.Count - 1);
    }

    private void EnsureAchievementSeeds()
    {
        _saveData.Achievements ??= new List<Achievement>();
        var defs = new[]
        {
            new Achievement { Id = "survive_1_year", Name = "First Winter Behind You", Description = "Survive one full year.", Target = 1 },
            new Achievement { Id = "survive_10_years", Name = "Decade-Worn", Description = "Survive ten years in one life.", Target = 10 },
            new Achievement { Id = "first_retirement", Name = "Warm Chair Ending", Description = "Have any hero retire.", Target = 1 },
            new Achievement { Id = "first_artifact", Name = "Definitely Not Cursed", Description = "Find a legendary artifact.", Target = 1 },
            new Achievement { Id = "first_pet", Name = "Road Paws", Description = "Meet a pet or mount.", Target = 1 },
            new Achievement { Id = "town_destroyed", Name = "The Bell Went Silent", Description = "Witness a town fall into ruin.", Target = 1 },
            new Achievement { Id = "become_immortal", Name = "Death Lost The Argument", Description = "Unlock an immortality or mythic path.", Target = 1 },
            new Achievement { Id = "bloodline_3", Name = "Family Name", Description = "Reach generation three in a bloodline.", Target = 3 },
            new Achievement { Id = "defeat_nemesis", Name = "Grudge Paid", Description = "Defeat a nemesis.", Target = 1 },
            new Achievement { Id = "live_100_years", Name = "Century Chronicle", Description = "Survive one hundred years in one world/life.", Target = 100 },
            new Achievement { Id = "world_500_years", Name = "Ancient Save File", Description = "Let a world reach five hundred years of history.", Target = 500 },
            new Achievement { Id = "rescued_10", Name = "Absolutely Refuses To Die", Description = "Use ten layered rescue/death-prevention saves.", Target = 10 }
        };
        foreach (var def in defs)
        {
            var existing = _saveData.Achievements.FirstOrDefault(a => a.Id == def.Id);
            if (existing == null)
                _saveData.Achievements.Add(def);
            else
            {
                existing.Name = def.Name;
                existing.Description = def.Description;
                existing.Target = def.Target;
            }
        }
    }

    private void GenerateNewCharacter(bool keepName, bool clearLegends, CharacterBuildChoice? custom = null)
    {
        var oldLegends = clearLegends ? new List<LegacyEntry>() : _saveData.HallOfLegends.ToList();
        var oldWorld = clearLegends ? new WorldState() : (_saveData.World ?? new WorldState());
        var oldSettings = _saveData.Settings ?? new GameSettings();
        var oldAchievements = _saveData.Achievements?.ToList() ?? new List<Achievement>();
        var oldStatHistory = clearLegends ? new List<StatSnapshot>() : (_saveData.StatHistory?.ToList() ?? new List<StatSnapshot>());
        var oldPatchNotes = _saveData.PatchNotes?.ToList() ?? new List<string>();
        var oldTransfers = _saveData.Transfers?.ToList() ?? new List<ImportExportRecord>();
        var oldEventTests = _saveData.EventTests?.ToList() ?? new List<EventTestResult>();
        var oldCustomEvents = _saveData.CustomEvents?.ToList() ?? new List<ModEventDefinition>();
        int generation = oldLegends.Count == 0 ? 1 : oldLegends.Max(l => l.Generation) + 1;
        string selectedName = !string.IsNullOrWhiteSpace(custom?.Name)
            ? custom!.Name.Trim()
            : (keepName && !string.IsNullOrWhiteSpace(PlayerNameBox.Text)
                ? PlayerNameBox.Text.Trim()
                : Pick(new[] { "Rowan", "Mira", "Eryn", "Cass", "Talia", "Niko", "Briar", "Liora", "Sable", "Juniper", "Vey", "Marin", "Elowen", "Thorn", "Aster" }));

        _saveData = new SaveData
        {
            HallOfLegends = oldLegends,
            World = oldWorld,
            Settings = oldSettings,
            Achievements = oldAchievements,
            StatHistory = oldStatHistory,
            PatchNotes = oldPatchNotes,
            Transfers = oldTransfers,
            EventTests = oldEventTests,
            CustomEvents = oldCustomEvents
        };
        EnsureSaveData();

        Player.Name = selectedName;
        Player.Generation = generation;
        Player.Difficulty = !string.IsNullOrWhiteSpace(custom?.Difficulty) ? custom!.Difficulty : ComboText(DifficultyBox, "Endless Legend");
        Player.LifePhilosophy = !string.IsNullOrWhiteSpace(custom?.LifePhilosophy) ? custom!.LifePhilosophy : ComboText(PhilosophyBox, "Seek Balance");
        Player.OriginSeed = !string.IsNullOrWhiteSpace(custom?.OriginSeed) ? custom!.OriginSeed : ComboText(OriginBox, "Random Hero");
        Player.Background = !string.IsNullOrWhiteSpace(custom?.Background)
            ? custom!.Background
            : Player.OriginSeed switch
            {
                "Orphan Wanderer" => "Orphaned Farmhand",
                "Failed Noble" => "Exiled Noble",
                "Temple Child" => "Former Temple Apprentice",
                "Old Soldier" => "Retired Guard",
                "Cursed Bloodline" => "Cursed Wanderer",
                "Merchant's Heir" => "Dockside Errand Runner",
                "Wild Forest Foundling" => "Witch's Errand Runner",
                _ => Pick(new[]
            {
                "Exiled Noble", "Village Runaway", "Former Temple Apprentice", "Debt-Ridden Mercenary", "Failed Mage Student",
                "Orphaned Farmhand", "Retired Guard", "Cursed Wanderer", "Dockside Errand Runner", "Disgraced Squire", "Guild Orphan", "Witch's Errand Runner"
            })
            };
        Player.Traits = custom?.Traits.Count > 0 ? NormalizeCustomTraits(custom.Traits) : RollTraits();
        Player.StoryArcs = CreateStartingArcs();
        Player.StartingBurden = !string.IsNullOrWhiteSpace(custom?.StartingBurden) ? custom!.StartingBurden : RollStartingBurden(Player.OriginSeed);
        Player.StartingBlessing = !string.IsNullOrWhiteSpace(custom?.StartingBlessing) ? custom!.StartingBlessing : RollStartingBlessing(Player.OriginSeed);
        Player.VisualArchetype = !string.IsNullOrWhiteSpace(custom?.VisualArchetype) ? custom!.VisualArchetype : RollVisualArchetype(Player.Background);
        Player.Factions = _factions.ToDictionary(f => f, _ => _random.Next(-4, 7));
        Player.AgeYears = custom?.AgeYears ?? _random.Next(17, 31);
        Player.AgeDays = _random.Next(0, 90);
        Player.IsImmortal = false;
        Player.ImmortalityPath = "Mortal";
        Player.MythicPathProgress = 0;
        Player.BloodlineName = !string.IsNullOrWhiteSpace(custom?.BloodlineName) ? custom!.BloodlineName.Trim() : ChooseBloodline(oldLegends);
        Player.HeirName = Pick(new[] { "Mira", "Tovin", "Sera", "Nell", "Hale", "Juniper", "Aster", "Liora", "Briar" });
        Player.HasChild = false;
        Player.ChildName = string.Empty;
        Player.ChildAgeYears = 0;
        Player.ChildAgeDays = 0;
        Player.ChildIsAdopted = false;
        Player.ChildStatus = "No child yet";
        Player.FamilyStatus = string.IsNullOrWhiteSpace(custom?.BloodlineName)
            ? "A small name in a world that forgets quickly"
            : $"House {Player.BloodlineName}, newly written into the ledger";
        Player.Faith = new DivineFaith { God = Pick(_gods), Favor = _random.Next(-4, 8), Blessing = "None", Omen = "No omen yet." };
        Player.Research = new MagicResearch { Field = Pick(new[] { "Healing Magic", "Warding Magic", "Monster Lore", "Artifact Study", "Dream Magic", "Weather Rituals", "Portal Magic", "Forbidden Necromancy" }) };
        Player.Research.IsForbidden = Player.Research.Field == "Forbidden Necromancy";
        Player.CurrentHp = Player.MaxHp;
        Player.Location = "Brindlewick";
        Player.CurrentActivity = "standing outside the tavern, pretending this is a plan";
        Player.ActivityMinutesRemaining = 0;
        Player.ActivityTotalMinutes = 0;
        Player.ActivityLocation = Player.Location;

        ApplyBackgroundAndTraits();
        ApplyOriginSeedEffects();
        ApplyStartingFocus(custom?.StartingFocus ?? "Balanced");
        ApplyLegacyInheritance(oldLegends);
        EnsureBloodlineForHero();
        Player.Clamp();

        PlayerNameBox.Text = Player.Name;
        SelectCombo(DifficultyBox, Player.Difficulty);
        SelectCombo(PhilosophyBox, Player.LifePhilosophy);
        SelectCombo(OriginBox, Player.OriginSeed);

        _storyLog.Clear();
        AddJournal($"{Player.Name} begins generation {Player.Generation} as a {Player.Background.ToLowerInvariant()} from House {Player.BloodlineName} — {string.Join(", ", Player.Traits.Select(t => t.ToLowerInvariant()))}. The chosen rule is '{Player.LifePhilosophy}' on {Player.Difficulty} difficulty.");
        AddJournal($"Origin seed: {Player.OriginSeed}. Burden: {Player.StartingBurden}. Blessing: {Player.StartingBlessing}. The portrait card calls them a {Player.VisualArchetype.ToLowerInvariant()}.");
        AddJournal("This life is fully idle. The hero will rest, shop, work, travel, chase rumors, build bonds, invest in a hall, face arcs, retire, die, or become absurdly hard to kill without needing orders.");
        StartStoryChapter("Chapter I — The First Road", $"{Player.Name} begins in Brindlewick with {Player.StartingBurden.ToLowerInvariant()} and {Player.StartingBlessing.ToLowerInvariant()}.");
        AddMapNote(Player.Location, "★", $"{Player.Name}'s generation began here.", 0);
        AddTimeline($"Generation {Player.Generation} begins in Brindlewick.");
        _legacySavedForThisEnd = false;
        SaveGame(false);
    }

    private List<string> NormalizeCustomTraits(IEnumerable<string> selectedTraits)
    {
        string[] allTraits = { "Brave", "Cowardly", "Greedy", "Kindhearted", "Reckless", "Lucky", "Frail", "Charming", "Hardy", "Curious", "Practical", "Haunted", "Patient", "Stubborn" };
        var traits = selectedTraits
            .Where(t => !string.IsNullOrWhiteSpace(t) && !t.StartsWith("Random", StringComparison.OrdinalIgnoreCase))
            .Select(t => t.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        while (traits.Count < 3)
        {
            string trait = Pick(allTraits);
            if (!traits.Contains(trait, StringComparer.OrdinalIgnoreCase)) traits.Add(trait);
        }

        if (traits.Contains("Brave", StringComparer.OrdinalIgnoreCase) && traits.Contains("Cowardly", StringComparer.OrdinalIgnoreCase)) traits.RemoveAll(t => string.Equals(t, "Cowardly", StringComparison.OrdinalIgnoreCase));
        if (traits.Contains("Frail", StringComparer.OrdinalIgnoreCase) && traits.Contains("Hardy", StringComparer.OrdinalIgnoreCase)) traits.RemoveAll(t => string.Equals(t, "Frail", StringComparison.OrdinalIgnoreCase));

        while (traits.Count < 3)
        {
            string trait = Pick(allTraits);
            if (!traits.Contains(trait, StringComparer.OrdinalIgnoreCase)) traits.Add(trait);
        }

        return traits.Take(3).ToList();
    }

    private void ApplyStartingFocus(string focus)
    {
        switch (focus)
        {
            case "Fighter":
                Player.WeaponTier += 1;
                Player.CurrentHp += 10;
                Player.AddFaction("Monster Hunters", 6);
                break;
            case "Survivor":
                Player.CampTier += 1;
                Player.Supplies += 4;
                Player.Energy += 6;
                break;
            case "Trader":
                Player.Gold += 30;
                Player.Reputation += 2;
                Player.AddFaction("Merchant Guild", 10);
                break;
            case "Scholar":
                Player.LibraryTier += 1;
                Player.Luck += 4;
                Player.Research.Field = "Artifact Study";
                Player.Research.IsForbidden = false;
                break;
            case "Healer":
                Player.Potions += 3;
                Player.InfirmaryTier += 1;
                Player.AddFaction("Temple Order", 6);
                break;
            case "Homestead":
                Player.HomeTier = Math.Max(Player.HomeTier, 1);
                Player.HomeName = "small inherited room";
                Player.HomeComfort += 8;
                Player.Supplies += 5;
                Player.Morale += 4;
                break;
        }
    }

    private void OpenCharacterBuilder(bool clearLegends)
    {
        _builderClearLegends = clearLegends;
        CharacterBuilderOverlay.Visibility = Visibility.Visible;
        MainMenuOverlay.Visibility = Visibility.Collapsed;
        FirstLaunchWelcomePanel.Visibility = _isFirstRun && !_saveData.Settings.FirstLaunchComplete ? Visibility.Visible : Visibility.Collapsed;

        BuilderNameBox.Text = !string.IsNullOrWhiteSpace(PlayerNameBox.Text) ? PlayerNameBox.Text.Trim() : Player.Name;
        BuilderAgeBox.Text = Player.AgeYears > 0 ? Player.AgeYears.ToString() : "19";
        BuilderBloodlineBox.Text = Player.BloodlineName is "Wanderer" ? "" : Player.BloodlineName;
        SelectCombo(BuilderOriginBox, Player.OriginSeed);
        SelectCombo(BuilderBackgroundBox, "Random Background");
        SelectCombo(BuilderLifeRuleBox, Player.LifePhilosophy);
        SelectCombo(BuilderDifficultyBox, Player.Difficulty);
        SelectCombo(BuilderFocusBox, "Balanced");
        SelectCombo(BuilderTraitOneBox, "Random Trait");
        SelectCombo(BuilderTraitTwoBox, "Random Trait");
        SelectCombo(BuilderTraitThreeBox, "Random Trait");
        SelectCombo(BuilderBurdenBox, "Random Burden");
        SelectCombo(BuilderBlessingBox, "Random Blessing");
        SelectCombo(BuilderVisualBox, "Random Look");
        BuilderRandomizeButton_Click(this, new RoutedEventArgs());
        BuilderCustomPreviewText.Text = BuildCustomPreviewText(ReadCharacterBuilderChoice());
    }

    private CharacterBuildChoice BuildRandomPreviewChoice()
    {
        string origin = Pick(new[] { "Random Hero", "Orphan Wanderer", "Failed Noble", "Temple Child", "Old Soldier", "Cursed Bloodline", "Merchant's Heir", "Wild Forest Foundling" });
        string background = origin switch
        {
            "Orphan Wanderer" => "Orphaned Farmhand",
            "Failed Noble" => "Exiled Noble",
            "Temple Child" => "Former Temple Apprentice",
            "Old Soldier" => "Retired Guard",
            "Cursed Bloodline" => "Cursed Wanderer",
            "Merchant's Heir" => "Dockside Errand Runner",
            "Wild Forest Foundling" => "Witch's Errand Runner",
            _ => Pick(new[] { "Exiled Noble", "Village Runaway", "Former Temple Apprentice", "Debt-Ridden Mercenary", "Failed Mage Student", "Orphaned Farmhand", "Retired Guard", "Cursed Wanderer", "Dockside Errand Runner", "Disgraced Squire", "Guild Orphan", "Witch's Errand Runner" })
        };

        return new CharacterBuildChoice
        {
            Name = Pick(new[] { "Rowan", "Mira", "Eryn", "Cass", "Talia", "Niko", "Briar", "Liora", "Sable", "Juniper", "Vey", "Marin", "Elowen", "Thorn", "Aster" }),
            AgeYears = _random.Next(17, 31),
            OriginSeed = origin,
            Background = background,
            Difficulty = ComboText(BuilderDifficultyBox, "Endless Legend"),
            LifePhilosophy = ComboText(BuilderLifeRuleBox, "Seek Balance"),
            BloodlineName = Pick(new[] { "Lantern", "Moonroot", "Ashvale", "Sunwhisper", "Hawthorne", "Stonemoss", "Foxglove", "Emberkeep" }),
            StartingBurden = Pick(new[] { "Debt to a guild collector", "A family name nobody trusts", "A curse that wakes at night", "A promise to protect someone missing", "No safe home to return to", "A map that lies sometimes" }),
            StartingBlessing = Pick(new[] { "A lucky charm from an old friend", "A road-worn blade that never rusts", "A healer's pouch of careful remedies", "A lantern that burns through bad weather", "A small purse of emergency coin", "A song that calms frightened companions" }),
            VisualArchetype = RollVisualArchetype(background),
            StartingFocus = Pick(new[] { "Balanced", "Fighter", "Survivor", "Trader", "Scholar", "Healer", "Homestead" }),
            Traits = RollTraits()
        };
    }

    private CharacterBuildChoice? _lastRandomPreview;

    private string BuildCustomPreviewText(CharacterBuildChoice choice)
    {
        string traits = choice.Traits.Count == 0 ? "3 random traits" : string.Join(", ", NormalizeCustomTraits(choice.Traits));
        return $"{(string.IsNullOrWhiteSpace(choice.Name) ? "A new wanderer" : choice.Name)} • age {(choice.AgeYears?.ToString() ?? "random")}\n" +
               $"Origin: {(string.IsNullOrWhiteSpace(choice.OriginSeed) ? "Random Hero" : choice.OriginSeed)}\n" +
               $"Background: {(string.IsNullOrWhiteSpace(choice.Background) ? "random from origin" : choice.Background)}\n" +
               $"House: {(string.IsNullOrWhiteSpace(choice.BloodlineName) ? "random bloodline" : choice.BloodlineName)}\n" +
               $"Traits: {traits}\n" +
               $"Burden: {(string.IsNullOrWhiteSpace(choice.StartingBurden) ? "random" : choice.StartingBurden)}\n" +
               $"Blessing: {(string.IsNullOrWhiteSpace(choice.StartingBlessing) ? "random" : choice.StartingBlessing)}\n" +
               $"Look: {(string.IsNullOrWhiteSpace(choice.VisualArchetype) ? "random" : choice.VisualArchetype)}\n" +
               $"Focus: {choice.StartingFocus}\n" +
               $"Rule: {choice.LifePhilosophy} • Difficulty: {choice.Difficulty}";
    }

    private CharacterBuildChoice ReadCharacterBuilderChoice()
    {
        int? age = null;
        if (int.TryParse(BuilderAgeBox.Text.Trim(), out int parsedAge)) age = Math.Clamp(parsedAge, 12, 90);

        string origin = ComboText(BuilderOriginBox, "Random Hero");
        string background = ComboText(BuilderBackgroundBox, "Random Background");
        string burden = ComboText(BuilderBurdenBox, "Random Burden");
        string blessing = ComboText(BuilderBlessingBox, "Random Blessing");
        string visual = ComboText(BuilderVisualBox, "Random Look");

        var traits = new List<string>
        {
            ComboText(BuilderTraitOneBox, "Random Trait"),
            ComboText(BuilderTraitTwoBox, "Random Trait"),
            ComboText(BuilderTraitThreeBox, "Random Trait")
        };

        return new CharacterBuildChoice
        {
            Name = BuilderNameBox.Text.Trim(),
            AgeYears = age,
            OriginSeed = origin.StartsWith("Random", StringComparison.OrdinalIgnoreCase) ? "" : origin,
            Background = background.StartsWith("Random", StringComparison.OrdinalIgnoreCase) ? "" : background,
            Difficulty = ComboText(BuilderDifficultyBox, "Endless Legend"),
            LifePhilosophy = ComboText(BuilderLifeRuleBox, "Seek Balance"),
            BloodlineName = BuilderBloodlineBox.Text.Trim(),
            StartingBurden = burden.StartsWith("Random", StringComparison.OrdinalIgnoreCase) ? "" : burden,
            StartingBlessing = blessing.StartsWith("Random", StringComparison.OrdinalIgnoreCase) ? "" : blessing,
            VisualArchetype = visual.StartsWith("Random", StringComparison.OrdinalIgnoreCase) ? "" : visual,
            StartingFocus = ComboText(BuilderFocusBox, "Balanced"),
            Traits = traits.Where(t => !t.StartsWith("Random", StringComparison.OrdinalIgnoreCase)).ToList()
        };
    }

    private void BuilderRandomizeButton_Click(object sender, RoutedEventArgs e)
    {
        _lastRandomPreview = BuildRandomPreviewChoice();
        BuilderRandomPreviewText.Text = BuildCustomPreviewText(_lastRandomPreview);
    }

    private void BuilderStartRandomButton_Click(object sender, RoutedEventArgs e)
    {
        CharacterBuilderOverlay.Visibility = Visibility.Collapsed;
        _saveData.Settings.FirstLaunchComplete = true;
        _saveData.Settings.ShowMainMenu = false;
        GenerateNewCharacter(keepName: false, clearLegends: _builderClearLegends, custom: _lastRandomPreview ?? BuildRandomPreviewChoice());
        SaveGame(false);
        Render();
        HintText.Text = $"Started {Player.Name}'s chronicle. Autosave is active.";
    }

    private void BuilderPreviewCustomButton_Click(object sender, RoutedEventArgs e)
    {
        if (!ValidateBuilderFields(showMessage: true)) return;
        BuilderCustomPreviewText.Text = BuildCustomPreviewText(ReadCharacterBuilderChoice());
    }

    private void BuilderCreateButton_Click(object sender, RoutedEventArgs e)
    {
        if (!ValidateBuilderFields(showMessage: true)) return;
        CharacterBuilderOverlay.Visibility = Visibility.Collapsed;
        _saveData.Settings.FirstLaunchComplete = true;
        _saveData.Settings.ShowMainMenu = false;
        var choice = ReadCharacterBuilderChoice();
        GenerateNewCharacter(keepName: false, clearLegends: _builderClearLegends, custom: choice);
        SaveGame(false);
        Render();
        HintText.Text = $"Started {Player.Name}'s chronicle. Autosave is active.";
    }

    private bool ValidateBuilderFields(bool showMessage)
    {
        string ageText = BuilderAgeBox.Text.Trim();
        if (!string.IsNullOrWhiteSpace(ageText) && (!int.TryParse(ageText, out int age) || age < 12 || age > 90))
        {
            if (showMessage)
            {
                System.Windows.MessageBox.Show(
                    "Age must be blank or a number between 12 and 90.",
                    "Character Builder",
                    System.Windows.MessageBoxButton.OK,
                    System.Windows.MessageBoxImage.Information);
            }
            return false;
        }
        return true;
    }

    private void BuilderCloseButton_Click(object sender, RoutedEventArgs e)
    {
        CharacterBuilderOverlay.Visibility = Visibility.Collapsed;
    }

    private List<StoryArc> CreateStartingArcs()
    {
        return new List<StoryArc>
        {
            new() { Name = "The Road Grows Restless", Description = "Bandits, beasts, and bad omens are starting to look connected.", Stage = "Rumor", Progress = _random.Next(0, 10), Threat = 12 },
            new() { Name = "The Black Tower Dream", Description = "The same tower appears in sleep, always closer than before.", Stage = "Rumor", Progress = _random.Next(0, 8), Threat = 15 },
            new() { Name = "The Ashen Plague", Description = "A gray fever moves slowly between ports and poor villages.", Stage = "Dormant", Progress = _random.Next(0, 5), Threat = 8 }
        };
    }

    private List<string> RollTraits()
    {
        string[] allTraits = { "Brave", "Cowardly", "Greedy", "Kindhearted", "Reckless", "Lucky", "Frail", "Charming", "Hardy", "Curious", "Practical", "Haunted", "Patient", "Stubborn" };
        var traits = new List<string>();
        while (traits.Count < 3)
        {
            string trait = Pick(allTraits);
            if (!traits.Contains(trait)) traits.Add(trait);
        }
        if (traits.Contains("Brave") && traits.Contains("Cowardly")) traits.Remove("Cowardly");
        if (traits.Contains("Frail") && traits.Contains("Hardy")) traits.Remove("Frail");
        while (traits.Count < 3)
        {
            string trait = Pick(allTraits);
            if (!traits.Contains(trait)) traits.Add(trait);
        }
        return traits;
    }

    private void ApplyBackgroundAndTraits()
    {
        switch (Player.Background)
        {
            case "Exiled Noble": Player.Gold += 45; Player.Reputation -= 2; Player.AddFaction("Noble House", 14); break;
            case "Village Runaway": Player.Morale += 8; Player.Supplies += 3; Player.AddFaction("Town Guard", -6); break;
            case "Former Temple Apprentice": Player.Potions += 2; Player.ShrineTier += 1; Player.AddFaction("Temple Order", 16); break;
            case "Debt-Ridden Mercenary": Player.WeaponTier += 1; Player.Gold = Math.Max(0, Player.Gold - 18); Player.AddFaction("Monster Hunters", 10); Player.AddFaction("Merchant Guild", -12); break;
            case "Failed Mage Student": Player.Luck += 7; Player.Morale -= 5; Player.LibraryTier += 1; Player.AddFaction("Mage Circle", 10); break;
            case "Orphaned Farmhand": Player.Supplies += 6; Player.Energy += 8; Player.AddFaction("Common Folk", 8); break;
            case "Retired Guard": Player.ArmorTier += 1; Player.AddFaction("Town Guard", 16); break;
            case "Cursed Wanderer": Player.Luck += 12; Player.CurrentHp -= 8; Player.AddFaction("Temple Order", -6); break;
            case "Dockside Errand Runner": Player.Gold += 12; Player.AddFaction("Merchant Guild", 8); break;
            case "Disgraced Squire": Player.ArmorTier += 1; Player.Reputation -= 4; Player.AddFaction("Noble House", -14); break;
            case "Guild Orphan": Player.GuildHallTier += 1; Player.AddFaction("Monster Hunters", 7); break;
            case "Witch's Errand Runner": Player.Luck += 6; Player.AddFaction("Mage Circle", 8); Player.AddFaction("Temple Order", -4); break;
        }

        if (Player.HasTrait("Lucky")) Player.Luck += 12;
        if (Player.HasTrait("Frail")) Player.CurrentHp -= 12;
        if (Player.HasTrait("Hardy")) Player.CurrentHp += 18;
        if (Player.HasTrait("Charming")) Player.Reputation += 4;
        if (Player.HasTrait("Greedy")) Player.Gold += 18;
        if (Player.HasTrait("Kindhearted")) Player.Reputation += 6;
        if (Player.HasTrait("Haunted")) Player.Morale -= 8;
        if (Player.HasTrait("Practical")) Player.Supplies += 3;
        if (Player.HasTrait("Patient")) Player.Morale += 5;
        if (Player.HasTrait("Stubborn")) Player.CurrentHp += 7;
        Player.Clamp();
    }

    private void ApplyLegacyInheritance(List<LegacyEntry> oldLegends)
    {
        if (oldLegends.Count == 0)
            return;

        var mentor = oldLegends.OrderByDescending(l => l.Score).First();
        int inheritance = Math.Clamp(mentor.Score / 250, 2, 45);
        Player.Gold += 10 + inheritance;
        Player.Reputation += Math.Clamp(mentor.Score / 700, 1, 12);
        Player.Supplies += Math.Clamp(mentor.DaysSurvived / 720, 1, 8);
        Player.MemorialGardenTier = Math.Max(Player.MemorialGardenTier, Math.Clamp(oldLegends.Count / 3, 0, 5));
        if (mentor.EndType == "Retirement") Player.GuildHallTier += 1;
        AddTimeline($"Inherited stories from {mentor.Name}, {mentor.Title}.");
        AddJournal($"The previous legend, {mentor.Name} the {mentor.Title}, leaves maps, favors, and a slightly haunted reputation behind. {Player.Name} starts with a small inheritance and a larger shadow.");
    }


    private string ChooseBloodline(List<LegacyEntry> oldLegends)
    {
        if (World.Bloodlines.Count > 0 && Percent(70))
            return World.Bloodlines.OrderByDescending(b => b.Reputation + b.GenerationCount * 4 + b.EstateTier * 8).First().Name;

        if (oldLegends.Count > 0 && Percent(50))
        {
            string seed = oldLegends.OrderByDescending(l => l.Score).First().Name.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "Vale";
            return seed.Replace("the", "").Trim();
        }

        return Pick(new[] { "Vale", "Ashhand", "Moonroot", "Brindle", "Foxglass", "Lantern", "Thorn", "Riverborn", "Mayflower", "Starling" });
    }

    private void EnsureBloodlineForHero()
    {
        var bloodline = World.Bloodlines.FirstOrDefault(b => b.Name == Player.BloodlineName);
        if (bloodline == null)
        {
            bloodline = new Bloodline
            {
                Name = Player.BloodlineName,
                GenerationCount = Player.Generation,
                Reputation = Math.Max(0, Player.Reputation),
                Wealth = SafeInt(Player.Gold),
                EstateLocation = Player.Location,
                EstateTier = Math.Max(Player.HomeTier, Player.GuildHallTier / 2),
                KnownFor = Pick(new[] { "walking away from awful odds", "keeping promises", "hoarding strange maps", "helping towns survive winters", "finding doors nobody ordered" }),
                InheritedTrait = Pick(new[] { "Road Memory", "Winter Nerves", "Kind Hands", "Moon Luck", "Stubborn Blood", "Old Debt", "Quiet Courage" })
            };
            bloodline.FamilyHistory.Add($"Founded by {Player.Name} in Year {CurrentYear()}.");
            World.Bloodlines.Add(bloodline);
        }
        else
        {
            bloodline.GenerationCount = Math.Max(bloodline.GenerationCount, Player.Generation);
            bloodline.FamilyHistory.Add($"{Player.Name} took up the road in Year {CurrentYear()}.");
            while (bloodline.FamilyHistory.Count > 60) bloodline.FamilyHistory.RemoveAt(0);
        }
    }

    private void ApplyOfflineProgress()
    {
        if (!Player.IsAlive || Player.IsRetired)
            return;

        TimeSpan away = DateTime.UtcNow - _saveData.LastSavedUtc;
        int minutesToSimulate = Math.Clamp((int)Math.Floor(away.TotalMinutes), 0, 90 * 24 * 60);
        if (minutesToSimulate <= 0)
            return;

        var before = CaptureOfflineSnapshot();
        int journalStart = _storyLog.Count;

        AddJournal($"While the app was closed, {FormatDuration(minutesToSimulate)} passed. The world continued moving in the background.");
        SimulateStoryMinutes(minutesToSimulate, true);
        AddJournal(Player.IsAlive && !Player.IsRetired ? "Offline time ends with the hero still moving." : "Offline time ends with a completed chapter.");

        var after = CaptureOfflineSnapshot();
        var offlineEntries = _storyLog
            .Skip(Math.Clamp(journalStart, 0, _storyLog.Count))
            .Where(line => !line.Contains("While the app was closed", StringComparison.OrdinalIgnoreCase) && !line.Contains("Offline time ends", StringComparison.OrdinalIgnoreCase))
            .TakeLast(8)
            .ToList();

        string summary = BuildOfflineSummary(minutesToSimulate, before, after, offlineEntries);
        AddJournal("Away summary: " + BuildOfflineJournalSummary(minutesToSimulate, before, after));
        SaveGame(false);

        if (minutesToSimulate >= 5)
        {
            try
            {
                System.Windows.MessageBox.Show(
                    summary,
                    "While You Were Away",
                    System.Windows.MessageBoxButton.OK,
                    System.Windows.MessageBoxImage.Information);
            }
            catch
            {
                // If Windows is not ready to show a dialog during startup, the journal still keeps the summary.
            }
        }
    }

    private OfflineSnapshot CaptureOfflineSnapshot()
    {
        return new OfflineSnapshot
        {
            Location = Player.Location,
            Destination = Player.Destination,
            Activity = Player.ActivityName,
            Level = Player.Level,
            Xp = Player.Xp,
            Gold = Player.Gold,
            Reputation = Player.Reputation,
            CurrentHp = Player.CurrentHp,
            Energy = Player.Energy,
            Hunger = Player.Hunger,
            Morale = Player.Morale,
            Supplies = Player.Supplies,
            Potions = Player.Potions,
            StoryDay = Player.StoryDay,
            QuestsCompleted = Player.QuestsCompleted,
            QuestsFailed = Player.QuestsFailed,
            AdventuresSurvived = Player.AdventuresSurvived,
            RumorsFollowed = Player.RumorsFollowed,
            ArtifactsFound = Player.ArtifactsFound,
            CompanionsMet = Player.CompanionsMet,
            CompanionsLost = Player.CompanionsLost,
            NearDeaths = Player.NearDeaths,
            MapNotes = World.MapNotes.Count,
            KnownPlaces = _locations.Count,
            GeneratedPlaces = World.DiscoveredLocations.Count,
            WorldExpansions = World.WorldExpansionCount,
            IsAlive = Player.IsAlive,
            IsRetired = Player.IsRetired,
            CauseOfEnd = Player.CauseOfEnd,
            FinalTitle = Player.FinalTitle
        };
    }

    private string BuildOfflineSummary(int minutes, OfflineSnapshot before, OfflineSnapshot after, List<string> entries)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"{FormatDuration(minutes)} passed while Mayflower was closed.");
        sb.AppendLine();
        sb.AppendLine(after.IsAlive && !after.IsRetired
            ? $"{Player.Name} is still alive and currently in {after.Location}."
            : $"{Player.Name}'s chapter changed while you were away: {(string.IsNullOrWhiteSpace(after.CauseOfEnd) ? after.FinalTitle : after.CauseOfEnd)}.");

        if (!string.Equals(before.Location, after.Location, StringComparison.OrdinalIgnoreCase))
            sb.AppendLine($"Travel: {before.Location} → {after.Location}");
        else if (!string.IsNullOrWhiteSpace(after.Activity))
            sb.AppendLine($"Current activity: {after.Activity}");

        var changes = new List<string>();
        AddDelta(changes, "Level", before.Level, after.Level);
        AddDelta(changes, "XP", before.Xp, after.Xp);
        AddDelta(changes, "Gold", before.Gold, after.Gold);
        AddDelta(changes, "Reputation", before.Reputation, after.Reputation);
        AddDelta(changes, "HP", before.CurrentHp, after.CurrentHp);
        AddDelta(changes, "Energy", before.Energy, after.Energy);
        AddDelta(changes, "Hunger", before.Hunger, after.Hunger, lowerIsBetter: true);
        AddDelta(changes, "Morale", before.Morale, after.Morale);
        AddDelta(changes, "Supplies", before.Supplies, after.Supplies);
        AddDelta(changes, "Potions", before.Potions, after.Potions);

        if (changes.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Changes:");
            foreach (string line in changes.Take(10)) sb.AppendLine("• " + line);
        }

        var worldChanges = new List<string>();
        AddCountDelta(worldChanges, "quests completed", before.QuestsCompleted, after.QuestsCompleted);
        AddCountDelta(worldChanges, "quests failed", before.QuestsFailed, after.QuestsFailed);
        AddCountDelta(worldChanges, "adventures survived", before.AdventuresSurvived, after.AdventuresSurvived);
        AddCountDelta(worldChanges, "rumors followed", before.RumorsFollowed, after.RumorsFollowed);
        AddCountDelta(worldChanges, "artifacts found", before.ArtifactsFound, after.ArtifactsFound);
        AddCountDelta(worldChanges, "companions met", before.CompanionsMet, after.CompanionsMet);
        AddCountDelta(worldChanges, "companions lost", before.CompanionsLost, after.CompanionsLost);
        AddCountDelta(worldChanges, "near-deaths", before.NearDeaths, after.NearDeaths);
        AddCountDelta(worldChanges, "new map notes", before.MapNotes, after.MapNotes);
        AddCountDelta(worldChanges, "new known places", before.KnownPlaces, after.KnownPlaces);
        AddCountDelta(worldChanges, "world expansions", before.WorldExpansions, after.WorldExpansions);

        if (worldChanges.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("World movement:");
            foreach (string line in worldChanges.Take(10)) sb.AppendLine("• " + line);
        }

        if (entries.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Recent chronicle notes:");
            foreach (string entry in entries)
                sb.AppendLine("• " + StripJournalStamp(entry));
        }

        sb.AppendLine();
        sb.AppendLine("The full record was added to the Journal.");
        return sb.ToString();
    }

    private string BuildOfflineJournalSummary(int minutes, OfflineSnapshot before, OfflineSnapshot after)
    {
        var parts = new List<string> { FormatDuration(minutes) + " passed" };
        if (!string.Equals(before.Location, after.Location, StringComparison.OrdinalIgnoreCase)) parts.Add($"traveled from {before.Location} to {after.Location}");
        if (after.Level != before.Level) parts.Add($"level {before.Level} to {after.Level}");
        if (after.Gold != before.Gold) parts.Add($"gold {Signed(after.Gold - before.Gold)}");
        if (after.WorldExpansions > before.WorldExpansions) parts.Add($"world expansions +{after.WorldExpansions - before.WorldExpansions}");
        if (!after.IsAlive || after.IsRetired) parts.Add("the chapter changed");
        return string.Join("; ", parts) + ".";
    }

    private static void AddDelta(List<string> lines, string label, long before, long after, bool lowerIsBetter = false)
    {
        long delta = after - before;
        if (delta == 0) return;
        string direction = delta > 0 ? "+" : "";
        string note = lowerIsBetter && delta < 0 ? " improved" : lowerIsBetter && delta > 0 ? " worsened" : "";
        lines.Add($"{label}: {before} → {after} ({direction}{delta}{note})");
    }

    private static void AddCountDelta(List<string> lines, string label, int before, int after)
    {
        int delta = after - before;
        if (delta <= 0) return;
        lines.Add($"{label}: +{delta}");
    }

    private static string Signed(long value) => value > 0 ? "+" + value : value.ToString();

    private static string StripJournalStamp(string entry)
    {
        int end = entry.IndexOf("] ", StringComparison.Ordinal);
        return end >= 0 && end + 2 < entry.Length ? entry[(end + 2)..] : entry;
    }

    private void SimulateStoryMinutes(int minutes, bool offline)
    {
        int remaining = Math.Max(0, minutes);
        while (remaining > 0 && Player.IsAlive && !Player.IsRetired)
        {
            if (Player.ActivityMinutesRemaining <= 0)
                StartNextActivity(offline);

            int slice = Math.Min(remaining, Math.Max(1, Player.ActivityMinutesRemaining));
            for (int i = 0; i < slice && Player.IsAlive && !Player.IsRetired; i++)
                SimulateOneMinute(offline);

            Player.ActivityMinutesRemaining -= slice;
            if (Player.ActivityMinutesRemaining <= 0 && Player.IsAlive && !Player.IsRetired)
                FinishCurrentActivity(offline);

            LevelUpIfNeeded();
            Player.Clamp();
            remaining -= slice;
        }
    }

    private void SimulateOneMinute(bool offline)
    {
        AdvanceClockOneMinute();
        ApplyMinuteNeeds();
        if (Player.StoryMinute == 0)
        {
            Player.TotalEvents++;
            HourlyNeedsAndRisk(offline);
            AutoUseEmergencyItems();
            CheckDeath("the slow math of hunger, exhaustion, blood loss, and bad luck finally balanced the ledger");
        }
    }

    private void AdvanceClockOneMinute()
    {
        Player.StoryMinute++;
        if (Player.StoryMinute < 60) return;
        Player.StoryMinute = 0;
        Player.StoryHour++;
        if (Player.StoryHour < 24) return;
        Player.StoryHour = 0;
        Player.StoryDay++;
        Player.SeasonDay++;

        if (Player.SeasonDay > 90)
        {
            Player.SeasonDay = 1;
            int seasonIndex = Array.IndexOf(_seasons, Player.Season);
            if (seasonIndex < 0) seasonIndex = 0;
            Player.Season = _seasons[(seasonIndex + 1) % _seasons.Length];
            AddJournal($"The season turns to {Player.Season.ToLowerInvariant()}. Prices, weather, roads, and moods all shift a little.");
        }

        RollWeather();
        UpdateWorldDaily();
        ApplyDirectorDailyPacing();
        AgeDailySystems();
        MaybeMemoryCallback();
        UpdateStatsAndAchievements();
        if (DayOfYear() == 1 && Player.StoryDay > 1)
            ApplyYearlyRoutine();
        MaybeRetire();

        if (Player.IsAlive && !Player.IsRetired)
        {
            AddJournal(Pick(new[]
            {
                $"Dawn finds {Player.Name} in {Player.Location}. The day looks survivable, which is suspicious.",
                $"Day {Player.StoryDay} arrives under {Player.Weather.ToLowerInvariant()} skies. Somewhere nearby, trouble is probably stretching.",
                $"Morning comes. {Player.Name} checks the pack, the wounds, and the insulting persistence of the road.",
                $"A new day in {Player.Season.ToLowerInvariant()} begins. The chronicle clears its throat."
            }));
        }
    }

    private void RollWeather()
    {
        string[] spring = { "Mild", "Rain", "Fog", "Wind", "Bright", "Rain", "Mild" };
        string[] summer = { "Bright", "Heatwave", "Mild", "Storm", "Dry Wind", "Muggy", "Bright" };
        string[] autumn = { "Mild", "Rain", "Fog", "Cold Wind", "Storm", "Gray", "Mild" };
        string[] winter = { "Cold", "Snow", "Sleet", "Clear Frost", "Wind", "Cold", "Snow" };
        Player.Weather = Player.Season switch
        {
            "Spring" => Pick(spring),
            "Summer" => Pick(summer),
            "Autumn" => Pick(autumn),
            "Winter" => Pick(winter),
            _ => "Mild"
        };
    }

    private void UpdateWorldDaily()
    {
        int drift = _random.Next(-1, 2);
        World.BanditPower += Percent(8) ? 1 : 0;
        World.MonsterPressure += Percent(10) ? 1 : 0;
        World.RoadSafety += drift;
        World.FoodSupply += Player.Season switch { "Spring" => 1, "Summer" => 1, "Autumn" => 2, "Winter" => -1, _ => 0 };
        World.TownWealth += World.Economy > 55 ? 1 : 0;
        World.TownWealth -= World.BanditPower > 65 ? 1 : 0;
        World.Plague += World.FoodSupply < 25 && Percent(12) ? 1 : 0;
        World.WarTension += World.BanditPower > 70 && Percent(7) ? 1 : 0;
        World.MagicInstability += Player.StoryArcs.Any(a => !a.IsResolved && a.Name.Contains("Black Tower")) && Percent(4) ? 1 : 0;

        if (Percent(3)) World.Economy += _random.Next(-2, 3);
        if (Player.GuildHallTier > 0 && Percent(10)) World.RoadSafety += 1;
        if (Player.InfirmaryTier > 0 && Percent(6)) World.Plague -= 1;
        World.Clamp();

        if (Player.StoryDay % 30 == 0)
        {
            ApplyDifficultyDrift();
            MaybeWorldEvent();
        }
    }

    private void MaybeWorldEvent()
    {
        int roll = _random.Next(100);
        if (roll < 18 && World.BanditPower > 45)
        {
            World.RoadSafety -= 6;
            World.TownWealth -= 3;
            World.LastMajorEvent = "Bandit clans hit the roads hard this month.";
        }
        else if (roll < 32 && World.FoodSupply < 38)
        {
            World.Plague += 4;
            World.Economy -= 3;
            World.LastMajorEvent = "Poor harvests make every market sharper and every cough more worrying.";
        }
        else if (roll < 48 && World.TownWealth > 60)
        {
            World.RoadSafety += 3;
            World.Economy += 2;
            World.LastMajorEvent = "A good trade month brings full wagons and smug merchants.";
        }
        else if (roll < 58 && World.MagicInstability > 35)
        {
            World.MonsterPressure += 4;
            World.LastMajorEvent = "Strange lights crawl across the night sky. Mages pretend this is fine.";
        }
        else
        {
            World.LastMajorEvent = "The world changes quietly this month: prices twitch, rumors age, and roads remember footsteps.";
        }
        World.Clamp();
        AddJournal($"World event: {World.LastMajorEvent}");
    }

    private void AgeDailySystems()
    {
        foreach (var injury in Player.Injuries.Where(i => !i.IsPermanent && i.DaysRemaining > 0)) injury.DaysRemaining--;
        int healed = Player.Injuries.RemoveAll(i => !i.IsPermanent && i.DaysRemaining <= 0);
        if (healed > 0) AddJournal("An old injury finally stops hurting every time the story uses punctuation.");

        foreach (var companion in Player.Companions.Where(c => c.IsActive).ToList())
        {
            companion.DaysTogether++;
            int change = 0;
            if (Player.Morale > 70) change += 1;
            if (Player.Hunger > 72) change -= 1;
            if (Player.HasTrait("Charming")) change += 1;
            if (Player.LifePhilosophy == "Trust Companions") change += 1;
            companion.Loyalty = Math.Clamp(companion.Loyalty + change, 0, 100);
            if (Percent(9 + (Player.LifePhilosophy == "Trust Companions" ? 6 : 0))) companion.Bond = Math.Clamp(companion.Bond + 1, 0, 100);

            if (companion.Loyalty <= 5 && Percent(14))
            {
                companion.IsActive = false;
                Player.CompanionsLost++;
                AddTimeline($"{companion.Name} left the party.");
                AddMemoryTag("companion lost: " + companion.Name);
                AddCauseThread($"{companion.Name} left after loyalty failed on the road.");
                AddJournal($"{companion.Name} leaves before sunrise. No speech. No grand betrayal. Just footprints going the other way.");
            }
            else if (companion.Bond >= 85 && Percent(2))
            {
                AddJournal($"{companion.Name} quietly carries the heavier pack today. Nobody makes a speech about it. That is why it matters.");
            }
        }

        foreach (var rumor in Player.Rumors.Where(r => !r.IsResolved)) rumor.DaysOld++;
        Player.Rumors.RemoveAll(r => r.IsResolved || r.DaysOld > 18);

        foreach (var arc in Player.StoryArcs.Where(a => !a.IsResolved).ToList())
            AgeArc(arc);

        if (Percent(16)) MaybeCreateRumor("daily gossip");
        if (Percent(LegendaryEventChance())) MaybeLegendaryEvent();
        AgeLivingWorldDaily();
    }


    private void AgeLivingWorldDaily()
    {
        AgeHeroBodyAndMind();
        AgeTowns();
        AgeRivals();
        AgeNemeses();
        AgeArtifacts();
        AgePetsAndHome();
        AgeFaithAndResearch();
        MaybeFestival();
        MaybeDreamOmen();
        MaybeDisease();
        MaybeGenerateBulletin();
        MaybeTriggerCustomModEvent();
        if (Percent(2)) MaybeMysteryBoxEvent();
    }

    private void AgeHeroBodyAndMind()
    {
        Player.AgeDays++;
        if (Player.AgeDays >= 360)
        {
            Player.AgeDays = 0;
            if (!Player.IsImmortal) Player.AgeYears++;
            AddTimeline($"Turned {Player.AgeYears}.");
            AddWorldHistory("Life", $"{Player.Name} reached age {Player.AgeYears} while the world kept asking for favors.");
            if (!Player.IsImmortal && Player.AgeYears >= 55 && Percent(12)) Player.Energy -= 1;
            if (!Player.IsImmortal && Player.AgeYears >= 70 && Percent(10)) MaybeRetireFromAge();
        }

        AgeChildDaily();

        foreach (var disease in Player.Diseases.Where(d => d.IsActive).ToList())
        {
            if (!disease.IsCurse) disease.DaysRemaining--;
            if (disease.Severity > 0 && Percent(Math.Max(1, disease.Severity / 6))) Player.CurrentHp -= 1;
            if (Player.Faith.Blessing == "Gentle Mercy" && Percent(16)) disease.Severity -= 1;
            if (Player.Research.Field == "Healing Magic" && Player.Research.Breakthroughs > 0 && Percent(10)) disease.Severity -= 1;
        }
        int cured = Player.Diseases.RemoveAll(d => !d.IsActive || d.Severity <= 0);
        if (cured > 0) AddJournal("An illness finally breaks. The body keeps score, but sometimes it also forgives.");

        foreach (var scar in Player.EmotionalScars.Where(e => e.IsActive).ToList())
        {
            scar.DaysRemaining--;
            if (scar.IsPositive) Player.Morale += Percent(8) ? 1 : 0;
            else if (Percent(Math.Max(1, scar.Intensity / 12))) Player.Morale -= 1;
        }
        Player.EmotionalScars.RemoveAll(e => !e.IsActive);
    }

    private void MaybeRetireFromAge()
    {
        if (Player.IsRetired || !Player.IsAlive) return;
        int chance = Math.Clamp((Player.AgeYears - 68) + Player.HomeTier * 2 + Player.FamilyMembers * 2 + Player.GuildHallTier, 0, 35);
        if (Percent(chance)) EndLife("Retirement", $"at age {Player.AgeYears}, {Player.Name} chooses a warm chair, a locked door, and the luxury of letting someone else be reckless");
    }

    private void AgeChildDaily()
    {
        if (!Player.HasChild) return;
        Player.ChildAgeDays++;
        if (Player.ChildAgeDays < 360) return;

        Player.ChildAgeDays = 0;
        Player.ChildAgeYears++;
        if (Player.ChildAgeYears == 5 || Player.ChildAgeYears == 10 || Player.ChildAgeYears == 16)
        {
            Player.FamilyMilestones++;
            AddTimeline($"Child milestone: {Player.ChildName} turned {Player.ChildAgeYears}.");
            AddJournal($"Family milestone: {Player.ChildName} turns {Player.ChildAgeYears}. The house keeps a candle for them, and the chronicle learns their name a little louder.");
        }

        if (Player.ChildAgeYears >= 16 && string.IsNullOrWhiteSpace(Player.HeirName))
        {
            Player.HeirName = Player.ChildName;
            Player.ChildStatus = "old enough to inherit the road if the worst happens";
            AddJournal($"Heir named: {Player.ChildName} is old enough to carry House {Player.BloodlineName} forward if {Player.Name}'s chapter ends badly.");
        }
    }

    private void MaybeChildMilestone()
    {
        if (Player.HasChild || Player.HomeTier <= 0 || Player.AgeYears < 18) return;
        int chance = 3 + Player.HomeTier + Player.FamilyMembers * 4 + (Player.LifePhilosophy == "Seek Balance" ? 2 : 0) + (Player.Morale > 70 ? 2 : 0);
        if (Player.FamilyMembers == 0 && !Percent(25)) return;
        if (!Percent(chance)) return;

        bool adopted = Percent(Player.FamilyStatus.Contains("adopt", StringComparison.OrdinalIgnoreCase) ? 60 : 35);
        Player.HasChild = true;
        Player.ChildName = RollChildName();
        Player.ChildIsAdopted = adopted;
        Player.ChildAgeYears = adopted ? _random.Next(2, 10) : 0;
        Player.ChildAgeDays = adopted ? _random.Next(0, 360) : 0;
        Player.ChildStatus = adopted
            ? "learning the house rules and deciding which ones are nonsense"
            : "small, loud, beloved, and very bad at understanding danger";
        Player.HeirName = Player.ChildName;
        Player.FamilyMembers = Math.Max(Player.FamilyMembers + 1, 1);
        Player.FamilyMilestones++;
        Player.FamilyStatus = adopted
            ? $"family with {Player.ChildName}, an adopted child of House {Player.BloodlineName}"
            : $"family with {Player.ChildName}, child of House {Player.BloodlineName}";

        AddTimeline(adopted ? $"Adopted child: {Player.ChildName}." : $"Child born: {Player.ChildName}.");
        AddWorldHistory("Family", adopted
            ? $"{Player.Name} adopted {Player.ChildName} into House {Player.BloodlineName}."
            : $"{Player.ChildName} was born into House {Player.BloodlineName}.");
        AddJournal(adopted
            ? $"Family milestone: {Player.Name} adopts {Player.ChildName}. The ledger writes them as child and heir, which is much heavier than ink should be."
            : $"Family milestone: {Player.ChildName} is born. The house gets smaller, louder, and suddenly more important than any dungeon.");
        AddMemoryTag("child heir: " + Player.ChildName);
        UpdateBloodlineFromHero();
    }

    private string RollChildName()
    {
        return Pick(new[]
        {
            "Mira", "Tovin", "Sera", "Nell", "Hale", "Juniper", "Aster", "Liora", "Briar",
            "Elowen", "Pip", "Rowan", "Marin", "Talia", "Cass", "Iris", "Wren", "Niko"
        });
    }

    private bool ContinueAsChildAfterDeath(string cause)
    {
        if (!Player.HasChild || string.IsNullOrWhiteSpace(Player.ChildName)) return false;

        string parentName = Player.Name;
        string parentTitle = Player.FinalTitle;
        string childName = Player.ChildName;
        int childAge = Math.Max(16, Player.ChildAgeYears);
        int yearsWaited = Math.Max(0, 16 - Player.ChildAgeYears);
        string bloodlineName = Player.BloodlineName;
        string difficulty = Player.Difficulty;
        string lifeRule = Player.LifePhilosophy;
        string parentBackground = Player.Background;
        bool adopted = Player.ChildIsAdopted;
        int inheritedGold = SafeInt(Math.Min(Player.Gold, 500));
        int inheritedHomeTier = Player.HomeTier;
        int inheritedHomeComfort = Player.HomeComfort;
        int inheritedGardenTier = Player.GardenTier;
        int inheritedGuildHall = Player.GuildHallTier;
        int inheritedReputation = Math.Max(0, Player.Reputation / 2);
        string inheritedHomeName = Player.HomeName;
        var inheritedTraits = BuildInheritedChildTraits(Player.Traits);

        var heir = new CharacterBuildChoice
        {
            Name = childName,
            AgeYears = childAge,
            OriginSeed = adopted ? "Adopted Heir" : "Family Heir",
            Background = MakeHeirBackground(parentBackground, adopted),
            Difficulty = difficulty,
            LifePhilosophy = lifeRule,
            BloodlineName = bloodlineName,
            StartingBurden = $"Parent's death: {cause}",
            StartingBlessing = "Inherited household",
            VisualArchetype = Pick(new[] { "Lantern heir", "Roadwise youth", "Quiet house scion", "Moonlit successor", "Second-generation wanderer" }),
            StartingFocus = inheritedHomeTier > 0 ? "Homestead" : "Survivor",
            Traits = inheritedTraits
        };

        GenerateNewCharacter(keepName: false, clearLegends: false, custom: heir);

        Player.FamilyStatus = adopted
            ? $"adopted child of {parentName}, carrying House {bloodlineName} forward"
            : $"child of {parentName}, carrying House {bloodlineName} forward";
        Player.Gold += inheritedGold / 2;
        Player.Reputation += inheritedReputation;
        Player.HomeTier = Math.Max(Player.HomeTier, Math.Max(0, inheritedHomeTier - 1));
        Player.HomeComfort = Math.Max(Player.HomeComfort, Math.Max(0, inheritedHomeComfort - 12));
        Player.GardenTier = Math.Max(Player.GardenTier, Math.Max(0, inheritedGardenTier - 1));
        Player.GuildHallTier = Math.Max(Player.GuildHallTier, inheritedGuildHall / 2);
        if (inheritedHomeTier > 0) Player.HomeName = inheritedHomeName;
        Player.HeirName = string.Empty;
        Player.HasChild = false;
        Player.ChildStatus = "No child yet";
        Player.Clamp();

        if (yearsWaited > 0)
            AddJournal($"Inheritance: {yearsWaited} quiet year{(yearsWaited == 1 ? "" : "s")} pass before {childName} is old enough to choose the road. The world does not pause; it only lowers its voice.");
        AddJournal($"Legacy continues: {childName}, {Player.FamilyStatus}, inherits the chronicle after {parentName} the {parentTitle} dies. The next page smells like old ink and unfinished promises.");
        AddTimeline($"Inherited chronicle from {parentName}.");
        AddWorldHistory("Inheritance", $"{childName} continued House {bloodlineName} after {parentName}'s death.");
        AddMapNote(Player.Location, "✦", $"{childName} inherited the chronicle from {parentName}.", 0);

        var bloodline = World.Bloodlines.FirstOrDefault(b => b.Name == bloodlineName);
        if (bloodline != null)
        {
            bloodline.GenerationCount = Math.Max(bloodline.GenerationCount, Player.Generation);
            bloodline.FamilyHistory.Add($"{childName}, child of {parentName}, inherited the chronicle after {parentName}'s death.");
            while (bloodline.FamilyHistory.Count > 60) bloodline.FamilyHistory.RemoveAt(0);
        }

        return true;
    }

    private string MakeHeirBackground(string parentBackground, bool adopted)
    {
        if (adopted) return Pick(new[] { "Adopted House Heir", "Foundling Successor", "Hearth-Raised Wanderer" });
        return parentBackground switch
        {
            "Exiled Noble" => "Restored House Heir",
            "Former Temple Apprentice" => "Temple-Raised Heir",
            "Retired Guard" => "Guard's Child",
            "Cursed Wanderer" => "Curse-Blood Heir",
            "Dockside Errand Runner" => "Port-Born Heir",
            "Witch's Errand Runner" => "Forest-Taught Heir",
            _ => Pick(new[] { "Second-Generation Wanderer", "House Heir", "Roadborn Child", "Lantern-House Heir" })
        };
    }

    private List<string> BuildInheritedChildTraits(List<string> parentTraits)
    {
        var traits = new List<string>();
        var inheritable = parentTraits.Where(t => !string.IsNullOrWhiteSpace(t)).OrderBy(_ => _random.Next()).ToList();
        if (inheritable.Count > 0) traits.Add(inheritable[0]);
        if (Player.BloodlineName.Contains("Lantern", StringComparison.OrdinalIgnoreCase) && !traits.Contains("Kindhearted")) traits.Add("Kindhearted");
        while (traits.Count < 3)
        {
            string trait = Pick(new[] { "Brave", "Kindhearted", "Lucky", "Charming", "Hardy", "Curious", "Practical", "Haunted", "Patient", "Stubborn" });
            if (!traits.Contains(trait)) traits.Add(trait);
        }
        return traits.Take(3).ToList();
    }

    private void AgeTowns()
    {
        foreach (var town in World.Towns)
        {
            if (town.IsDestroyed)
            {
                if (Percent(1 + Player.MemorialGardenTier))
                {
                    town.IsDestroyed = false;
                    town.Population = _random.Next(80, 240);
                    town.Morale = 25;
                    town.LocalHistory.Add($"Rebuilding began in Year {CurrentYear()} after years of ruin.");
                    AddWorldHistory("Town", $"{town.Name} begins rebuilding from ruin.");
                }
                continue;
            }

            town.Food += Player.Season switch { "Spring" => 1, "Summer" => 1, "Autumn" => 2, "Winter" => -2, _ => 0 };
            town.Safety += World.RoadSafety > 55 ? 1 : -1;
            town.Safety -= World.BanditPower > 60 ? 1 : 0;
            town.Medicine -= World.Plague > 60 ? 1 : 0;
            town.Wealth += World.Economy > 55 ? 1 : 0;
            town.Wealth -= World.WarTension > 65 ? 1 : 0;
            town.Morale += town.Food > 55 ? 1 : -1;
            town.Population += Math.Clamp((town.Food + town.Safety + town.Morale - 150) / 18, -6, 10);
            if (Player.Location == town.Name && Player.Reputation > 20 && Percent(4)) town.Morale += 1;
            if (Player.GuildHallTier > 0 && town.Name == "Brindlewick") { town.Safety += Player.GuildHallTier / 2; town.Medicine += Player.InfirmaryTier / 2; }
            if (town.Safety <= 3 && World.BanditPower > 85 && Percent(4)) DestroyTown(town, "raiders and fear emptied the streets");
            if (World.Plague > 88 && town.Medicine <= 5 && Percent(3)) DestroyTown(town, "plague bells rang too long and too often");
            town.Clamp();
        }
    }

    private void DestroyTown(TownRecord town, string reason)
    {
        town.IsDestroyed = true;
        town.IsHaunted = Percent(40);
        town.Population = Math.Max(0, town.Population / 10);
        town.LocalHistory.Add($"Ruined in Year {CurrentYear()}: {reason}.");
        AddWorldHistory("Town", $"{town.Name} becomes a ruin: {reason}.");
        AddMemoryTag("town ruined: " + town.Name);
        AddCauseThread($"{town.Name} fell into ruin because {reason}.");
        AddJournal($"News travels badly: {town.Name} has fallen into ruin. {reason}.");
    }

    private void AgeRivals()
    {
        foreach (var rival in World.Rivals.Where(r => r.IsAlive && !r.IsRetired).ToList())
        {
            if (Percent(20)) rival.Location = Pick(_locations.Select(l => l.Name).ToList());
            if (Percent(18)) { rival.Fame += _random.Next(-1, 5); rival.Level += Percent(12) ? 1 : 0; }
            if (Percent(3 + World.MonsterPressure / 30))
            {
                int danger = (GetLocation(rival.Location)?.Danger ?? 12) + World.MonsterPressure / 4;
                if (_random.Next(100) + rival.Level * 6 + rival.Luck < danger)
                {
                    rival.IsAlive = false;
                    rival.History.Add($"Died near {rival.Location} in Year {CurrentYear()}.");
                    AddWorldHistory("Rival", $"{rival.Name}, rival adventurer, died near {rival.Location}.");
                }
            }
            if (Percent(2) && rival.Fame > 80) { rival.IsRetired = true; rival.CurrentGoal = "retired into fame"; AddWorldHistory("Rival", $"{rival.Name} retired as a famous {rival.Role.ToLowerInvariant()}."); }
        }

        if (World.Rivals.Count(r => r.IsAlive && !r.IsRetired) < 4 && Percent(3))
        {
            var rival = new RivalAdventurer
            {
                Name = Pick(new[] { "Maris", "Orrin", "Calyx", "Vey", "Sable", "Nessa", "Rowe", "Tamsin" }) + " " + Pick(new[] { "Fox", "Grey", "Vale", "Quill", "Ash", "Dawn" }),
                Role = Pick(new[] { "Treasure Hunter", "Monster Hunter", "Temple Runner", "Caravan Guard", "Mage Apprentice", "Relic Seeker" }),
                Level = _random.Next(1, Math.Max(2, Player.Level + 2)),
                Fame = _random.Next(0, 15),
                Location = Pick(_locations.Select(l => l.Name).ToList()),
                CurrentGoal = "making a name before the road notices"
            };
            World.Rivals.Add(rival);
            AddWorldHistory("Rival", $"{rival.Name}, a new {rival.Role.ToLowerInvariant()}, entered the roads.");
        }
    }

    private void AgeNemeses()
    {
        foreach (var nemesis in World.Nemeses.Where(n => n.IsActive && !n.IsDefeated))
        {
            nemesis.Threat += Percent(35) ? 1 : 0;
            nemesis.Grudge += Player.Reputation > 30 && Percent(8) ? 1 : 0;
            if (Percent(10)) nemesis.LastSeen = Pick(_locations.Select(l => l.Name).ToList());
            if (nemesis.Threat > 90 && Percent(3))
            {
                World.BanditPower += 3;
                World.RoadSafety -= 3;
                AddWorldHistory("Nemesis", $"{nemesis.Name} tightened their grip near {nemesis.LastSeen}.");
            }
        }

        if (World.Nemeses.Count(n => n.IsActive && !n.IsDefeated) < 3 && Percent(1))
        {
            var n = new Nemesis
            {
                Name = Pick(new[] { "The Hollow Baron", "Sister Knife", "Old Grin", "The Wolf King", "Marrow Bell", "Ash-Eyed Lark" }),
                Kind = Pick(new[] { "Corrupt Noble", "Cursed Wolf", "Debt Collector", "Lich", "Bandit Saint", "Rival Captain" }),
                Threat = _random.Next(18, 42),
                Grudge = _random.Next(4, 18),
                LastSeen = Pick(_locations.Select(l => l.Name).ToList()),
                Signature = Pick(new[] { "sends letters sealed with black wax", "never attacks under sunlight", "leaves flowers on empty roads", "knows names they should not know" })
            };
            World.Nemeses.Add(n);
            AddWorldHistory("Nemesis", $"{n.Name}, {n.Kind.ToLowerInvariant()}, became a name people lower their voices around.");
        }
    }

    private void AgeArtifacts()
    {
        foreach (var artifact in World.WorldArtifacts.Concat(Player.Artifacts)) artifact.AgeYears = Math.Max(0, artifact.AgeYears + (DayOfYear() == 1 ? 1 : 0));
        if (Percent(2) && Player.Artifacts.Count(a => !a.IsLost) > 0)
        {
            var art = Player.Artifacts.Where(a => !a.IsLost).OrderBy(_ => _random.Next()).First();
            art.PowerLevel = Math.Clamp(art.PowerLevel + 1, 1, 20);
            art.History.Add($"Grew stronger with {Player.Name} in Year {CurrentYear()}.");
        }
    }

    private void AgePetsAndHome()
    {
        foreach (var pet in Player.PetsMounts.Where(p => p.IsAlive))
        {
            if (Percent(12)) pet.Bond += 1;
            if (Percent(1) && pet.Bond < 20 && Player.Hunger > 85)
            {
                pet.IsAlive = false;
                AddJournal($"{pet.Name} disappears during a miserable day. The journal refuses to make it cute.");
                AddTimeline($"Lost pet: {pet.Name}.");
            }
        }

        if (Player.HomeTier > 0 && (Player.Location is "Brindlewick" or "Riverglass Port"))
        {
            if (Percent(10)) Player.Morale += 1;
            if (Percent(6)) Player.HomeComfort = Math.Min(100, Player.HomeComfort + 1);
            if (Player.FamilyMembers > 0 && !Player.HasChild && CurrentYear() >= 3 && Percent(1)) MaybeChildMilestone();
        }
    }

    private void AgeFaithAndResearch()
    {
        if (Player.Faith.BlessingDaysRemaining > 0)
        {
            Player.Faith.BlessingDaysRemaining--;
            if (Player.Faith.BlessingDaysRemaining <= 0) Player.Faith.Blessing = "None";
        }
        if (Player.Faith.Favor > 40 && Player.Faith.Blessing == "None" && Percent(3)) GrantBlessing();

        if (Player.Research.Progress >= 100)
        {
            Player.Research.Progress = 0;
            Player.Research.Breakthroughs++;
            Player.ResearchBreakthroughs++;
            Player.Xp += 75 + Player.Research.Breakthroughs * 25;
            AddTimeline($"Research breakthrough: {Player.Research.Field}.");
            AddWorldHistory("Research", $"{Player.Name} made a breakthrough in {Player.Research.Field}.");
            AddJournal($"Research breakthrough: {Player.Research.Field}. It is either genius or a beautifully organized mistake. XP rises.");
            if (Player.Research.Field == "Forbidden Necromancy" && Percent(25)) World.MagicInstability += 4;
        }
    }

    private void MaybeFestival()
    {
        int day = DayOfYear();
        string? festival = day switch
        {
            15 => "Lantern Night",
            96 => "Moonflower Bloom",
            188 => "Founder\'s Day",
            270 => "Harvest Week",
            315 => "Hero Remembrance Day",
            348 => "First Snow Feast",
            _ => null
        };
        if (festival == null || !CurrentLocation().Kind.Equals("Town", StringComparison.OrdinalIgnoreCase)) return;
        if (!Percent(60)) return;
        Player.FestivalsAttended++;
        Player.Morale += 8;
        Player.Hunger = Math.Max(0, Player.Hunger - 8);
        Player.Faith.Favor += festival.Contains("Hero") ? 3 : 1;
        AddJournal($"Festival: {festival}. {Player.Name} gets food, noise, candles, and a brief reminder that the world is not only teeth.");
        AddTimeline($"Attended {festival}.");
    }

    private void MaybeDreamOmen()
    {
        int chance = Player.HasTrait("Haunted") ? 8 : 3;
        chance += Player.Artifacts.Any(a => a.Name.Contains("Foxglass") && !a.IsLost) ? 5 : 0;
        if (!Percent(chance)) return;
        var dream = new DreamOmen
        {
            Symbol = Pick(new[] { "Black Tower", "Silver Wolf", "Burning Crown", "Crying Statue", "Ocean Under The Forest", "Door With No Handle", "Lantern Full Of Moths" }),
            Strength = _random.Next(1, 8) + Player.Dreams.Count / 3,
            Meaning = Pick(new[] { "a warning", "a promise", "a threat wearing pretty shoes", "probably about an arc that has not started yet", "a map folded into sleep" })
        };
        Player.Dreams.Add(dream);
        Player.DreamsSeen++;
        if (Player.Dreams.Count > 20) Player.Dreams.RemoveAt(0);
        AddJournal($"Dream omen: {dream.Symbol}. It feels like {dream.Meaning}.");
        if (dream.Symbol == "Black Tower")
        {
            var arc = Player.StoryArcs.FirstOrDefault(a => a.Name.Contains("Black Tower") && !a.IsResolved);
            if (arc != null) arc.Progress += 2;
        }
    }

    private void MaybeDisease()
    {
        int chance = World.Plague / 18 + (Player.Weather is "Snow" or "Sleet" or "Cold" ? 1 : 0) + (Player.Hunger > 80 ? 2 : 0);
        if (!Percent(chance) || Player.Diseases.Count(d => d.IsActive) >= 3) return;
        var disease = new DiseaseCondition
        {
            Name = Pick(new[] { "Winter fever", "Swamp lung", "Mageburn", "Curse sickness", "Gray cough", "Road chills" }),
            Severity = _random.Next(8, 28) + World.Plague / 8,
            DaysRemaining = _random.Next(4, 18),
            IsCurse = Percent(Math.Max(0, World.MagicInstability / 18)),
            Description = Pick(new[] { "A fever that makes every blanket feel too thin.", "A cough with bad timing.", "Magic leaves fingerprints under the skin.", "A weakness that turns stairs into enemies." })
        };
        Player.Diseases.Add(disease);
        AddJournal($"Illness: {disease.Name}. {disease.Description}");
        AddTimeline($"Illness: {disease.Name}.");
    }

    private void MaybeGenerateBulletin()
    {
        if (Player.StoryDay % 14 != 0 || !CurrentLocation().Kind.Equals("Town", StringComparison.OrdinalIgnoreCase)) return;
        var issue = new BulletinIssue
        {
            Year = CurrentYear(),
            Day = DayOfYear(),
            Title = CurrentLocation().Name == "Riverglass Port" ? "The Riverglass Ledger" : "The Brindlewick Bell"
        };
        issue.Lines.Add(World.LastMajorEvent);
        issue.Lines.Add($"Road safety sits at {World.RoadSafety}/100 while bandit power is {World.BanditPower}/100.");
        var rival = World.Rivals.Where(r => r.IsAlive).OrderByDescending(r => r.Fame).FirstOrDefault();
        if (rival != null) issue.Lines.Add($"{rival.Name} was seen in {rival.Location}, {rival.CurrentGoal}.");
        var town = World.Towns.FirstOrDefault(t => t.Name == Player.Location);
        if (town != null) issue.Lines.Add($"{town.Name} reports food {town.Food}/100 and morale {town.Morale}/100.");
        if (Player.Reputation > 30) issue.Lines.Add($"Local hero {Player.Name} was seen alive, which remains newsworthy.");
        World.Bulletins.Add(issue);
        while (World.Bulletins.Count > 240) World.Bulletins.RemoveAt(0);
        AddJournal(issue.Summary);
    }

    private void MaybeTriggerCustomModEvent()
    {
        if (_customEvents.Count == 0 || !Percent(2)) return;
        var pool = _customEvents.Where(e => e.MinimumYear <= CurrentYear() && (e.Location == "Any" || e.Location == Player.Location)).ToList();
        if (pool.Count == 0) return;
        var e = pool.OrderBy(_ => _random.Next()).First();
        int chance = e.Rarity switch { "Common" => 35, "Uncommon" => 16, "Rare" => 7, "Epic" => 3, "Legendary" => 1, _ => 7 };
        if (!Percent(chance)) return;
        ApplyModEffect(e.Effect);
        AddJournal($"Mod event — {e.Name}: {e.Text}");
        AddWorldHistory("Mod", $"Custom event triggered: {e.Name}.");
    }

    private void ApplyModEffect(string effect)
    {
        foreach (var part in effect.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var pair = part.Split(':', 2);
            if (pair.Length != 2 || !int.TryParse(pair[1], out int amount)) continue;
            switch (pair[0].Trim().ToLowerInvariant())
            {
                case "luck": Player.Luck += amount; break;
                case "morale": Player.Morale += amount; break;
                case "gold": Player.Gold += amount; Player.TotalGoldEarned += Math.Max(0, amount); break;
                case "reputation": Player.Reputation += amount; break;
                case "faith": Player.Faith.Favor += amount; break;
                case "magic": World.MagicInstability += amount; break;
                case "roadsafety": World.RoadSafety += amount; break;
            }
        }
    }

    private void MaybeMysteryBoxEvent()
    {
        if (Player.StoryDay < 180) return;
        Player.MysteryEventsSeen++;
        string eventText = Pick(new[]
        {
            "A door appears in the rented room. It opens onto rain, despite the hallway being dry.",
            "A stranger delivers a letter written in the hero's own handwriting, dated next winter.",
            "An innkeeper remembers a hero who has not been born yet.",
            "A dead companion is seen in a crowd, smiling like an apology.",
            "For one day, every map omits the town the hero is standing in.",
            "A candle burns blue and whispers the name of the current nemesis. Rude candle."
        });
        Player.Luck += _random.Next(-1, 4);
        World.MagicInstability += 1;
        AddJournal("Mystery: " + eventText);
        AddTimeline("Mystery event witnessed.");
    }

    private void AgeArc(StoryArc arc)
    {
        if (Percent(8 + arc.Threat / 15))
        {
            arc.Progress = Math.Clamp(arc.Progress + _random.Next(1, 4), 0, 100);
            arc.Threat = Math.Clamp(arc.Threat + _random.Next(0, 3), 0, 100);
        }

        arc.Stage = arc.Progress switch
        {
            < 20 => "Rumor",
            < 45 => "Signs",
            < 75 => "Crisis",
            < 100 => "Major Event",
            _ => "Ending"
        };

        if (arc.Progress >= 100)
            ResolveArc(arc, heroic: false);
    }

    private void ResolveArc(StoryArc arc, bool heroic)
    {
        if (arc.IsResolved) return;
        arc.IsResolved = true;
        arc.Stage = "Resolved";
        if (heroic || arc.Threat < 65)
        {
            arc.Ending = "Resolved by courage, timing, and the long road between safe places.";
            Player.Reputation += heroic ? 16 : 9;
            Player.Gold += 80 + Player.Level * 12;
            Player.Xp += 110 + Player.Level * 18;
            World.RoadSafety += 6;
            World.MonsterPressure -= 5;
            World.TownWealth += 4;
        }
        else
        {
            arc.Ending = "Ended badly enough that maps now avoid eye contact.";
            World.RoadSafety -= 8;
            World.MonsterPressure += 6;
            World.BanditPower += 4;
            Player.Morale -= 5;
        }
        World.Clamp();
        AddTimeline($"Arc ended: {arc.Name}.");
        AddJournal($"The arc '{arc.Name}' reaches an ending: {arc.Ending}");
    }

    private void ApplyYearlyRoutine()
    {
        int year = CurrentYear();
        int stipend = 22 + Math.Max(0, Player.Reputation) / 2 + Player.Level * 4 + Player.GuildHallTier * 12;
        int supplies = 3 + Math.Min(10, year / 2) + Player.GuildHallTier;
        Player.Gold += stipend;
        Player.TotalGoldEarned += stipend;
        Player.Supplies += supplies;
        Player.Potions += year % 2 == 0 ? 1 + Player.InfirmaryTier / 2 : 0;
        Player.Morale += 10 + Player.MemorialGardenTier;
        Player.Luck += year % 3 == 0 ? 1 : 0;
        World.TownWealth += Player.GuildHallTier > 0 ? 2 : 0;
        World.RoadSafety += Player.StableTier > 0 ? 1 : 0;
        AddTimeline($"Survived year {year}.");
        UpdateBloodlineFromHero();
        if (year % 25 == 0) { World.CurrentEra++; AddWorldHistory("Era", $"Era {World.CurrentEra} begins after {year} years of accumulated trouble."); }
        AddChronicleMilestone(year, year switch { 1 => "First Year", 7 => "The Seventh-Year Road", 19 => "The Road Wars Remembered", 42 => "The Black Tower Watches", 100 => "Century Chronicle", 250 => "Ancient Roads", 500 => "Age of Lanterns", _ => "Another Year Survived" }, $"{Player.Name} and the world enter another page of history.");
        MaybeRetiredHeroCameo();
        AddJournal($"A full year closes and {Player.Name} is still here. Habits, allies, and a small survivor's routine add {stipend} gold and {supplies} supplies.");
    }

    private void MaybeRetire()
    {
        if (!Player.IsAlive || Player.IsRetired) return;
        int years = Math.Max(0, (Player.StoryDay - 1) / 360);
        if (years < 6) return;

        int chance = 0;
        if (Player.LifePhilosophy == "Retire Wealthy" && Player.Gold >= 850) chance += 7;
        if (years >= 12 && Player.GuildHallTier >= 3) chance += 2;
        if (years >= 18 && Player.Reputation >= 45) chance += 2;
        if (years >= 25) chance += 3;
        if (Player.HasTrait("Patient")) chance += 1;
        if (Player.HasTrait("Reckless")) chance -= 2;
        if (chance <= 0 || !Percent(chance)) return;

        string retirement = Pick(new[]
        {
            "opens an inn with a suspiciously well-armed cellar",
            "becomes guildmaster and starts judging younger adventurers",
            "joins the temple as the person who actually knows field medicine",
            "becomes mayor mostly by refusing to die",
            "vanishes into legend with a pack full of maps",
            "becomes a mentor for the next fool with a sword"
        });
        EndLife("Retirement", $"after {FormatSurvivedTime()}, {Player.Name} {retirement}");
    }

    private void ApplyMinuteNeeds()
    {
        GetNeedRates(out double hungerPerHour, out double energyPerHour, out double hpPerHour, out double moralePerHour);
        Player.HungerCarry += hungerPerHour / 60.0;
        Player.EnergyCarry += energyPerHour / 60.0;
        Player.HpCarry += hpPerHour / 60.0;
        Player.MoraleCarry += moralePerHour / 60.0;
        Player.HungerCarry = ApplyCarry(Player.HungerCarry, v => Player.Hunger += v);
        Player.EnergyCarry = ApplyCarry(Player.EnergyCarry, v => Player.Energy += v);
        Player.HpCarry = ApplyCarry(Player.HpCarry, v => Player.CurrentHp += v);
        Player.MoraleCarry = ApplyCarry(Player.MoraleCarry, v => Player.Morale += v);
        Player.Clamp();
    }

    private double ApplyCarry(double carry, Action<int> apply)
    {
        if (Math.Abs(carry) < 1.0) return carry;
        int whole = (int)Math.Truncate(carry);
        carry -= whole;
        apply(whole);
        return carry;
    }

    private void GetNeedRates(out double hungerPerHour, out double energyPerHour, out double hpPerHour, out double moralePerHour)
    {
        hungerPerHour = 0.24;
        energyPerHour = -0.18;
        hpPerHour = 0.02;
        moralePerHour = 0.00;

        switch (Player.ActivityType)
        {
            case "RestInn": hungerPerHour = -0.70; energyPerHour = 10.0; hpPerHour = 7.8 + Player.InfirmaryTier; moralePerHour = 2.6; break;
            case "Camp": hungerPerHour = 0.03; energyPerHour = 7.4; hpPerHour = 4.3 + Player.CampTier * 0.6; moralePerHour = 1.1; break;
            case "Meal": hungerPerHour = -16.0; energyPerHour = 1.1; hpPerHour = 1.1; moralePerHour = 3.6; break;
            case "TempleCare": hungerPerHour = -0.35; energyPerHour = 6.8; hpPerHour = 10.0 + Player.InfirmaryTier * 1.5; moralePerHour = 1.4; break;
            case "Travel": hungerPerHour = 0.34; energyPerHour = -0.42; moralePerHour = -0.02; break;
            case "Quest":
            case "Adventure":
            case "Rumor":
            case "Arc":
            case "Legendary": hungerPerHour = 0.48; energyPerHour = -0.66; moralePerHour = -0.04; break;
            case "Work":
            case "Training": hungerPerHour = 0.39; energyPerHour = -0.55; moralePerHour = -0.02; break;
            case "Shop":
            case "Invest":
            case "Social": hungerPerHour = 0.32; energyPerHour = -0.22; moralePerHour = 0.45; break;
            case "Peaceful": hungerPerHour = 0.12; energyPerHour = 0.80; hpPerHour = 0.45; moralePerHour = 1.25; break;
            case "Forage": hungerPerHour = 0.30; energyPerHour = -0.44; moralePerHour = -0.02; break;
            case "Retreat": hungerPerHour = 0.18; energyPerHour = 2.55; hpPerHour = 2.6; moralePerHour = 0.8; break;
        }

        if (Player.Season == "Winter") hungerPerHour += 0.08;
        if (Player.Weather is "Snow" or "Sleet" or "Cold") energyPerHour -= 0.06;
        if (Player.Weather is "Heatwave" or "Dry Wind") hungerPerHour += 0.09;
        if (World.FoodSupply < 30) hungerPerHour += 0.05;
        if (World.Plague > 50) hpPerHour -= 0.05;
        if (Player.HasTrait("Hardy")) energyPerHour += 0.25;
        if (Player.HasTrait("Frail")) hpPerHour -= 0.03;
        if (Player.HasTrait("Haunted") && Player.StoryHour <= 4) moralePerHour -= 0.35;
        if (Player.GuildHallTier >= 4 && (Player.Location is "Brindlewick" or "Riverglass Port")) moralePerHour += 0.15;
    }

    private void HourlyNeedsAndRisk(bool offline)
    {
        if (Player.Hunger >= 96)
        {
            int damage = 1 + (Player.Hunger - 95) / 16;
            Player.CurrentHp -= damage;
            Player.Energy -= 1;
            if (!offline && Percent(7)) AddJournal($"Hunger starts doing damage. HP -{damage}. The next meal has become a plot point.");
        }
        if (Player.Energy <= 3)
        {
            if (Percent(40)) Player.CurrentHp -= 1;
            Player.Morale -= 1;
        }
        if (World.Plague > 70 && Percent(2 + World.Plague / 25))
        {
            Player.CurrentHp -= 1;
            Player.Morale -= 1;
            if (!offline && Percent(12)) AddJournal("The plague in the region presses at the edges of the day. Everyone washes their hands like it is a religion.");
        }

        if (Player.ActivityDanger > 0)
        {
            if (ShouldAbortDangerousActivity())
            {
                StartEmergencyRetreat("survival instincts finally got louder than ambition");
                return;
            }
            int hours = Math.Max(0, (Player.ActivityTotalMinutes - Player.ActivityMinutesRemaining) / 60);
            int risk = Math.Clamp(EffectiveDanger(Player.ActivityDanger) / 34, 0, 6);
            if (hours > 14) risk++;
            if (Player.Weather is "Storm" or "Snow" or "Sleet" or "Heatwave") risk++;
            if (Player.ActivityType is "Travel" or "Forage") risk = Math.Max(0, risk - 1);
            if (Player.HasTrait("Lucky")) risk--;
            if (Player.HasTrait("Reckless")) risk++;
            risk += DifficultyRiskHourly();
            risk = Math.Max(0, risk - LongLifeStabilityBonus() / 10);
            if (Percent(risk)) MidActivityEvent(offline);
        }
    }

    private int DifficultyRiskHourly()
    {
        return Player.Difficulty switch
        {
            "Cozy Chronicle" => -2,
            "Endless Legend" => -1,
            "Harsh World" => 1,
            "Iron Fate" => 2,
            _ => 0
        };
    }

    private int DifficultyDangerModifier()
    {
        return Player.Difficulty switch
        {
            "Cozy Chronicle" => -16,
            "Endless Legend" => -8,
            "Harsh World" => 12,
            "Iron Fate" => 24,
            _ => 0
        };
    }

    private int CheatDeathBonus()
    {
        return Player.Difficulty switch
        {
            "Cozy Chronicle" => 35,
            "Endless Legend" => 20,
            "Harsh World" => -10,
            "Iron Fate" => -25,
            _ => 0
        };
    }

    private int PhilosophyDangerModifier()
    {
        return Player.LifePhilosophy switch
        {
            "Seek Safety" => -10,
            "Chase Glory" => 8,
            "Pursue Legends" => 12,
            "Never Abandon Quests" => 5,
            "Avoid Violence" => -8,
            _ => 0
        };
    }

    private int LongLifeStabilityBonus()
    {
        int years = Math.Max(0, (Player.StoryDay - 1) / 360);
        int companionTrust = Player.Companions.Where(c => c.IsActive).Sum(c => c.Loyalty + c.Bond) / 35;
        int reputationSafety = Math.Clamp(Player.Reputation / 10, -4, 14);
        int gearRoutine = Math.Min(18, Player.CampTier + Player.ArmorTier / 2 + Player.WeaponTier / 3 + Player.GuildHallTier * 2 + Player.InfirmaryTier * 2);
        int memorial = Player.MemorialGardenTier * 2;
        int bloodline = World.Bloodlines.FirstOrDefault(b => b.Name == Player.BloodlineName)?.EstateTier * 2 ?? 0;
        int pets = Player.PetsMounts.Where(p => p.IsAlive).Sum(p => p.Utility) / 4;
        int artifacts = Player.Artifacts.Where(a => !a.IsLost).Sum(a => a.PowerLevel);
        int immortal = Player.IsImmortal ? 20 : 0;
        int home = Player.HomeTier * 2 + Player.HomeComfort / 12;
        return Math.Clamp(years * 4 + companionTrust + reputationSafety + gearRoutine + memorial + bloodline + pets + artifacts + immortal + home, 0, 85);
    }

    private bool ShouldAbortDangerousActivity()
    {
        if (Player.ActivityType is "RestInn" or "Camp" or "Meal" or "TempleCare" or "Shop" or "Social" or "Work" or "Training" or "Retreat" or "Invest" or "HomeLife" or "Faith" or "Research" or "Family" or "PetCare" or "Peaceful") return false;
        if (Player.LifePhilosophy == "Never Abandon Quests" && Player.CurrentHp > Player.MaxHp * 0.32 && Player.Energy > 16) return false;
        if (Player.CurrentHp <= Player.MaxHp * 0.40) return true;
        if (Player.Energy <= 20) return true;
        if (Player.Hunger >= 76 && Player.Supplies <= 0) return true;
        if (Player.Injuries.Count(i => i.IsActive && !i.IsPermanent) >= 3) return true;
        return false;
    }

    private void StartEmergencyRetreat(string reason)
    {
        StartActivity("Retreat", "Emergency retreat", $"{Player.Name} abandons the current plan because {reason}. Pride can limp; corpses cannot.", _random.Next(90, 280), 0, 0, 5 + Player.Level);
    }

    private void AutoUseEmergencyItems()
    {
        if (Player.Hunger >= 52 && Player.Supplies > 0)
        {
            Player.Supplies--;
            Player.Hunger = Math.Max(0, Player.Hunger - _random.Next(32, 52));
            Player.Energy += _random.Next(5, 12);
            AddJournal($"{Player.Name} eats from the pack before hunger becomes a crisis. Supplies -1.");
        }
        if (Player.CurrentHp <= Math.Max(36, (int)(Player.MaxHp * 0.43)) && Player.Potions > 0)
        {
            Player.Potions--;
            int healed = _random.Next(48, 82) + Player.Level * 3 + Player.InfirmaryTier * 6;
            Player.CurrentHp += healed;
            Player.NearDeaths++;
            AddJournal($"A potion gets opened with undignified urgency. HP +{healed}. Near-death reschedules.");
        }
    }

    private void MidActivityEvent(bool offline)
    {
        int roll = _random.Next(100);
        if (roll < 8)
        {
            int damage = _random.Next(1, 5) + EffectiveDanger(Player.ActivityDanger) / 34;
            Player.CurrentHp -= damage;
            AddJournal(Pick(new[]
            {
                $"Trouble interrupts the plan: {Player.Name} takes {damage} damage before the moment passes.",
                $"A bad step, a worse shadow, and suddenly the activity costs blood. HP -{damage}.",
                $"The road collects a small tax in bruises. HP -{damage}."
            }));
        }
        else if (roll < 20)
        {
            int loss = Math.Min(Player.Supplies, _random.Next(1, 3));
            Player.Supplies -= loss;
            if (loss > 0) AddJournal($"Bad weather and worse packing cost {loss} supplies."); else Player.Morale -= 2;
        }
        else if (roll < 31)
        {
            Player.Energy -= _random.Next(2, 6);
            Player.Morale -= _random.Next(1, 3);
            AddJournal($"The hours drag. Energy and morale slip while {Player.Name} considers the emotional merits of becoming a baker.");
        }
        else if (roll < 36)
        {
            AddInjury(false, Player.ActivityDanger);
        }
        else if (roll < 45 && Player.Companions.Any(c => c.IsActive))
        {
            CompanionTrouble();
        }
        else
        {
            int found = _random.Next(2, 12) + Player.Level;
            Player.Gold += found;
            Player.TotalGoldEarned += found;
            Player.Morale += 1;
            AddJournal($"A lucky find interrupts the misery: {found} gold tucked somewhere only desperate people check.");
        }
    }

    private void StartNextActivity(bool offline)
    {
        Player.Clamp();
        var location = CurrentLocation();
        if (!Player.IsAlive || Player.IsRetired) return;

        ApplyDirectorBeforeDecision(location);
        MaybeExpandWorld("a traveler, map scrap, or local story points past the known road", location.Kind == "Town" ? 3 : 5);

        if (ShouldSeekTown(location)) { StartTravelTowardTown(location); return; }
        if (location.Kind == "Town" && ShouldUseTempleCare()) { StartTempleCare(location); return; }
        if (ShouldRest(location)) { StartRest(location); return; }
        if (Player.Hunger >= 35 && location.Kind == "Town") { StartMeal(location); return; }
        if ((Player.Supplies <= 10 || Player.Potions <= 2) && location.Kind == "Town" && Player.Gold >= 8) { StartShopping(location); return; }
        if (location.Kind == "Town" && ShouldHandleFamilyOrHome()) { StartHomeLife(location); return; }
        if (location.Kind == "Town" && ShouldFaithVisit()) { StartFaithVisit(location); return; }
        if (location.Kind == "Town" && ShouldResearch()) { StartResearch(location); return; }
        if (location.Kind == "Town" && ShouldPetCare()) { StartPetCare(location); return; }
        if (location.Kind == "Town" && ShouldIdleCrafting(location)) { StartIdleCrafting(location); return; }
        if (location.Kind == "Town" && ShouldDailyRoutine(location)) { StartDailyRoutine(location); return; }
        if (location.Kind == "Town" && ShouldPeacefulLife(location)) { StartPeacefulLife(location); return; }
        if (location.Kind == "Town" && ShouldInvestInGuildHall()) { StartInvest(location); return; }
        if (location.Kind == "Town" && Player.Gold < 35 && Percent(Player.LifePhilosophy == "Get Rich" ? 78 : 55)) { StartWork(location); return; }
        if (ShouldUpgrade(location)) { StartUpgrade(location); return; }

        bool healthy = Player.Energy >= 72 && Player.Hunger <= 40 && Player.CurrentHp >= Player.MaxHp * 0.86 && Player.Injuries.Count(i => i.IsActive && !i.IsPermanent) <= 1;
        if (healthy)
        {
            var urgentArc = Player.StoryArcs.Where(a => !a.IsResolved && a.Progress >= 55 && a.Threat < SafeDangerLimit() + 26).OrderByDescending(a => a.Progress + a.Threat).FirstOrDefault();
            int arcChance = Player.LifePhilosophy == "Pursue Legends" ? 32 : Player.LifePhilosophy == "Seek Safety" ? 7 : 15;
            if (urgentArc != null && Percent(arcChance)) { StartArcQuest(location, urgentArc); return; }

            var usableRumor = Player.Rumors.Where(r => !r.IsResolved && r.Location == Player.Location && r.Danger <= SafeDangerLimit() + 12).OrderByDescending(r => r.Reward - r.DaysOld).FirstOrDefault();
            int rumorChance = Player.HasTrait("Curious") ? 32 : 15;
            if (Player.LifePhilosophy == "Pursue Legends") rumorChance += 8;
            if (usableRumor != null && Percent(rumorChance)) { StartRumor(location, usableRumor); return; }
            var nemesis = World.Nemeses.Where(n => n.IsActive && !n.IsDefeated && n.LastSeen == Player.Location && n.Threat <= SafeDangerLimit() + 22).OrderByDescending(n => n.Grudge + n.Threat).FirstOrDefault();
            if (nemesis != null && Percent(Player.LifePhilosophy == "Seek Safety" ? 6 : 18)) { StartNemesisEncounter(location, nemesis); return; }
            var rival = World.Rivals.Where(r => r.IsAlive && !r.IsRetired && r.Location == Player.Location).OrderByDescending(r => r.Fame).FirstOrDefault();
            if (rival != null && Percent(16)) { StartRivalEncounter(location, rival); return; }

            if (location.Kind == "Legendary" && Percent(Player.LifePhilosophy == "Pursue Legends" ? 28 : 10)) { StartLegendary(location); return; }
            int questChance = 17 + (Player.HasTrait("Brave") ? 8 : 0) - (Player.HasTrait("Cowardly") ? 7 : 0);
            if (Player.LifePhilosophy == "Chase Glory") questChance += 16;
            if (Player.LifePhilosophy == "Avoid Violence") questChance -= 12;
            if (Percent(questChance)) { StartQuest(location); return; }
        }

        if (location.Kind == "Town" && Percent(SocialChance())) { StartSocial(location); return; }
        if (Player.Energy >= 55 && Player.Hunger <= 50 && Percent(Player.LifePhilosophy == "Pursue Legends" ? 28 : 18)) { StartTravel(location); return; }
        if (location.Kind != "Town" && (Player.Supplies <= 7 || Percent(44))) { StartForage(location); return; }
        if (Player.Energy >= 55 && Player.Hunger <= 52 && Percent(28)) { StartTraining(location); return; }
        StartWander(location);
    }

    private int SocialChance()
    {
        int chance = 22;
        if (Player.HasTrait("Charming")) chance += 16;
        if (Player.LifePhilosophy == "Trust Companions") chance += 22;
        if (Player.LifePhilosophy == "Help People") chance += 10;
        return chance;
    }

    private bool ShouldRest(WorldLocation location)
    {
        if (Player.Energy <= (Player.LifePhilosophy == "Seek Safety" ? 72 : 62)) return true;
        if (Player.CurrentHp <= Player.MaxHp * (Player.LifePhilosophy == "Seek Safety" ? 0.94 : 0.88)) return true;
        if (Player.Injuries.Count(i => i.IsActive && !i.IsPermanent) >= 1 && Percent(60)) return true;
        if (Player.StoryHour >= 21 || Player.StoryHour <= 5) return Percent(location.Kind == "Town" ? 88 : 64);
        return false;
    }

    private bool ShouldUseTempleCare()
    {
        if (Player.Gold < 7) return false;
        if (Player.CurrentHp <= Player.MaxHp * 0.82) return true;
        if (Player.Injuries.Count(i => i.IsActive && !i.IsPermanent) >= 1) return true;
        if (Player.Hunger >= 72 && Player.Supplies <= 1) return true;
        if (World.Plague > 65 && Player.CurrentHp < Player.MaxHp && Percent(20)) return true;
        return false;
    }

    private bool ShouldSeekTown(WorldLocation location)
    {
        if (location.Kind == "Town") return false;
        if (Player.CurrentHp <= Player.MaxHp * 0.82) return true;
        if (Player.Energy <= 54) return true;
        if (Player.Hunger >= 58 && Player.Supplies <= 2) return true;
        if (Player.Injuries.Count(i => i.IsActive && !i.IsPermanent) >= 2) return true;
        return false;
    }

    private bool ShouldUpgrade(WorldLocation location)
    {
        if (location.Kind != "Town") return false;
        int minCost = Math.Min(UpgradeCost(Player.WeaponTier, 34), Math.Min(UpgradeCost(Player.ArmorTier, 36), UpgradeCost(Player.CampTier, 28)));
        int chance = Player.HasTrait("Greedy") ? 14 : 31;
        if (Player.LifePhilosophy == "Seek Safety") chance += 10;
        if (Player.LifePhilosophy == "Get Rich") chance -= 10;
        return Player.Gold >= minCost && Percent(chance);
    }

    private bool ShouldInvestInGuildHall()
    {
        if (Player.Gold < 160) return false;
        if (Player.GuildHallTier < 1) return Percent(22);
        if (Player.LifePhilosophy == "Get Rich" && Player.Gold < 500) return false;
        return Percent(15 + Player.Reputation / 8);
    }


    private bool ShouldHandleFamilyOrHome()
    {
        if (Player.Gold < 45 && Player.HomeTier > 0) return false;
        if (Player.HomeTier == 0 && Player.Gold >= 140) return Percent(16);
        if (Player.HomeTier > 0 && (Player.Morale < 55 || Player.HomeComfort < 40 || Player.FamilyMembers > 0 || Percent(7))) return Percent(18 + Player.HomeTier * 2);
        if (CurrentYear() >= 4 && Player.FamilyMembers == 0 && Player.Morale > 70 && Percent(3)) return true;
        if (CurrentYear() >= 3 && Player.Apprentices == 0 && Player.Reputation > 35 && Percent(4)) return true;
        return false;
    }

    private bool ShouldFaithVisit()
    {
        if (Player.Gold < 4) return false;
        if (Player.Faith.Favor < -15) return Percent(22);
        if (Player.Diseases.Any(d => d.IsActive) || Player.EmotionalScars.Any(e => e.IsActive && !e.IsPositive && e.Intensity > 30)) return Percent(20);
        if (Player.Faith.Blessing == "None" && Player.Faith.Favor > 25) return Percent(18);
        return Percent(4 + Player.ShrineTier);
    }

    private bool ShouldResearch()
    {
        if (Player.Energy < 50 || Player.Hunger > 55) return false;
        int chance = 8 + Player.LibraryTier * 4;
        if (Player.Background is "Failed Mage Student" or "Witch's Errand Runner") chance += 8;
        if (Player.LifePhilosophy == "Pursue Legends") chance += 5;
        return Percent(chance);
    }

    private bool ShouldPetCare()
    {
        if (Player.PetsMounts.Count(p => p.IsAlive) == 0 && Player.Gold >= 12) return Percent(5);
        if (Player.PetsMounts.Any(p => p.IsAlive && p.Bond < 45)) return Percent(11);
        return Percent(3);
    }


    private bool ShouldPeacefulLife(WorldLocation location)
    {
        if (location.Kind != "Town") return false;
        if (Player.CurrentHp < Player.MaxHp * 0.70 || Player.Hunger > 58 || Player.Energy < 45) return false;
        int chance = 8 + Player.HomeTier * 2 + Player.GardenTier + (Player.LifePhilosophy == "Seek Balance" ? 6 : 0);
        if (Player.Morale < 55) chance += 12;
        if (Player.FamilyMembers > 0 || Player.Apprentices > 0) chance += 4;
        return Percent(chance);
    }

    private int SafeDangerLimit()
    {
        int limit = 16 + Player.Level * 3 + Player.WeaponTier * 3 + Player.ArmorTier * 5 + Player.CampTier * 3 + Player.SurvivalBonus + LongLifeStabilityBonus();
        if (Player.CurrentHp < Player.MaxHp * 0.92) limit -= 12;
        if (Player.Energy < 75) limit -= 10;
        if (Player.Hunger > 38) limit -= 10;
        if (Player.Injuries.Count(i => i.IsActive && !i.IsPermanent) > 0) limit -= Player.Injuries.Count(i => i.IsActive && !i.IsPermanent) * 7;
        if (Player.HasTrait("Brave")) limit += 4;
        if (Player.HasTrait("Cowardly")) limit -= 6;
        limit += PhilosophyDangerModifier();
        limit -= DifficultyDangerModifier() / 3;
        return Math.Max(8, limit);
    }

    private string NearestTownFrom(WorldLocation location)
    {
        if (location.Routes.Contains("Brindlewick")) return "Brindlewick";
        if (location.Routes.Contains("Riverglass Port")) return "Riverglass Port";
        return location.Routes.Select(GetLocation).Where(l => l != null).Cast<WorldLocation>().OrderBy(l => l.Danger).FirstOrDefault()?.Name ?? "Brindlewick";
    }

    private void StartActivity(string type, string name, string description, int minutes, int danger, long gold, long xp, string faction = "", string rumorTitle = "", string destination = "", string arcName = "")
    {
        Player.ActivityType = type;
        Player.ActivityName = name;
        Player.CurrentActivity = description;
        Player.ActivityTotalMinutes = Math.Max(1, minutes);
        Player.ActivityMinutesRemaining = Player.ActivityTotalMinutes;
        Player.ActivityDanger = Math.Max(0, danger);
        Player.ActivityRewardGold = Math.Max(0, gold);
        Player.ActivityRewardXp = Math.Max(0, xp);
        Player.ActivityFaction = faction;
        Player.ActivityRumor = rumorTitle;
        Player.Destination = destination;
        Player.ActivityArc = arcName;
        Player.ActivityLocation = Player.Location;
        AddJournal(description + $" It should take about {FormatDuration(Player.ActivityTotalMinutes)}.");
    }

    private void StartRest(WorldLocation location)
    {
        bool inn = location.Kind == "Town" && Player.Gold >= 8;
        if (inn)
        {
            int cost = Math.Clamp(6 + (100 - location.InnQuality) / 20 - Player.Reputation / 20, 3, 14);
            SpendGold(cost);
            StartActivity("RestInn", "Resting at an inn", $"{Player.Name} rents a room in {location.Name}, pays {cost} gold, and lets the world be someone else's problem for one blessed night.", _random.Next(420, 610), 0, 0, 6);
        }
        else
        {
            StartActivity("Camp", "Making camp", $"{Player.Name} makes camp near {location.Name}. It is not comfortable, but neither is dying standing up.", _random.Next(330, 500), Math.Max(0, location.Danger / 3), 0, 5);
        }
    }

    private void StartMeal(WorldLocation location)
    {
        int cost = Math.Clamp(_random.Next(3, 8) + (World.FoodSupply < 30 ? 2 : 0) - (Player.HasTrait("Charming") ? 1 : 0), 1, 12);
        cost = Math.Min(cost, SafeInt(Player.Gold));
        SpendGold(cost);
        StartActivity("Meal", "Eating at the tavern", $"{Player.Name} spends {cost} gold on a hot meal in {location.Name}. Heroism is easier with soup involved.", _random.Next(45, 125), 0, 0, 3);
    }

    private void StartTempleCare(WorldLocation location)
    {
        int cost = Math.Clamp(_random.Next(10, 24) + Player.Injuries.Count(i => i.IsActive && !i.IsPermanent) * 5 - Player.InfirmaryTier * 3, 5, 60);
        cost = Math.Min(cost, SafeInt(Player.Gold));
        SpendGold(cost);
        StartActivity("TempleCare", "Taking recovery time", $"{Player.Name} pays {cost} gold for temple care, clean bandages, actual food, and several lectures about not bleeding on the floor.", _random.Next(420, 1800), 0, 0, 14, "Temple Order");
    }

    private void StartShopping(WorldLocation location)
    {
        StartActivity("Shop", "Shopping for survival goods", $"{Player.Name} searches {location.Name} for food, potions, rope, oil, replacement socks, and other thrilling essentials.", _random.Next(35, 120), 0, 0, 4, "Merchant Guild");
    }

    private void StartUpgrade(WorldLocation location)
    {
        StartActivity("Upgrade", "Commissioning better gear", $"{Player.Name} visits smiths, leatherworkers, and one extremely judgmental tailor in {location.Name} to improve survival odds.", _random.Next(95, 280), 0, 0, 11, "Merchant Guild");
    }

    private void StartInvest(WorldLocation location)
    {
        StartActivity("Invest", "Investing in the guild hall", $"{Player.Name} spends time turning spare gold into long-term safety: rooms, shelves, bandages, stables, shrines, and a memorial garden for people who deserved better.", _random.Next(180, 420), 0, 0, 12, "Common Folk");
    }


    private void StartHomeLife(WorldLocation location)
    {
        StartActivity("HomeLife", "Tending home and family", $"{Player.Name} spends time in {location.Name} on the parts of life that do not fit into quest contracts: home, family, apprentices, gardens, repairs, and quiet rooms.", _random.Next(180, 720), 0, 0, 16, "Common Folk");
    }

    private void StartFaithVisit(WorldLocation location)
    {
        int cost = Math.Min(SafeInt(Player.Gold), _random.Next(2, 12));
        SpendGold(cost);
        StartActivity("Faith", "Visiting shrine", $"{Player.Name} visits a shrine of {Player.Faith.God} in {location.Name}, leaving {cost} gold and several worries behind.", _random.Next(70, 260), 0, 0, 14, "Temple Order");
    }

    private void StartResearch(WorldLocation location)
    {
        StartActivity("Research", $"Studying {Player.Research.Field}", $"{Player.Name} spends the afternoon with books, diagrams, rumors, and the dangerous belief that learning solves things.", _random.Next(120, 430), Player.Research.IsForbidden ? 6 + World.MagicInstability / 12 : 0, 0, 28, "Mage Circle");
    }

    private void StartPetCare(WorldLocation location)
    {
        StartActivity("PetCare", "Caring for animals", $"{Player.Name} checks stables, stray animals, feed prices, and the ancient truth that a loyal animal is better than half the people on the road.", _random.Next(60, 220), 0, 0, 8, "Common Folk");
    }

    private void StartNemesisEncounter(WorldLocation location, Nemesis nemesis)
    {
        int danger = Math.Min(nemesis.Threat + location.Danger / 3, SafeDangerLimit() + 22);
        StartActivity("Nemesis", $"Nemesis: {nemesis.Name}", $"{nemesis.Name} is near {location.Name}. {Player.Name} follows the trail because unresolved grudges are basically quests with worse manners.", _random.Next(260, 1050), danger, 70 + nemesis.Threat, 95 + nemesis.Grudge, "Town Guard", "", "", nemesis.Name);
    }

    private void StartRivalEncounter(WorldLocation location, RivalAdventurer rival)
    {
        StartActivity("Rival", $"Rival: {rival.Name}", $"{Player.Name} crosses paths with {rival.Name}, a {rival.Role.ToLowerInvariant()}. This may become friendship, rivalry, gossip, or theft with paperwork.", _random.Next(90, 380), Math.Max(0, location.Danger / 5), 20 + rival.Fame, 28 + rival.Level * 8, "Monster Hunters", "", "", rival.Name);
    }

    private void StartQuest(WorldLocation location)
    {
        string seed = Pick(location.QuestSeeds.Length > 0 ? location.QuestSeeds : new[] { "doing dangerous work for unclear reasons" });
        string faction = Pick(_factions.Where(f => f != "Bandit Clans").ToArray());
        int danger = Math.Max(3, location.Danger + _random.Next(0, 12) - Player.GuildRank + World.MonsterPressure / 12 + World.BanditPower / 16 - World.RoadSafety / 25);
        danger = ClampChosenDanger(danger);
        int hours = _random.Next(3, 11) + Math.Max(0, location.Danger / 16);
        if (location.Kind is "Dungeon" or "Legendary") hours += _random.Next(5, 24);
        long gold = location.Reward + _random.Next(12, 32) + Player.Level * 8;
        long xp = 32 + location.Danger + Player.Level * 11;
        StartActivity("Quest", $"Quest: {seed}", $"{Player.Name} accepts work involving {seed}. The contract looks survivable, which is how contracts lie.", hours * 60 + _random.Next(0, 90), danger, gold, xp, faction);
    }

    private int ClampChosenDanger(int danger)
    {
        if (Player.HasTrait("Brave")) danger += 4;
        if (Player.HasTrait("Cowardly")) danger -= 7;
        danger += DifficultyDangerModifier() / 4;
        if (danger > SafeDangerLimit() + 14) danger = SafeDangerLimit() + _random.Next(0, 9);
        return Math.Max(2, danger);
    }

    private void StartRumor(WorldLocation location, Rumor rumor)
    {
        Player.RumorsFollowed++;
        int danger = Math.Min(rumor.Danger + location.Danger / 4, SafeDangerLimit() + 10);
        StartActivity("Rumor", $"Rumor: {rumor.Title}", $"The rumor about {rumor.Title.ToLowerInvariant()} gets too loud to ignore. {Player.Name} follows it into the part of the story where people make mistakes.", _random.Next(180, 850) + danger * 4, danger, rumor.Reward, rumor.Reward + 18, rumor.Faction, rumor.Title);
    }

    private void StartArcQuest(WorldLocation location, StoryArc arc)
    {
        int danger = Math.Min(location.Danger + arc.Threat / 3 + arc.Progress / 7, SafeDangerLimit() + 12);
        long reward = 65 + arc.Progress + Player.Level * 15;
        StartActivity("Arc", $"Arc: {arc.Name}", $"The larger story pulls on {Player.Name}: {arc.Description} Ignoring it would be safer, so naturally the hero does not.", _random.Next(420, 1600) + arc.Threat * 2, danger, reward, reward + 35, Pick(_factions), "", "", arc.Name);
    }

    private void StartLegendary(WorldLocation location)
    {
        int danger = Math.Min(location.Danger + _random.Next(8, 26), SafeDangerLimit() + 24);
        long reward = 220 + location.Reward + Player.Level * 20;
        StartActivity("Legendary", "Legendary expedition", $"A rare opening appears in {location.Name}. {Player.Name} follows the kind of omen that usually gets painted on tavern walls afterward.", _random.Next(900, 3600), danger, reward, reward + 90, Pick(_factions));
    }

    private void StartSocial(WorldLocation location)
    {
        StartActivity("Social", "Listening for rumors", $"{Player.Name} spends time in {location.Name} listening, smiling at the right moments, and buying exactly enough drinks to make strangers informative.", _random.Next(80, 240), 0, 0, 6, Pick(_factions));
    }

    private void StartPeacefulLife(WorldLocation location)
    {
        string scene = Pick(new[]
        {
            "tending a stubborn little garden and pretending weeds are less dangerous than wolves",
            "repairing boots by a warm window while rain taps patient fingers on the glass",
            "writing letters that may or may not ever be sent",
            "teaching an apprentice how to pack rope without creating a cursed knot",
            "sharing soup with neighbors who know better than to ask about the blood on the cloak",
            "sitting through a festival rehearsal where every lantern has an opinion",
            "brushing mud from gear and calling it emotional growth",
            "reading old notes by the hearth while the pet judges the handwriting"
        });
        StartActivity("Peaceful", "Peaceful life", $"{Player.Name} spends quiet time in {location.Name}, {scene}. Not every useful day needs teeth.", _random.Next(90, 420), 0, 0, _random.Next(5, 18), "Common Folk");
    }

    private void FinishPeacefulLife()
    {
        int morale = _random.Next(3, 9) + Player.HomeTier;
        int comfort = _random.Next(1, 5) + Player.GardenTier / 2;
        Player.Morale += morale;
        Player.HomeComfort = Math.Clamp(Player.HomeComfort + comfort, 0, 100);
        if (Percent(18)) Player.Supplies += 1;
        if (Percent(12)) AddMemoryTag("peaceful day at home");
        AddJournal($"Peaceful life helps. Morale +{morale}, comfort +{comfort}. {Player.Name} gets the rare fantasy reward of a day that does not bite.");
    }

    private void StartWork(WorldLocation location)
    {
        string job = Pick(new[] { "hauling crates", "guarding a warehouse", "copying notices", "watching a gate", "cleaning monster bits off a cart", "helping a merchant count inventory" });
        StartActivity("Work", "Taking safe-ish town work", $"Gold is low, so {Player.Name} takes work {job} in {location.Name}. Glamour has left the building.", _random.Next(180, 540), Math.Max(0, location.Danger / 3), _random.Next(10, 32) + Player.Level * 2, _random.Next(8, 22), Pick(_factions));
    }

    private void StartTravel(WorldLocation location)
    {
        var possibleRoutes = location.Routes.Select(GetLocation).Where(l => l != null).Cast<WorldLocation>().Where(l => l.Name != Player.Location).OrderBy(l => l.Danger).ToList();
        if (possibleRoutes.Count == 0) { StartWander(location); return; }
        var safeRoutes = possibleRoutes.Where(l => l.Danger <= SafeDangerLimit() || l.Kind == "Town").ToList();
        var pool = safeRoutes.Count > 0 ? safeRoutes : possibleRoutes;
        if (Player.LifePhilosophy == "Pursue Legends" && possibleRoutes.Any(l => l.Kind == "Legendary") && Percent(20)) pool = possibleRoutes.Where(l => l.Kind == "Legendary").ToList();
        var dest = pool.OrderBy(_ => _random.Next()).First();
        int minutes = _random.Next(180, 760) + (location.Danger + dest.Danger) * 3 - Player.StableTier * 20;
        if (Player.Weather is "Storm" or "Snow" or "Sleet" or "Heatwave") minutes += _random.Next(60, 180);
        if (Player.Season == "Winter") minutes += _random.Next(40, 140);
        int danger = Math.Max(1, (location.Danger + dest.Danger) / 3 + _random.Next(0, 8) + (100 - World.RoadSafety) / 25);
        StartActivity("Travel", $"Travel to {dest.Name}", $"{Player.Name} chooses the road toward {dest.Name}. The route is picked with at least half a survival instinct.", minutes, danger, 0, 9 + dest.Danger / 3, "", "", dest.Name);
    }

    private void StartTravelTowardTown(WorldLocation location)
    {
        string destination = NearestTownFrom(location);
        var dest = GetLocation(destination) ?? GetLocation("Brindlewick") ?? location;
        int minutes = _random.Next(180, 640) + (location.Danger + dest.Danger) * 3 - Player.StableTier * 20;
        int danger = Math.Max(1, (location.Danger + dest.Danger) / 3 + _random.Next(0, 5));
        StartActivity("Travel", $"Careful travel to {destination}", $"{Player.Name} decides survival is more attractive than glory and heads carefully toward {destination}.", minutes, danger, 0, 8 + dest.Danger / 3, "", "", destination);
    }

    private void StartForage(WorldLocation location)
    {
        StartActivity("Forage", "Foraging for supplies", $"{Player.Name} searches around {location.Name} for edible things, useful things, and ideally not poisonous versions of either.", _random.Next(90, 340), Math.Max(1, location.Danger / 4), _random.Next(0, 8), _random.Next(8, 24));
    }

    private void StartTraining(WorldLocation location)
    {
        string training = location.Kind == "Town" ? "with a bored yard instructor" : "against trees, stones, and the concept of self-preservation";
        StartActivity("Training", "Training", $"{Player.Name} trains {training}. No one applauds, which is probably character building.", _random.Next(120, 330), Math.Max(0, location.Danger / 8), 0, _random.Next(24, 50) + Player.Level * 5, "Monster Hunters");
    }

    private void StartWander(WorldLocation location)
    {
        StartActivity("Adventure", "Wandering without a contract", $"With no better plan, {Player.Name} wanders through {location.Name}, letting curiosity and poor scheduling make decisions.", _random.Next(100, 540), Math.Max(1, Math.Min(location.Danger + _random.Next(-8, 5), SafeDangerLimit() + 5)), location.Reward / 2, 14 + location.Danger);
    }

    private void FinishCurrentActivity(bool offline)
    {
        string type = Player.ActivityType;
        switch (type)
        {
            case "RestInn": FinishRest(true); break;
            case "Camp": FinishRest(false); break;
            case "Meal": FinishMeal(); break;
            case "TempleCare": FinishTempleCare(); break;
            case "Shop": FinishShopping(); break;
            case "Upgrade": FinishUpgrade(); break;
            case "Invest": FinishInvest(); break;
            case "Quest": FinishRiskyActivity("quest"); break;
            case "Rumor": FinishRiskyActivity("rumor"); break;
            case "Arc": FinishRiskyActivity("story arc"); break;
            case "Legendary": FinishRiskyActivity("legendary expedition"); break;
            case "Adventure": FinishRiskyActivity("adventure"); break;
            case "Travel": FinishTravel(); break;
            case "Forage": FinishForage(); break;
            case "Work": FinishWork(); break;
            case "Training": FinishTraining(); break;
            case "Social": FinishSocial(); break;
            case "HomeLife": FinishHomeLife(); break;
            case "Faith": FinishFaithVisit(); break;
            case "Research": FinishResearch(); break;
            case "PetCare": FinishPetCare(); break;
            case "Peaceful": FinishPeacefulLife(); break;
            case "DailyRoutine": FinishDailyRoutine(); break;
            case "Crafting": FinishIdleCrafting(); break;
            case "Nemesis": FinishNemesisEncounter(); break;
            case "Rival": FinishRivalEncounter(); break;
            case "Retreat": FinishEmergencyRetreat(); break;
            default: AddJournal($"{Player.Name} finishes doing nothing in particular. Honestly, healthy."); break;
        }
        Player.ActivityType = "Idle";
        Player.ActivityName = "Deciding";
        Player.CurrentActivity = "deciding what the road wants next";
        Player.ActivityDanger = 0;
        Player.ActivityRewardGold = 0;
        Player.ActivityRewardXp = 0;
        Player.ActivityFaction = "";
        Player.ActivityRumor = "";
        Player.ActivityArc = "";
        Player.Destination = "";
        Player.Clamp();
    }

    private void FinishEmergencyRetreat()
    {
        Player.CurrentHp += _random.Next(8, 20) + Player.InfirmaryTier * 2;
        Player.Energy += _random.Next(12, 26);
        Player.Morale += 2;
        Player.Xp += Player.ActivityRewardXp;
        AddJournal($"The retreat ends. {Player.Name} is alive, which is the least glamorous and most important victory.");
    }

    private void FinishRest(bool inn)
    {
        int hp = inn ? _random.Next(35, 58) + Player.InfirmaryTier * 5 : _random.Next(18, 38) + Player.CampTier * 4;
        int energy = inn ? _random.Next(45, 70) : _random.Next(35, 56);
        Player.CurrentHp += hp;
        Player.Energy += energy;
        Player.Morale += inn ? 7 : 3;
        Player.TimesRested++;
        if (!inn && Percent(18)) Player.Supplies = Math.Max(0, Player.Supplies - 1);
        AddJournal(inn ? $"The inn rest works wonders. HP +{hp}, energy +{energy}." : $"Camp is rough, but sleep still does its quiet miracle. HP +{hp}, energy +{energy}.");
    }

    private void FinishMeal()
    {
        int hunger = _random.Next(35, 58);
        Player.Hunger = Math.Max(0, Player.Hunger - hunger);
        Player.Morale += _random.Next(4, 9);
        Player.Energy += _random.Next(4, 10);
        World.TownWealth += 1;
        AddJournal($"The meal helps. Hunger -{hunger}. The world is still dangerous, but less on an empty stomach.");
    }

    private void FinishTempleCare()
    {
        int healed = _random.Next(45, 92) + Player.InfirmaryTier * 10;
        Player.CurrentHp += healed;
        Player.Hunger = Math.Max(0, Player.Hunger - _random.Next(18, 38));
        Player.Energy += _random.Next(18, 35);
        int injuriesHealed = 0;
        foreach (var injury in Player.Injuries.Where(i => i.IsActive && !i.IsPermanent).OrderByDescending(i => i.DaysRemaining).Take(2 + Player.InfirmaryTier))
        {
            injury.DaysRemaining = Math.Max(0, injury.DaysRemaining - _random.Next(4, 12) - Player.InfirmaryTier * 2);
            if (injury.DaysRemaining == 0) injuriesHealed++;
        }
        if (Player.Injuries.Any(i => i.IsActive && i.IsPermanent) && Percent(6 + Player.InfirmaryTier * 3))
        {
            var permanent = Player.Injuries.First(i => i.IsActive && i.IsPermanent);
            permanent.IsPermanent = false;
            permanent.DaysRemaining = _random.Next(18, 45);
            AddJournal($"Temple care turns {permanent.Name.ToLowerInvariant()} from permanent to merely long-term. That is basically a miracle with paperwork.");
        }
        Player.Injuries.RemoveAll(i => !i.IsPermanent && i.DaysRemaining <= 0);
        Player.AddFaction("Temple Order", 2);
        World.Plague -= 1;
        AddJournal($"Temple care ends. HP +{healed}. Injuries improved: {injuriesHealed}. The priest looks tired but victorious.");
    }

    private void FinishShopping()
    {
        int budget = SafeInt(Math.Min(Player.Gold, 45 + Player.Level * 4 + World.Economy / 2));
        int spent = 0;
        int suppliesBought = 0;
        int potionsBought = 0;
        while (budget - spent >= 5 && Player.Supplies < 26 + Player.GuildHallTier * 2 && Percent(70))
        {
            int cost = World.FoodSupply < 35 ? 7 : 5;
            spent += cost;
            suppliesBought += 2;
        }
        while (budget - spent >= 12 && Player.Potions < 7 + Player.InfirmaryTier && Percent(55))
        {
            spent += 12;
            potionsBought++;
        }
        spent = Math.Min(spent, SafeInt(Player.Gold));
        SpendGold(spent);
        Player.Supplies += suppliesBought;
        Player.Potions += potionsBought;
        Player.ShopVisits++;
        Player.AddFaction("Merchant Guild", 2);
        World.TownWealth += Math.Max(1, spent / 20);
        AddJournal($"Shopping ends. Spent {spent} gold, supplies +{suppliesBought}, potions +{potionsBought}. The backpack feels less tragic.");
    }

    private int UpgradeCost(int tier, int baseCost) => baseCost + tier * 32 + World.Economy / 4;

    private void FinishUpgrade()
    {
        int weaponCost = UpgradeCost(Player.WeaponTier, 34);
        int armorCost = UpgradeCost(Player.ArmorTier, 36);
        int campCost = UpgradeCost(Player.CampTier, 28);
        string choice = "nothing, because prices were rude";
        if (Player.Gold >= armorCost && (Player.ArmorTier <= Player.WeaponTier || Player.LifePhilosophy == "Seek Safety"))
        {
            SpendGold(armorCost); Player.ArmorTier++; choice = $"armor tier +1 for {armorCost} gold";
        }
        else if (Player.Gold >= weaponCost && Player.LifePhilosophy != "Avoid Violence")
        {
            SpendGold(weaponCost); Player.WeaponTier++; choice = $"weapon tier +1 for {weaponCost} gold";
        }
        else if (Player.Gold >= campCost)
        {
            SpendGold(campCost); Player.CampTier++; choice = $"camp kit tier +1 for {campCost} gold";
        }
        Player.AddFaction("Merchant Guild", 2);
        AddJournal($"The upgrade errand ends with {choice}. Survival has been slightly commercialized.");
    }

    private void FinishInvest()
    {
        int choice = _random.Next(7);
        int cost = 120 + (Player.GuildHallTier + Player.InfirmaryTier + Player.StableTier + Player.LibraryTier + Player.ShrineTier + Player.BlacksmithTier + Player.MemorialGardenTier) * 45;
        cost = Math.Min(cost, SafeInt(Player.Gold));
        if (cost < 60)
        {
            AddJournal("The guild hall plan dies in the budget meeting, which is less dramatic than a dragon but still painful.");
            return;
        }
        SpendGold(cost);
        string result;
        switch (choice)
        {
            case 0: Player.GuildHallTier++; result = "the guild hall itself grows"; break;
            case 1: Player.InfirmaryTier++; result = "the infirmary gets better beds and cleaner bandages"; break;
            case 2: Player.StableTier++; result = "the stable adds safer travel routes"; break;
            case 3: Player.LibraryTier++; result = "the library gains maps, monster notes, and extremely cursed bookmarks"; break;
            case 4: Player.ShrineTier++; result = "the shrine becomes a quieter place to recover"; break;
            case 5: Player.BlacksmithTier++; result = "the blacksmith corner starts producing better gear"; break;
            default: Player.MemorialGardenTier++; result = "the memorial garden remembers old names"; break;
        }
        Player.Reputation += 2;
        World.TownWealth += 3;
        World.RoadSafety += Player.StableTier > 0 ? 1 : 0;
        AddTimeline($"Invested in guild hall: {result}.");
        AddJournal($"{Player.Name} spends {cost} gold and {result}. This is how an idle life turns into a place in the world.");
    }

    private void FinishRiskyActivity(string label)
    {
        int danger = EffectiveDanger(Player.ActivityDanger);
        int skill = Player.Attack + Player.Defense + Player.SurvivalBonus + Player.Luck + Player.Level * 2 + LongLifeStabilityBonus() / 2;
        if (Player.HasTrait("Brave")) skill += 4;
        if (Player.HasTrait("Cowardly")) skill += 2;
        if (Player.HasTrait("Greedy")) danger += 3;
        if (Player.HasTrait("Reckless")) danger += 7;
        if (Player.HasTrait("Practical")) skill += 5;

        int roll = _random.Next(1, 101) + skill;
        int target = 45 + (int)(danger * 0.58) + DifficultyDangerModifier() - LongLifeStabilityBonus() / 3;
        bool success = roll >= target;
        bool heroic = roll >= target + 38;
        bool disaster = roll < target - 42;

        if (success)
        {
            long gold = Player.ActivityRewardGold + (heroic ? danger : 0);
            long xp = Player.ActivityRewardXp + (heroic ? danger / 2 : 0);
            Player.Gold += gold;
            Player.TotalGoldEarned += gold;
            Player.Xp += xp;
            Player.Reputation += heroic ? 3 : 1;
            Player.Morale += heroic ? 7 : 3;
            if (label is "quest" or "rumor" or "story arc") Player.QuestsCompleted++;
            Player.AdventuresSurvived++;
            if (label == "legendary expedition") Player.LegendaryEventsSeen++;
            if (!string.IsNullOrWhiteSpace(Player.ActivityFaction)) Player.AddFaction(Player.ActivityFaction, heroic ? 5 : 2);
            ResolveRumorIfNeeded(true);
            ProgressArcOnSuccess(label, heroic);
            ImproveWorldAfterSuccess(label, danger, heroic);

            AddJournal(heroic ? $"The {label} ends brilliantly. {Player.Name} returns with {gold} gold, {xp} XP, and a reputation for impossible timing." : $"The {label} succeeds. {Player.Name} earns {gold} gold and {xp} XP, then acts like this was the plan.");
            MaybeExpandWorld(heroic ? "a heroic success unlocks a larger map rumor" : "the reward includes directions to somewhere new", heroic ? 14 : 5);
            if (Percent(CompanionMeetChance())) MaybeMeetCompanion();
            if (Percent(18)) MaybeCreateRumor("reward gossip");
            if (heroic) AddTimeline($"Heroic success: {label} in {Player.ActivityLocation}.");
        }
        else
        {
            if (label is "quest" or "rumor" or "story arc") Player.QuestsFailed++;
            int damage = _random.Next(2, 10) + danger / 11;
            int goldLoss = Math.Min(SafeInt(Player.Gold), _random.Next(0, Math.Max(1, danger / 2 + 6)));
            Player.CurrentHp -= damage;
            SpendGold(goldLoss);
            Player.Morale -= _random.Next(4, 12);
            if (!string.IsNullOrWhiteSpace(Player.ActivityFaction)) Player.AddFaction(Player.ActivityFaction, disaster ? -6 : -2);
            ResolveRumorIfNeeded(false);
            ProgressArcOnFailure(disaster);
            World.MonsterPressure += disaster ? 2 : 1;
            World.BanditPower += label == "quest" && disaster ? 2 : 0;

            if (disaster) AddMemoryTag("disaster: " + label);
            AddJournal(disaster ? $"The {label} becomes a disaster. HP -{damage}, gold -{goldLoss}. The retreat is ugly, loud, and not guaranteed to be over." : $"The {label} fails. HP -{damage}, gold -{goldLoss}. {Player.Name} escapes with the traditional adventurer prize: a lesson nobody wanted.");
            if (Percent(disaster ? 23 : 9)) AddInjury(disaster, danger);
            if (disaster && Percent(14)) CompanionTrouble();
            TryCheatDeath($"the failed {label}", danger);
        }
        CheckDeath($"a failed {label} in {Player.ActivityLocation}");
    }

    private void ImproveWorldAfterSuccess(string label, int danger, bool heroic)
    {
        if (label is "quest" or "adventure" or "legendary expedition") World.MonsterPressure -= heroic ? 3 : 1;
        if (label is "quest" or "rumor") World.BanditPower -= heroic ? 3 : 1;
        if (label is "quest" or "story arc") World.RoadSafety += heroic ? 2 : 1;
        if (label == "legendary expedition") World.MagicInstability -= 4;
        World.TownWealth += heroic ? 2 : 1;
        World.Clamp();
    }

    private void FinishTravel()
    {
        int danger = EffectiveDanger(Player.ActivityDanger);
        int roll = _random.Next(1, 101) + Player.SurvivalBonus + Player.Defense + Player.Luck / 2 + LongLifeStabilityBonus() / 2;
        bool safe = roll >= 28 + (int)(danger * 0.55) + DifficultyDangerModifier() / 2 - LongLifeStabilityBonus() / 4;
        if (safe)
        {
            Player.Location = string.IsNullOrWhiteSpace(Player.Destination) ? Player.Location : Player.Destination;
            Player.Xp += Player.ActivityRewardXp;
            Player.Morale += 1;
            AddJournal($"Travel ends at {Player.Location}. {Player.Name} arrives tired, dusty, and alive — the holy trinity of successful walking.");
            MaybeExpandWorld("the road keeps going beyond the old map edge", 16);
            if (Percent(22)) MaybeCreateRumor("road rumor");
        }
        else
        {
            int damage = _random.Next(1, 7) + danger / 10;
            Player.CurrentHp -= damage;
            Player.Energy -= _random.Next(5, 14);
            Player.Morale -= 3;
            AddJournal($"The road to {Player.Destination} turns cruel. {Player.Name} is forced back toward {Player.Location}. HP -{damage}.");
            if (Percent(13)) AddInjury(false, danger);
            if (Percent(10)) Player.Supplies = Math.Max(0, Player.Supplies - 1);
        }
        CheckDeath($"the road between {Player.ActivityLocation} and {Player.Destination}");
    }

    private void FinishForage()
    {
        int danger = EffectiveDanger(Player.ActivityDanger);
        int roll = _random.Next(1, 101) + Player.SurvivalBonus + Player.Luck + LongLifeStabilityBonus() / 3;
        if (roll >= 24 + (int)(danger * 0.5) + DifficultyDangerModifier() / 2 - LongLifeStabilityBonus() / 5)
        {
            int supplies = _random.Next(1, 4) + (Player.HasTrait("Practical") ? 1 : 0);
            Player.Supplies += supplies;
            Player.Hunger = Math.Max(0, Player.Hunger - _random.Next(3, 10));
            Player.Xp += Player.ActivityRewardXp;
            AddJournal($"Foraging works out: supplies +{supplies}. Nature briefly pretends to be generous.");
        }
        else
        {
            int damage = _random.Next(1, 4) + danger / 12;
            Player.CurrentHp -= damage;
            Player.Hunger += 3;
            AddJournal($"Foraging produces thorns, mud, and regret. HP -{damage}. Food remains rude and hidden.");
            if (Percent(8)) AddInjury(false, danger);
        }
        CheckDeath("a miserable attempt to live off the land");
    }

    private void FinishWork()
    {
        long gold = Player.ActivityRewardGold;
        long xp = Player.ActivityRewardXp;
        if (Player.HasTrait("Charming")) gold += 3;
        if (Player.HasTrait("Greedy") || Player.LifePhilosophy == "Get Rich") gold += 5;
        Player.Gold += gold;
        Player.TotalGoldEarned += gold;
        Player.Xp += xp;
        Player.Morale += Player.HasTrait("Practical") ? 2 : -1;
        if (!string.IsNullOrWhiteSpace(Player.ActivityFaction)) Player.AddFaction(Player.ActivityFaction, 2);
        World.TownWealth += 1;
        AddJournal($"The work is finished. Gold +{gold}, XP +{xp}. Nobody writes songs about it, but rent does not care about songs.");
    }

    private void FinishTraining()
    {
        long xp = Player.ActivityRewardXp + Player.LibraryTier * 2;
        Player.Xp += xp;
        Player.Energy -= 4;
        Player.Morale += Player.HasTrait("Brave") ? 2 : 0;
        if (Percent(10 + Player.Level + Player.BlacksmithTier))
        {
            if (Percent(50)) Player.WeaponTier++; else Player.ArmorTier++;
            AddJournal($"Training clicks into place. Some tiny part of {Player.Name}'s gear or technique improves, and it only cost sweat and dignity.");
        }
        AddJournal($"Training ends. XP +{xp}. The body complains, but apparently that is how progress sounds.");
    }

    private void FinishSocial()
    {
        Player.Morale += _random.Next(3, 9);
        Player.Reputation += Percent(Player.HasTrait("Charming") ? 55 : 25) ? 1 : 0;
        if (!string.IsNullOrWhiteSpace(Player.ActivityFaction)) Player.AddFaction(Player.ActivityFaction, 1);
        MaybeCreateRumor("tavern rumor");
        if (Percent(CompanionMeetChance())) MaybeMeetCompanion();
        AddJournal($"After a few hours of listening, {Player.Name} leaves with warmer spirits and fresh nonsense to worry about.");
    }


    private void FinishHomeLife()
    {
        if (Player.HomeTier == 0 && Player.Gold >= 120)
        {
            SpendGold(120);
            Player.HomeTier = 1;
            Player.HomeName = Pick(new[] { "a creaky cottage", "a rented room with a lock that mostly works", "a backstreet loft", "a tiny guild room" });
            Player.HomeComfort += 10;
            AddTimeline("Found a home base.");
            AddJournal($"{Player.Name} claims {Player.HomeName} as a home base. It is not much, but neither is sleeping in rain.");
        }
        else
        {
            int comfort = _random.Next(2, 7) + Player.GardenTier;
            Player.HomeComfort += comfort;
            Player.Morale += _random.Next(4, 10);
            if (Player.Gold >= 35 && Percent(25)) { SpendGold(35); Player.HomeTier = Math.Min(10, Player.HomeTier + 1); AddJournal("Home upgrade: a better bed, stronger locks, shelves for maps, and the fantasy luxury of dry socks."); }
            if (Player.Gold >= 25 && Percent(18)) { SpendGold(25); Player.GardenTier = Math.Min(10, Player.GardenTier + 1); AddJournal("The garden grows. Herbs, flowers, and practical hope take root."); }
            if (CurrentYear() >= 3 && Player.FamilyMembers == 0 && Percent(10))
            {
                Player.FamilyMembers = 1;
                Player.FamilyStatus = Pick(new[] { "found family at the hearth", "adopted kin and shared keys", "a household built from trust instead of blood", "quiet family ties in a loud world" });
                Player.FamilyMilestones++;
                AddTimeline("Family milestone: a household formed.");
                AddJournal($"Family milestone: {Player.FamilyStatus}. The story gains someone waiting at home.");
            }
            MaybeChildMilestone();
            if (Player.Reputation > 35 && Player.Apprentices == 0 && Percent(9))
            {
                Player.Apprentices = 1;
                Player.FamilyMilestones++;
                AddTimeline($"Apprentice accepted: {Player.HeirName}.");
                AddJournal($"{Player.HeirName} asks to learn the road from {Player.Name}. This is either mentorship or delayed panic.");
            }
            AddJournal($"Home time helps. Comfort +{comfort}. {Player.Name} remembers that survival includes somewhere to return to.");
        }
        UpdateBloodlineFromHero();
    }

    private void FinishFaithVisit()
    {
        int favor = _random.Next(3, 10) + Player.ShrineTier;
        Player.Faith.Favor += favor;
        Player.Morale += _random.Next(2, 7);
        if (Player.Diseases.Any(d => d.IsActive) && Percent(35 + Player.ShrineTier * 5))
        {
            var disease = Player.Diseases.Where(d => d.IsActive).OrderByDescending(d => d.Severity).First();
            disease.Severity -= _random.Next(4, 12) + Player.ShrineTier;
            disease.DaysRemaining = Math.Max(0, disease.DaysRemaining - _random.Next(1, 5));
            AddJournal($"Temple care softens {disease.Name}. Not a miracle maybe, but close enough to say thank you.");
        }
        if (Player.Faith.Favor > 35 && Percent(28)) GrantBlessing();
        AddJournal($"The shrine visit ends. Favor with {Player.Faith.God} +{favor}.");
    }

    private void FinishResearch()
    {
        int gain = _random.Next(8, 22) + Player.LibraryTier * 3 + (Player.Background == "Failed Mage Student" ? 5 : 0);
        Player.Research.Progress += gain;
        Player.Xp += Player.ActivityRewardXp;
        if (Player.Research.Field == "Forbidden Necromancy" || Player.Research.IsForbidden)
        {
            World.MagicInstability += Percent(35) ? 1 : 0;
            if (Percent(10)) Player.EmotionalScars.Add(new EmotionalScar { Name = "Forbidden whispers", Intensity = _random.Next(8, 22), DaysRemaining = _random.Next(12, 45), Description = "Some pages keep reading back." });
        }
        AddJournal($"Research progresses in {Player.Research.Field}: +{gain}%. The notes are probably meaningful. Maybe even on purpose.");
    }

    private void FinishPetCare()
    {
        if (Player.PetsMounts.Count(p => p.IsAlive) == 0 && Percent(65))
        {
            bool mount = Percent(35 + Player.StableTier * 8);
            var pet = new PetMount
            {
                Species = mount ? Pick(new[] { "Horse", "Mule", "Stag", "Goat" }) : Pick(new[] { "Dog", "Raven", "Fox", "Owl", "Cat", "Little Dragon" }),
                Name = Pick(new[] { "Moss", "Lantern", "Pickle", "Comet", "Biscuit", "Thistle", "Pebble", "Orra", "Noodle" }),
                IsMount = mount,
                Bond = _random.Next(15, 38),
                Utility = _random.Next(4, 12) + Player.StableTier,
                Quirk = Pick(new[] { "judges strangers", "steals bread", "hates rain", "knows shortcuts", "bites ghosts", "snores like thunder" })
            };
            Player.PetsMounts.Add(pet);
            Player.PetsMet++;
            AddTimeline($"Met animal companion: {pet.Name}.");
            AddJournal($"Animal companion: {pet.Summary}. The road immediately becomes at least 12% better.");
        }
        else
        {
            foreach (var pet in Player.PetsMounts.Where(p => p.IsAlive)) { pet.Bond += _random.Next(2, 7); pet.Utility += Percent(20) ? 1 : 0; }
            Player.Morale += 4;
            AddJournal("Animal care ends with cleaner tack, fuller bowls, and at least one creature pretending not to enjoy affection.");
        }
    }

    private void FinishNemesisEncounter()
    {
        var nemesis = World.Nemeses.FirstOrDefault(n => n.Name == Player.ActivityArc && n.IsActive && !n.IsDefeated);
        if (nemesis == null) { FinishRiskyActivity("quest"); return; }
        Player.NemesisEncounters++;
        int danger = EffectiveDanger(Player.ActivityDanger);
        int roll = _random.Next(1, 101) + Player.Attack + Player.Defense + Player.SurvivalBonus + Player.Luck / 2 + LongLifeStabilityBonus() / 2;
        bool win = roll >= 42 + danger + DifficultyDangerModifier() / 2;
        if (win)
        {
            nemesis.Threat -= _random.Next(12, 28);
            nemesis.Grudge += _random.Next(2, 8);
            Player.Gold += Player.ActivityRewardGold;
            Player.Xp += Player.ActivityRewardXp;
            Player.Reputation += 5;
            Player.TotalGoldEarned += Player.ActivityRewardGold;
            nemesis.Encounters.Add($"Defeated by {Player.Name} in Year {CurrentYear()}, but hatred is renewable.");
            if (nemesis.Threat <= 5 || Percent(18 + Player.Level))
            {
                nemesis.IsDefeated = true;
                nemesis.IsActive = false;
                Player.TrophyCount++;
                AddTimeline($"Nemesis defeated: {nemesis.Name}.");
                AddWorldHistory("Nemesis", $"{Player.Name} ended the threat of {nemesis.Name}.");
                AddMemoryTag("nemesis defeated: " + nemesis.Name);
                AddCauseThread($"{Player.Name} ended {nemesis.Name}'s threat; roads near {nemesis.LastSeen} should remember.");
                AddJournal($"Nemesis defeated: {nemesis.Name}. The road exhales. Somewhere, a very rude signature stops appearing.");
            }
            else AddJournal($"{Player.Name} wounds {nemesis.Name}'s plans, but the nemesis escapes. Of course they do.");
        }
        else
        {
            int damage = _random.Next(3, 15) + danger / 8;
            Player.CurrentHp -= damage;
            Player.Morale -= 4;
            nemesis.Threat += _random.Next(3, 10);
            nemesis.Grudge += _random.Next(4, 12);
            AddJournal($"Nemesis trouble: {nemesis.Name} turns the encounter ugly. HP -{damage}. Their grudge grows teeth.");
            if (Percent(20)) AddInjury(true, danger);
            CheckDeath(nemesis.Name + " finally landing a cruel enough blow");
        }
    }

    private void FinishRivalEncounter()
    {
        var rival = World.Rivals.FirstOrDefault(r => r.Name == Player.ActivityArc && r.IsAlive);
        if (rival == null) { FinishSocial(); return; }
        Player.RivalEncounters++;
        int roll = _random.Next(100);
        if (roll < 22)
        {
            rival.RelationshipToHero = "rival";
            rival.Fame += 3;
            Player.Morale -= 1;
            AddJournal($"{rival.Name} snatches credit for a small opportunity. Rivalry officially gets boots.");
        }
        else if (roll < 52)
        {
            rival.RelationshipToHero = "friendly rival";
            Player.Xp += 30 + rival.Level * 5;
            rival.Fame += 2;
            AddJournal($"{Player.Name} trades stories and techniques with {rival.Name}. XP rises. So does competitive tension.");
        }
        else if (roll < 76)
        {
            rival.RelationshipToHero = "ally";
            Player.Reputation += 2;
            if (Percent(20)) MaybeMeetCompanion();
            AddJournal($"{rival.Name} helps with a messy local problem. Not friendship exactly, but suspiciously adjacent.");
        }
        else
        {
            long gold = _random.Next(12, 45) + rival.Fame;
            Player.Gold += gold;
            Player.TotalGoldEarned += gold;
            rival.Fame += 1;
            AddJournal($"A shared job with {rival.Name} pays out. Gold +{gold}.");
        }
    }

    private int CompanionMeetChance()
    {
        int chance = 9 + Math.Max(0, Player.Reputation) / 6;
        if (Player.HasTrait("Charming")) chance += 10;
        if (Player.LifePhilosophy == "Trust Companions") chance += 18;
        if (Player.Companions.Count(c => c.IsActive) >= 4) chance -= 15;
        return Math.Clamp(chance, 2, 45);
    }

    private int EffectiveDanger(int baseDanger)
    {
        int danger = baseDanger + DifficultyDangerModifier() + PhilosophyDangerModifier();
        if (Player.Weather is "Storm" or "Snow" or "Sleet" or "Heatwave") danger += 3;
        if (Player.Weather is "Fog" or "Cold Wind" or "Dry Wind") danger += 1;
        if (Player.Season == "Winter") danger += 2;
        if (World.RoadSafety < 30 && Player.ActivityType == "Travel") danger += 4;
        if (World.MonsterPressure > 60) danger += 3;
        if (World.BanditPower > 60 && (Player.ActivityType is "Travel" or "Quest")) danger += 3;
        if (Player.Hunger > 70) danger += 3;
        if (Player.Energy < 30) danger += 4;
        if (Player.Morale < 25) danger += 2;
        if (Player.HasTrait("Lucky")) danger -= 5;
        if (Player.HasTrait("Reckless")) danger += 3;
        if (Player.HasTrait("Cowardly")) danger -= 5;
        return Math.Max(0, danger);
    }

    private void ProgressArcOnSuccess(string label, bool heroic)
    {
        StoryArc? arc = null;
        if (!string.IsNullOrWhiteSpace(Player.ActivityArc)) arc = Player.StoryArcs.FirstOrDefault(a => !a.IsResolved && a.Name == Player.ActivityArc);
        arc ??= Player.StoryArcs.Where(a => !a.IsResolved).OrderByDescending(a => a.Progress).FirstOrDefault();
        if (arc == null) return;
        int gain = label == "story arc" ? _random.Next(12, 26) : label == "legendary expedition" ? _random.Next(8, 18) : _random.Next(1, 7);
        if (heroic) gain += 8;
        arc.Progress = Math.Clamp(arc.Progress + gain, 0, 100);
        arc.Threat = Math.Clamp(arc.Threat - _random.Next(1, 5), 0, 100);
        if (arc.Progress >= 100) ResolveArc(arc, heroic);
    }

    private void ProgressArcOnFailure(bool disaster)
    {
        var arc = Player.StoryArcs.Where(a => !a.IsResolved).OrderByDescending(a => a.Threat).FirstOrDefault();
        if (arc == null) return;
        arc.Threat = Math.Clamp(arc.Threat + (disaster ? _random.Next(5, 12) : _random.Next(1, 5)), 0, 100);
        if (disaster) arc.Progress = Math.Max(0, arc.Progress - _random.Next(0, 5));
    }

    private void ResolveRumorIfNeeded(bool success)
    {
        if (string.IsNullOrWhiteSpace(Player.ActivityRumor)) return;
        var rumor = Player.Rumors.FirstOrDefault(r => !r.IsResolved && r.Title == Player.ActivityRumor);
        if (rumor == null) return;
        rumor.IsResolved = true;
        if (success)
        {
            Player.Reputation += 2;
            if (!string.IsNullOrWhiteSpace(rumor.Faction)) Player.AddFaction(rumor.Faction, 3);
        }
    }

    private void MaybeCreateRumor(string source)
    {
        if (Player.Rumors.Count(r => !r.IsResolved) >= 10) return;
        var location = CurrentLocation();
        string title = Pick(location.RumorSeeds.Length > 0 ? location.RumorSeeds : new[] { "something strange nearby" });
        if (Player.Rumors.Any(r => !r.IsResolved && r.Title == title)) return;
        var rumor = new Rumor
        {
            Title = title,
            Location = location.Name,
            Faction = Pick(_factions),
            Danger = Math.Max(4, location.Danger + _random.Next(-4, 15)),
            Reward = location.Reward + _random.Next(12, 60) + Player.Level * 5
        };
        Player.Rumors.Add(rumor);
        if (source != "daily gossip" || Percent(35)) AddJournal($"A rumor surfaces from {source}: {title} in {location.Name}.");
    }

    private void MaybeMeetCompanion()
    {
        if (Player.Companions.Count(c => c.IsActive) >= 5) return;
        string role = Pick(new[] { "Healer", "Knight", "Rogue", "Mage", "Ranger", "Dog", "Merchant", "Bodyguard" });
        string name = role == "Dog" ? Pick(new[] { "Biscuit", "Moss", "Lantern", "Pickle", "Comet" }) : Pick(new[] { "Mira", "Kael", "Tovin", "Sera", "Nell", "Orin", "Vessa", "Pip", "Iris", "Hale", "Maer" });
        if (Player.Companions.Any(c => c.IsActive && c.Name == name)) name += " " + _random.Next(2, 99);
        var companion = new Companion
        {
            Name = name,
            Role = role,
            Loyalty = _random.Next(42, 74) + (Player.HasTrait("Charming") ? 8 : 0),
            Bond = _random.Next(5, 24),
            PersonalArc = Pick(new[]
            {
                "is searching for someone they will not name",
                "owes money to the wrong kind of people",
                "laughs too easily when afraid",
                "keeps a sealed letter close",
                "trusts slowly and leaves quickly"
            })
        };
        Player.Companions.Add(companion);
        Player.CompanionsMet++;
        AddTimeline($"Met companion: {companion.Name}, {companion.Role}.");
        AddJournal($"{Player.Name} meets {companion.Name}, a {companion.Role.ToLowerInvariant()} who {companion.PersonalArc}. They join the road, at least for now.");
    }

    private void CompanionTrouble()
    {
        var companion = Player.Companions.Where(c => c.IsActive).OrderBy(_ => _random.Next()).FirstOrDefault();
        if (companion == null) return;
        int roll = _random.Next(100);
        if (roll < 25)
        {
            companion.Loyalty -= _random.Next(6, 18);
            Player.Morale -= 2;
            AddJournal($"A hard argument with {companion.Name} leaves the camp colder. Loyalty drops.");
        }
        else if (roll < 46)
        {
            companion.Bond += _random.Next(3, 9);
            Player.CurrentHp += _random.Next(2, 8);
            AddJournal($"{companion.Name} helps at exactly the right moment. Bond rises. The road gets a little less lonely.");
        }
        else if (roll < 62)
        {
            companion.IsActive = false;
            Player.CompanionsLost++;
            AddTimeline($"Lost companion: {companion.Name}.");
            AddMemoryTag("companion lost: " + companion.Name);
            AddCauseThread($"{companion.Name} was lost because the road turned cruel near {Player.Location}.");
            AddJournal($"The trouble costs the party {companion.Name}. The journal leaves space where the name used to be.");
        }
        else
        {
            companion.Loyalty += _random.Next(1, 7);
            companion.Bond += _random.Next(1, 6);
            AddJournal($"Campfire honesty with {companion.Name} changes something small and permanent.");
        }
    }

    private void AddInjury(bool severe, int danger)
    {
        var templates = new[]
        {
            new Injury { Name = "Sprained ankle", Description = "Travel gets slower and meaner.", DaysRemaining = _random.Next(5, 16), SurvivalPenalty = 3 },
            new Injury { Name = "Broken ribs", Description = "Breathing is now a scheduled enemy.", DaysRemaining = _random.Next(10, 26), HpPenalty = 8, DefensePenalty = 3 },
            new Injury { Name = "Infected cut", Description = "A small wound starts negotiating with mortality.", DaysRemaining = _random.Next(7, 22), HpPenalty = 6, SurvivalPenalty = 4 },
            new Injury { Name = "Concussion", Description = "Decisions arrive wearing fog.", DaysRemaining = _random.Next(4, 14), AttackPenalty = 3, SurvivalPenalty = 5 },
            new Injury { Name = "Burn scar", Description = "It hurts, but it looks like a story.", DaysRemaining = _random.Next(12, 32), DefensePenalty = 2 },
            new Injury { Name = "Damaged hand", Description = "Gear feels heavier and locks feel smug.", DaysRemaining = _random.Next(8, 24), AttackPenalty = 4 }
        };
        var injury = templates[_random.Next(templates.Length)];
        if (severe && Percent(Math.Clamp(8 + danger / 7 - Player.InfirmaryTier * 3 - LongLifeStabilityBonus() / 8, 1, 30)))
        {
            injury.IsPermanent = true;
            injury.DaysRemaining = 0;
            injury.Description += " It may never fully heal.";
        }
        Player.Injuries.Add(injury);
        Player.Morale -= severe ? 5 : 2;
        AddTimeline($"Injury: {injury.Name}.");
        AddMemoryTag("injury: " + injury.Name);
        AddJournal($"Injury gained: {injury.Name}. {injury.Description}");
    }

    private int LegendaryEventChance()
    {
        int chance = 1;
        if (CurrentYear() >= 2) chance += 1;
        if (Player.LifePhilosophy == "Pursue Legends") chance += 3;
        if (Player.Location == "Starfall Keep") chance += 4;
        if (Player.HasTrait("Haunted") || Player.HasTrait("Lucky")) chance += 1;
        return Math.Clamp(chance, 0, 9);
    }

    private void MaybeLegendaryEvent()
    {
        if (!Player.IsAlive || Player.IsRetired) return;
        if (Player.StoryDay < 120 && Player.Difficulty != "Cozy Chronicle") return;
        Player.LegendaryEventsSeen++;
        if (Percent(18 + Player.Artifacts.Count * 2)) { FindOrAwakenArtifact(); return; }
        if (!Player.IsImmortal && CurrentYear() >= 8 && Percent(10 + Player.MythicPathProgress / 5)) { TryMythicPath(); return; }
        int roll = _random.Next(100);
        if (roll < 18)
        {
            Player.Luck += 3;
            Player.Morale += 8;
            AddTimeline("Legendary event: talking sword dream.");
            AddJournal("A sword speaks in a dream and gives advice that is either prophecy or sleep poisoning. Luck rises anyway.");
        }
        else if (roll < 34)
        {
            Player.Gold += 120;
            Player.TotalGoldEarned += 120;
            AddTimeline("Legendary event: hidden city found.");
            AddJournal($"{Player.Name} finds a hidden city for one impossible afternoon. The coins remain after the streets vanish.");
        }
        else if (roll < 50)
        {
            var companion = Player.Companions.FirstOrDefault(c => c.IsActive);
            if (companion != null)
            {
                companion.Bond += 14;
                companion.Loyalty += 10;
                AddTimeline($"Legendary bond: {companion.Name}.");
                AddJournal($"A dangerous omen passes over the camp. {companion.Name} stays. Something between them becomes harder to break.");
            }
        }
        else if (roll < 66)
        {
            World.MagicInstability += 8;
            Player.Xp += 120;
            AddTimeline("Legendary event: another realm.");
            AddJournal($"{Player.Name} is lost in another realm for a stretch of impossible hours. The journal's ink smells like stars afterward.");
        }
        else if (roll < 82)
        {
            Player.Reputation += 10;
            World.RoadSafety += 5;
            AddTimeline("Legendary event: saved a town from winter starvation.");
            AddJournal($"A starving town survives because {Player.Name} was in the right place with the right stubbornness. Reputation rises hard.");
        }
        else
        {
            int danger = EffectiveDanger(70 + _random.Next(0, 30));
            Player.CurrentHp -= _random.Next(5, 18);
            AddTimeline("Legendary event: dragon sighting.");
            AddJournal($"A dragon passes low enough to turn courage into a theoretical concept. {Player.Name} survives the sighting. Barely.");
            TryCheatDeath("a legendary dragon omen", danger);
        }
        World.Clamp();
    }


    private void FindOrAwakenArtifact()
    {
        Artifact artifact;
        var lost = World.WorldArtifacts.Where(a => a.IsLost || a.CurrentHolder is "Lost" or "Unknown").OrderBy(_ => _random.Next()).FirstOrDefault();
        if (lost != null)
        {
            artifact = lost;
            artifact.IsLost = false;
            artifact.CurrentHolder = Player.Name;
            World.WorldArtifacts.Remove(lost);
        }
        else
        {
            artifact = new Artifact
            {
                Name = Pick(new[] { "Saint Orra's Bell", "The Foxglass Ring", "The Black Lantern", "Mayflower Crown", "Ashen Compass", "Lantern-Bone Knife", "Star-Salt Cloak" }),
                Kind = Pick(new[] { "Weapon", "Armor", "Relic", "Relic", "Tool" }),
                Power = Pick(new[] { "improves survival during bad weather", "protects against a single disaster", "speaks during dreams", "turns grief into luck", "makes roads shorter but stranger" }),
                PowerLevel = _random.Next(1, 5) + Player.Level / 10,
                IsCursed = Percent(22),
                CurrentHolder = Player.Name
            };
        }
        artifact.History.Add($"Claimed by {Player.Name} in Year {CurrentYear()} near {Player.Location}.");
        Player.Artifacts.Add(artifact);
        Player.ArtifactsFound++;
        AddTimeline($"Artifact found: {artifact.Name}.");
        AddWorldHistory("Artifact", $"{Player.Name} claimed {artifact.Name}.");
        AddMemoryTag("artifact: " + artifact.Name);
        AddCauseThread($"{artifact.Name} entered {Player.Name}'s story in {Player.Location}.");
        AddJournal($"Artifact found: {artifact.Summary}. This is how sensible people get dragged into legends.");
    }

    private void TryMythicPath()
    {
        Player.MythicPathProgress += _random.Next(12, 28);
        string path = Pick(new[] { "Temple-Blessed", "Dragon-Blooded", "Forest Guardian", "Archmage of Slow Years", "Lantern-Bound", "Cursed Undying" });
        if (Player.MythicPathProgress >= 100)
        {
            Player.IsImmortal = true;
            Player.ImmortalityPath = path;
            Player.MythicPathProgress = 100;
            Player.Luck += 10;
            Player.Morale += 12;
            AddTimeline($"Mythic path completed: {path}.");
            AddWorldHistory("Myth", $"{Player.Name} became {path}, stepping beyond ordinary aging.");
            AddJournal($"Mythic transformation: {Player.Name} becomes {path}. Death is not gone, but age has lost the argument.");
        }
        else
        {
            AddJournal($"Mythic path stirs: {path}. Progress reaches {Player.MythicPathProgress}%. The hero is still mortal, but the story is clearly flirting with cheating.");
        }
    }

    private void LevelUpIfNeeded()
    {
        while (Player.Xp >= Player.XpToNextLevel)
        {
            Player.Xp -= Player.XpToNextLevel;
            Player.Level++;
            Player.XpToNextLevel = (long)Math.Round(Player.XpToNextLevel * 1.28 + 45);
            Player.CurrentHp = Player.MaxHp;
            Player.Energy += 12;
            Player.Morale += 4;
            AddTimeline($"Reached level {Player.Level}.");
            AddJournal($"Level up! {Player.Name} reaches level {Player.Level}. For one shining second, competence seems possible.");
        }
    }

    private void TryCheatDeath(string reason, int danger)
    {
        if (Player.CurrentHp > 0) return;
        if (TryLayeredRescue(reason, danger)) return;
        if (Player.Difficulty == "Iron Fate" && Player.NearDeaths > 5 && Percent(45)) return;

        int chance = 48 + CheatDeathBonus() + Player.Level * 2 + Player.Luck / 2 + Player.SurvivalBonus + LongLifeStabilityBonus() - danger / 2;
        chance += Player.Companions.Count(c => c.IsActive) * 8;
        if (Player.LifePhilosophy == "Seek Safety") chance += 8;
        if (Player.HasTrait("Stubborn")) chance += 10;
        chance = Math.Clamp(chance, Player.Difficulty == "Iron Fate" ? 10 : 30, Player.Difficulty == "Cozy Chronicle" ? 99 : 96);
        if (!Percent(chance)) return;
        Player.CurrentHp = _random.Next(8, Math.Max(18, 30 + Player.Level * 2));
        Player.NearDeaths++;
        Player.RescueLayersUsed++;
        Player.Morale -= _random.Next(0, 5);
        Player.Energy = Math.Max(Player.Energy, 32);
        Player.Hunger = Math.Min(Player.Hunger, 74);
        if (Percent(13)) AddInjury(true, danger);
        AddMemoryTag("near death: " + reason);
        AddCauseThread($"{Player.Name} nearly died because {reason}, then learned to retreat earlier.");
        StartEmergencyRetreat("death came close enough to smell the campfire");
        AddJournal($"Death gets close after {reason}, but not close enough. {Player.Name} survives at {Player.CurrentHp} HP. The longer this life goes, the better the hero gets at refusing dramatic endings.");
    }

    private bool TryLayeredRescue(string reason, int danger)
    {
        if (Player.CurrentHp > 0) return true;

        var bondedCompanion = Player.Companions.Where(c => c.IsActive).OrderByDescending(c => c.Bond + c.Loyalty).FirstOrDefault();
        if (bondedCompanion != null && Percent(18 + bondedCompanion.Bond / 3 + bondedCompanion.Loyalty / 5))
        {
            Player.CurrentHp = _random.Next(10, 28) + Player.Level;
            Player.Energy = Math.Max(Player.Energy, 26);
            bondedCompanion.Bond = Math.Clamp(bondedCompanion.Bond + 3, 0, 100);
            Player.NearDeaths++;
            Player.RescueLayersUsed++;
            AddMemoryTag("near death rescued by companion");
            AddCauseThread($"{bondedCompanion.Name} saved {Player.Name} from {reason}.");
            StartEmergencyRetreat($"{bondedCompanion.Name} dragged the hero out before the ending could finish its sentence");
            AddJournal($"Layered rescue: {bondedCompanion.Name} refuses to let {Player.Name} die after {reason}. Bond rises. The road looks embarrassed.");
            return true;
        }

        if (Player.Faith.Blessing != "None" && Player.Faith.BlessingDaysRemaining > 0 && Percent(20 + Player.Faith.Favor / 3))
        {
            Player.CurrentHp = _random.Next(12, 34) + Player.ShrineTier * 3;
            Player.Faith.BlessingDaysRemaining = 0;
            Player.Faith.Favor -= 8;
            Player.NearDeaths++;
            Player.RescueLayersUsed++;
            AddMemoryTag("near death divine rescue");
            AddCauseThread($"{Player.Faith.God} spent a blessing to keep {Player.Name} alive after {reason}.");
            StartEmergencyRetreat("a blessing burned bright enough to buy one more morning");
            AddJournal($"Layered rescue: {Player.Faith.God}'s blessing breaks over {Player.Name} after {reason}. The miracle is not tidy, but it works.");
            return true;
        }

        var artifact = Player.Artifacts.Where(a => !a.IsLost).OrderByDescending(a => a.PowerLevel).FirstOrDefault();
        if (artifact != null && Percent(12 + artifact.PowerLevel * 4 + (artifact.IsCursed ? 7 : 0)))
        {
            Player.CurrentHp = _random.Next(8, 24) + artifact.PowerLevel * 2;
            Player.Morale -= artifact.IsCursed ? 8 : 2;
            artifact.History.Add($"Saved {Player.Name} from {reason} in Year {CurrentYear()}.");
            Player.NearDeaths++;
            Player.RescueLayersUsed++;
            AddMemoryTag("artifact rescue: " + artifact.Name);
            AddCauseThread($"{artifact.Name} changed the outcome of {reason}.");
            StartEmergencyRetreat($"{artifact.Name} cheated the ending in a way nobody should trust");
            AddJournal($"Layered rescue: {artifact.Name} wakes at the worst possible moment and keeps {Player.Name} alive. This is comforting only if you ignore the humming.");
            return true;
        }

        if (Player.IsImmortal && Percent(35 + Player.MythicPathProgress / 2))
        {
            Player.CurrentHp = _random.Next(18, 45);
            Player.NearDeaths++;
            Player.RescueLayersUsed++;
            AddMemoryTag("immortal recovery");
            StartEmergencyRetreat("the mythic path refused to accept the paperwork");
            AddJournal($"Layered rescue: {Player.ImmortalityPath} pulls {Player.Name} back from {reason}. Death loses another argument.");
            return true;
        }

        if (Player.GuildHallTier >= 3 && (Player.Location is "Brindlewick" or "Riverglass Port") && Percent(14 + Player.InfirmaryTier * 5))
        {
            Player.CurrentHp = _random.Next(10, 30) + Player.InfirmaryTier * 4;
            Player.NearDeaths++;
            Player.RescueLayersUsed++;
            AddMemoryTag("guild hall rescue");
            StartEmergencyRetreat("guild hands and infirmary lamps found the hero in time");
            AddJournal($"Layered rescue: the guild hall network catches {Player.Name} after {reason}. Investing in safety suddenly looks very smug.");
            return true;
        }

        return false;
    }

    private void CheckDeath(string cause)
    {
        if (!Player.IsAlive || Player.IsRetired || Player.CurrentHp > 0) return;
        TryCheatDeath(cause, EffectiveDanger(Player.ActivityDanger));
        if (Player.CurrentHp > 0) return;
        EndLife("Death", cause);
    }

    private void EndLife(string endType, string cause)
    {
        Player.IsAlive = endType != "Death";
        Player.IsRetired = endType == "Retirement";
        Player.CauseOfEnd = cause;
        Player.FinalTitle = MakeFinalTitle(endType);
        AddTimeline($"{endType}: {Player.FinalTitle}.");
        AddJournal(endType == "Death"
            ? $"{Player.Name}'s story ends in {Player.Location}: {cause}. Final title: {Player.FinalTitle}. Score {Player.SurvivalScore}."
            : $"{Player.Name}'s adventuring life closes in {Player.Location}: {cause}. Final title: {Player.FinalTitle}. Score {Player.SurvivalScore}.");
        UpdateBloodlineFromHero();
        AddLegacyEntry(endType);
        AddWorldHistory(endType, $"{Player.Name}, {Player.FinalTitle}, ended a chapter in {Player.Location}: {cause}");

        if (endType == "Death" && ContinueAsChildAfterDeath(cause))
        {
            _isPaused = false;
            if (_saveData.Settings.AutoBackups) _saveService.CreateBackup(_saveData, "Heir");
            SaveGame(false);
            return;
        }

        if (_saveData.Settings.PauseOnDeath) _isPaused = true;
        if (_saveData.Settings.AutoBackups) _saveService.CreateBackup(_saveData, endType);
        SaveGame(false);
    }

    private string MakeFinalTitle(string endType)
    {
        if (endType == "Retirement" && Player.GuildHallTier >= 4) return "The Guildheart";
        if (endType == "Retirement" && Player.Gold >= 1500) return "The Coin-Safe Legend";
        if (Player.IsImmortal) return Player.ImmortalityPath;
        if (Player.StoryDay >= 7200) return "The Endless Road";
        if (Player.StoryDay >= 3600) return "The Decade-Worn Legend";
        if (Player.StoryDay >= 1800) return "The Five-Year Flame";
        if (Player.LegendaryEventsSeen >= 6) return "The Myth-Touched";
        if (Player.StoryArcs.Count(a => a.IsResolved) >= 3) return "The Arc-Ender";
        if (Player.Companions.Any(c => c.IsActive && c.Bond >= 90)) return "The Sworn Friend";
        if (Player.GuildHallTier >= 3) return "The Hall-Builder";
        if (Player.QuestsCompleted >= 30) return "The Contract-Bound Legend";
        if (Player.StoryDay >= 720) return "The Road-Rooted Survivor";
        if (Player.Location == "Starfall Keep") return "The Star-Touched Fool";
        if (Player.Reputation >= 35) return "The Lantern-Bearer";
        if (Player.NearDeaths >= 4) return "The One Who Kept Crawling";
        if (Player.HasTrait("Kindhearted")) return "The Gentle Fool";
        return "The Road-Worn";
    }

    private void AddLegacyEntry(string endType)
    {
        if (_legacySavedForThisEnd) return;
        _saveData.HallOfLegends.Add(new LegacyEntry
        {
            Name = Player.Name,
            Title = Player.FinalTitle,
            EndType = endType,
            CauseOfEnd = Player.CauseOfEnd,
            FinalLocation = Player.Location,
            Background = Player.Background,
            Traits = string.Join(", ", Player.Traits),
            Generation = Player.Generation,
            DaysSurvived = Math.Max(0, Player.StoryDay - 1),
            Level = Player.Level,
            AgeYears = Player.AgeYears,
            BloodlineName = Player.BloodlineName,
            HeirName = Player.HeirName,
            ImmortalityPath = Player.ImmortalityPath,
            Artifacts = string.Join(", ", Player.Artifacts.Where(a => !a.IsLost).Select(a => a.Name)),
            Pets = string.Join(", ", Player.PetsMounts.Where(p => p.IsAlive).Select(p => p.Name)),
            Score = Player.SurvivalScore,
            QuestsCompleted = Player.QuestsCompleted,
            CompanionsMet = Player.CompanionsMet,
            StorySummary = BuildLifeStoryText(shortVersion: true),
            EndedUtc = DateTime.UtcNow
        });
        _saveData.HallOfLegends = _saveData.HallOfLegends.OrderByDescending(l => l.Score).ThenByDescending(l => l.DaysSurvived).Take(80).ToList();
        _legacySavedForThisEnd = true;
    }

    private WorldLocation CurrentLocation() => GetLocation(Player.Location) ?? _locations.First(l => l.Name == "Brindlewick");
    private WorldLocation? GetLocation(string name) => _locations.FirstOrDefault(l => string.Equals(l.Name, name, StringComparison.OrdinalIgnoreCase));
    private string Pick(IReadOnlyList<string> items) => items[_random.Next(items.Count)];
    private bool Percent(int chance) => _random.Next(100) < Math.Clamp(chance, 0, 100);
    private int SafeInt(long value) => (int)Math.Clamp(value, 0, int.MaxValue);
    private void SpendGold(int amount) => Player.Gold = Math.Max(0, Player.Gold - Math.Max(0, amount));

    private int CurrentYear() => ((Math.Max(1, Player.StoryDay) - 1) / 360) + 1;
    private int DayOfYear() => ((Math.Max(1, Player.StoryDay) - 1) % 360) + 1;

    private string FormatSurvivedTime()
    {
        int days = Math.Max(0, Player.StoryDay - 1);
        int years = days / 360;
        int rem = days % 360;
        return years <= 0 ? $"{days} day{(days == 1 ? "" : "s")}" : $"{years} year{(years == 1 ? "" : "s")}, {rem} day{(rem == 1 ? "" : "s")}";
    }

    private string FormatDuration(int minutes)
    {
        if (minutes < 60) return minutes == 1 ? "1 minute" : $"{minutes} minutes";
        int days = minutes / 1440;
        int hours = (minutes % 1440) / 60;
        int mins = minutes % 60;
        var parts = new List<string>();
        if (days > 0) parts.Add(days == 1 ? "1 day" : $"{days} days");
        if (hours > 0) parts.Add(hours == 1 ? "1 hour" : $"{hours} hours");
        if (mins > 0 && days == 0) parts.Add(mins == 1 ? "1 minute" : $"{mins} minutes");
        return parts.Count == 0 ? "0 minutes" : string.Join(", ", parts);
    }



    private void UpdateStatsAndAchievements()
    {
        if (Player.StoryDay % 7 == 0 && (_saveData.StatHistory.Count == 0 || _saveData.StatHistory.Last().StoryDay != Player.StoryDay))
        {
            int hpPercent = Player.MaxHp <= 0 ? 0 : (int)Math.Round(Player.CurrentHp * 100.0 / Player.MaxHp);
            int danger = Math.Clamp(World.BanditPower / 3 + World.MonsterPressure / 3 + World.Plague / 4 + World.WarTension / 5 + World.MagicInstability / 6, 0, 100);
            int townSafety = World.Towns.Count == 0 ? World.RoadSafety : (int)Math.Round(World.Towns.Where(t => !t.IsDestroyed).DefaultIfEmpty(new TownRecord()).Average(t => t.Safety));
            _saveData.StatHistory.Add(new StatSnapshot
            {
                Year = CurrentYear(),
                Day = DayOfYear(),
                StoryDay = Player.StoryDay,
                Level = Player.Level,
                Score = Player.SurvivalScore,
                Gold = Player.Gold,
                HpPercent = Math.Clamp(hpPercent, 0, 100),
                WorldDanger = danger,
                TownSafety = Math.Clamp(townSafety, 0, 100),
                Companions = Player.Companions.Count(c => c.IsActive),
                Artifacts = Player.Artifacts.Count(a => !a.IsLost),
                QuestsCompleted = Player.QuestsCompleted
            });
            while (_saveData.StatHistory.Count > 520) _saveData.StatHistory.RemoveAt(0);
        }

        EnsureAchievementSeeds();
        foreach (var achievement in _saveData.Achievements)
        {
            achievement.Progress = AchievementProgress(achievement.Id);
            if (!achievement.Unlocked && achievement.Progress >= achievement.Target)
            {
                achievement.Unlocked = true;
                achievement.UnlockedUtc = DateTime.UtcNow;
                AddJournal($"Achievement unlocked: {achievement.Name}. {achievement.Description}");
                NotifyMajor("Achievement unlocked", achievement.Name);
            }
        }
    }

    private int AchievementProgress(string id)
    {
        return id switch
        {
            "survive_1_year" => Math.Max(0, (Player.StoryDay - 1) / 360),
            "survive_10_years" => Math.Max(0, (Player.StoryDay - 1) / 360),
            "first_retirement" => _saveData.HallOfLegends.Count(l => l.EndType == "Retirement") + (Player.IsRetired ? 1 : 0),
            "first_artifact" => Player.ArtifactsFound + _saveData.HallOfLegends.Count(l => !string.IsNullOrWhiteSpace(l.Artifacts)),
            "first_pet" => Player.PetsMet + _saveData.HallOfLegends.Count(l => !string.IsNullOrWhiteSpace(l.Pets)),
            "town_destroyed" => World.Towns.Count(t => t.IsDestroyed),
            "become_immortal" => Player.IsImmortal ? 1 : _saveData.HallOfLegends.Count(l => l.ImmortalityPath != "Mortal"),
            "bloodline_3" => Math.Max(Player.Generation, World.Bloodlines.Count == 0 ? 1 : World.Bloodlines.Max(b => b.GenerationCount)),
            "defeat_nemesis" => World.Nemeses.Count(n => n.IsDefeated),
            "live_100_years" => Math.Max(Player.AgeYears, _saveData.HallOfLegends.Count == 0 ? 0 : _saveData.HallOfLegends.Max(l => l.AgeYears)),
            "world_500_years" => CurrentYear(),
            "rescued_10" => Player.RescueLayersUsed,
            _ => 0
        };
    }

    private void AddMemoryTag(string tag)
    {
        if (string.IsNullOrWhiteSpace(tag)) return;
        tag = tag.Trim();
        if (!Player.MemoryTags.Contains(tag, StringComparer.OrdinalIgnoreCase))
            Player.MemoryTags.Add(tag);
        while (Player.MemoryTags.Count > 80) Player.MemoryTags.RemoveAt(0);
    }

    private void AddCauseThread(string thread)
    {
        if (string.IsNullOrWhiteSpace(thread)) return;
        Player.CauseEffectThreads.Add(thread.Trim());
        while (Player.CauseEffectThreads.Count > 80) Player.CauseEffectThreads.RemoveAt(0);
    }

    private void MaybeMemoryCallback()
    {
        if (Player.MemoryTags.Count == 0 || !Percent(4)) return;
        string tag = Pick(Player.MemoryTags);
        string callback = tag switch
        {
            var t when t.Contains("near death", StringComparison.OrdinalIgnoreCase) => $"For no obvious reason, {Player.Name} checks the exits twice today. The body remembers almost dying before the mind admits it.",
            var t when t.Contains("companion lost", StringComparison.OrdinalIgnoreCase) => $"A familiar laugh in a market crowd makes {Player.Name} turn too quickly. It is not the person the road took.",
            var t when t.Contains("artifact", StringComparison.OrdinalIgnoreCase) => $"The artifact feels warm for one impossible second, as if it remembers a choice {Player.Name} has not made yet.",
            var t when t.Contains("town", StringComparison.OrdinalIgnoreCase) => $"News from a wounded town changes the shape of the day. Old consequences do not stay buried politely.",
            _ => $"An old memory returns: {tag}. The road has excellent timing and terrible manners."
        };
        AddJournal(callback);
    }

    private void NotifyMajor(string title, string message)
    {
        if (_saveData.Settings.SoundEnabled)
        {
            try { System.Media.SystemSounds.Asterisk.Play(); } catch { }
        }
        if (_trayIcon == null || !_saveData.Settings.MajorNotifications) return;
        try
        {
            _trayIcon.BalloonTipTitle = title;
            _trayIcon.BalloonTipText = message.Length > 220 ? message[..220] + "..." : message;
            _trayIcon.ShowBalloonTip(2200);
        }
        catch { }
    }

    private void UpdateBloodlineFromHero()
    {
        var bloodline = World.Bloodlines.FirstOrDefault(b => b.Name == Player.BloodlineName);
        if (bloodline == null) { EnsureBloodlineForHero(); return; }
        bloodline.Reputation = Math.Clamp(bloodline.Reputation + Math.Max(0, Player.Reputation) / 50, -1000, 1000);
        bloodline.Wealth += Math.Max(0, SafeInt(Player.Gold / 50));
        bloodline.EstateTier = Math.Max(bloodline.EstateTier, Math.Max(Player.HomeTier, Player.GuildHallTier / 2));
        bloodline.EstateLocation = Player.Location;
        if (Player.FamilyMilestones > 0 && !bloodline.FamilyHistory.Any(h => h.Contains(Player.Name)))
            bloodline.FamilyHistory.Add($"{Player.Name} strengthened the line in Year {CurrentYear()}.");
        while (bloodline.FamilyHistory.Count > 60) bloodline.FamilyHistory.RemoveAt(0);
    }

    private void AddWorldHistory(string category, string text)
    {
        World.WorldHistory.Add(new WorldHistoryEntry { Year = CurrentYear(), Day = DayOfYear(), Category = category, Text = text });
        while (World.WorldHistory.Count > 240) World.WorldHistory.RemoveAt(0);
    }

    private void GrantBlessing()
    {
        Player.Faith.Blessing = Pick(new[] { "Gentle Mercy", "Road Ward", "Harvest Warmth", "Storm Nerve", "Forge Hand", "Moonlit Luck" });
        Player.Faith.BlessingDaysRemaining = _random.Next(12, 45);
        Player.Faith.Favor -= 20;
        AddJournal($"Blessing gained: {Player.Faith.Blessing} from {Player.Faith.God}. For a while, the road feels slightly less hostile.");
        AddTimeline($"Blessed by {Player.Faith.God}.");
    }

    private void AddJournal(string text, bool major = false)
    {
        if (string.IsNullOrWhiteSpace(text)) return;
        major = major || IsMajorJournal(text);
        if (!ShouldKeepJournal(text, major)) return;

        if (_saveData.Settings.JournalPacing == "Dramatic" && !major && Percent(10))
            text += " The journal marks it as a turning point.";

        string stamp = $"Year {CurrentYear()}, Day {DayOfYear()}, {Player.StoryHour:00}:{Player.StoryMinute:00}";
        _storyLog.Add($"[{stamp}] {text}");
        while (_storyLog.Count > 520) _storyLog.RemoveAt(0);
        _saveData.StoryLog = _storyLog.ToList();

        if (major)
        {
            AddStorybookLine(text);
            if (!text.Contains("Achievement unlocked", StringComparison.OrdinalIgnoreCase))
            {
                AddEventReplay("Major chronicle beat", new[]
                {
                    $"The day begins in {Player.Location} under {Player.Weather.ToLowerInvariant()} skies.",
                    text,
                    $"The hero's risk reads {CurrentDeathRiskLabel()} and the director mood is {World.DirectorMood}."
                }, "Recorded by the chronicle.");
            }
            NotifyMajor("Mayflower Idle RPG", text);
            if (_saveData.Settings.PauseOnMajorEvents && !text.Contains("Achievement unlocked", StringComparison.OrdinalIgnoreCase))
            {
                _isPaused = true;
                Player.MajorPauses++;
            }
        }
        if (_saveData.Settings.PauseOnLegendaryEvents && (text.Contains("Legendary", StringComparison.OrdinalIgnoreCase) || text.Contains("Artifact found", StringComparison.OrdinalIgnoreCase) || text.Contains("Mythic", StringComparison.OrdinalIgnoreCase)))
            _isPaused = true;
    }

    private bool IsMajorJournal(string text)
    {
        string t = text.ToLowerInvariant();
        return t.Contains("death") || t.Contains("retirement") || t.Contains("legendary") || t.Contains("artifact found") ||
               t.Contains("mythic") || t.Contains("nemesis defeated") || t.Contains("town") && t.Contains("ruin") ||
               t.Contains("achievement unlocked") || t.Contains("level up") || t.Contains("world event") || t.Contains("blessing gained") ||
               t.Contains("companion") && (t.Contains("lost") || t.Contains("leaves"));
    }

    private bool ShouldKeepJournal(string text, bool major)
    {
        if (major) return true;
        string pacing = _saveData.Settings?.JournalPacing ?? "Normal";
        return pacing switch
        {
            "Major Only" => false,
            "Quiet" => Percent(35),
            "Detailed" => true,
            "Dramatic" => true,
            _ => true
        };
    }

    private void AddTimeline(string text)
    {
        string stamp = $"Y{CurrentYear()} D{DayOfYear()}";
        Player.Timeline.Add($"[{stamp}] {text}");
        while (Player.Timeline.Count > 120) Player.Timeline.RemoveAt(0);
    }


    private void QueueLeaderboardUpload(string reason, bool force = false)
    {
        try
        {
            if (_saveData?.Settings == null || !_saveData.Settings.LeaderboardAutoUpload)
                return;

            if (_leaderboardSubmitInFlight)
                return;

            // Autosaves happen often. Keep the public board fresh without spamming Firebase.
            if (!force && DateTime.UtcNow - _lastLeaderboardSubmitUtc < TimeSpan.FromMinutes(5))
                return;

            var entry = BuildLeaderboardEntry(reason);
            _leaderboardSubmitInFlight = true;
            _lastLeaderboardSubmitUtc = DateTime.UtcNow;

            _ = Task.Run(async () =>
            {
                LeaderboardSubmitResult result;
                try
                {
                    result = await _leaderboardService.SubmitAsync(entry);
                }
                catch (Exception ex)
                {
                    result = new LeaderboardSubmitResult
                    {
                        Success = false,
                        Message = "Leaderboard upload failed: " + ex.Message
                    };
                }

                try
                {
                    await Dispatcher.InvokeAsync(() =>
                    {
                        _leaderboardSubmitInFlight = false;
                        _saveData.Settings.LastLeaderboardUploadUtc = result.WhenUtc;
                        _saveData.Settings.LastLeaderboardStatus = result.Message;
                        if (result.Success)
                        {
                            _lastLeaderboardSubmitUtc = DateTime.UtcNow;
                            if (SettingsText != null) SettingsText.Text = RenderSettingsText();
                        }
                        else
                        {
                            ReleaseDiagnostics.LogMessage(result.Message);
                        }
                    });
                }
                catch
                {
                    _leaderboardSubmitInFlight = false;
                }
            });
        }
        catch (Exception ex)
        {
            ReleaseDiagnostics.LogException(ex, "QueueLeaderboardUpload");
        }
    }

    private LeaderboardEntry BuildLeaderboardEntry(string reason)
    {
        string displayName = _saveData.Settings.LeaderboardDisplayName;
        if (string.IsNullOrWhiteSpace(displayName)) displayName = Player.Name;
        if (string.IsNullOrWhiteSpace(displayName)) displayName = "Mayflower Hero";

        int discoveredLocations = Math.Max(World.DiscoveredLocations?.Count ?? 0, _locations.Count);
        int score = CalculateLeaderboardScore(discoveredLocations);

        return new LeaderboardEntry
        {
            id = _saveData.Settings.LeaderboardInstallId,
            displayName = SafeLeaderboardText(displayName, 32),
            characterName = SafeLeaderboardText(Player.Name, 32),
            bloodlineName = SafeLeaderboardText(Player.BloodlineName, 32),
            location = SafeLeaderboardText(Player.Location, 40),
            status = Player.IsRetired ? "Retired" : Player.IsAlive ? "Alive" : "Ended",
            finalTitle = SafeLeaderboardText(CurrentLivingTitle(), 60),
            appVersion = SafeLeaderboardText(ReleaseDiagnostics.AppVersion, 24),
            uploadReason = SafeLeaderboardText(reason, 32),
            updatedAtUtc = DateTime.UtcNow.ToString("O"),
            score = score,
            level = Player.Level,
            generation = Player.Generation,
            ageYears = Player.AgeYears,
            storyDay = Player.StoryDay,
            currentYear = CurrentYear(),
            daysSurvived = Math.Max(1, Player.StoryDay),
            gold = Player.Gold,
            totalGoldEarned = Math.Max(Player.TotalGoldEarned, Player.Gold),
            reputation = Player.Reputation,
            questsCompleted = Player.QuestsCompleted,
            questsFailed = Player.QuestsFailed,
            adventuresSurvived = Player.AdventuresSurvived,
            artifactsFound = Player.ArtifactsFound,
            companionsMet = Player.CompanionsMet,
            generatedPlaces = Math.Max(0, World.WorldExpansionCount),
            worldExpansionCount = Math.Max(0, World.WorldExpansionCount),
            legendaryEventsSeen = Player.LegendaryEventsSeen
        };
    }

    private int CalculateLeaderboardScore(int discoveredLocations)
    {
        long raw = 0;
        raw += Player.Level * 1000L;
        raw += Math.Max(0, Player.Generation - 1) * 750L;
        raw += Math.Max(0, Player.StoryDay) * 12L;
        raw += Math.Max(0, Player.QuestsCompleted) * 250L;
        raw += Math.Max(0, Player.AdventuresSurvived) * 90L;
        raw += Math.Max(0, Player.ArtifactsFound) * 700L;
        raw += Math.Max(0, Player.LegendaryEventsSeen) * 900L;
        raw += Math.Max(0, Player.Reputation) * 15L;
        raw += Math.Max(0, discoveredLocations) * 180L;
        raw += Math.Max(0, World.WorldExpansionCount) * 320L;
        raw += Math.Max(0, Player.CompanionsMet) * 80L;
        raw += Math.Min(Math.Max(0, Player.TotalGoldEarned), 2_000_000) / 8L;
        raw -= Math.Max(0, Player.QuestsFailed) * 85L;
        return (int)Math.Clamp(raw, 0, int.MaxValue);
    }

    private static string SafeLeaderboardText(string? value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value)) return "Unknown";
        string clean = new string(value.Trim().Where(c => !char.IsControl(c)).ToArray());
        clean = clean.Replace("<", "").Replace(">", "");
        if (clean.Length > maxLength) clean = clean[..maxLength];
        return string.IsNullOrWhiteSpace(clean) ? "Unknown" : clean;
    }

    private void SaveGame(bool showMessage)
    {
        try
        {
            EnsureSaveData();
            _saveData.Settings.SaveSlot = _saveService.ActiveSlot;
            _saveData.Settings.JournalPacing = ComboText(PacingBox, _saveData.Settings.JournalPacing);
            _saveData.Settings.ThemeName = ComboText(ThemeBox, _saveData.Settings.ThemeName);
            _saveData.StoryLog = _storyLog.TakeLast(520).ToList();
            if (_saveData.Settings.AutoBackups && showMessage)
                _saveService.BackupCurrentSave("before_manual_save");

            if (_saveData.Settings.AutoBackups && (showMessage || DateTime.UtcNow - _lastBackupUtc > TimeSpan.FromMinutes(20)))
            {
                _saveService.CreateBackup(_saveData, showMessage ? "manual" : "autosave");
                _lastBackupUtc = DateTime.UtcNow;
            }
            _saveData.Settings.LastKnownAppVersion = ReleaseDiagnostics.AppVersion;
            _saveService.Save(_saveData);
            QueueLeaderboardUpload(showMessage ? "manual_save" : "autosave", force: showMessage);
            _lastSaveStatus = $"Saved {DateTime.Now:h:mm tt}";
            if (showMessage) HintText.Text = $"Saved successfully. Backup created for {_saveService.ActiveSlot}.";
            if (SaveStatusText != null) SaveStatusText.Text = _lastSaveStatus;
        }
        catch (Exception ex)
        {
            _lastSaveStatus = "Save failed";
            if (SaveStatusText != null) SaveStatusText.Text = _lastSaveStatus;
            HintText.Text = "Save failed: " + ex.Message;
            ReleaseDiagnostics.LogException(ex, "SaveGame");
        }
    }

    private void Render()
    {
        Player.Clamp();
        World.Clamp();
        ClockText.Text = $"Year {CurrentYear()}, day {DayOfYear()}, {Player.StoryHour:00}:{Player.StoryMinute:00} • {Player.Season}, day {Player.SeasonDay}/90 • {Player.Weather} • Speed: {_speedNames[_speedIndex]} ({_storyMinutesPerTick[_speedIndex]} story minute{(_storyMinutesPerTick[_speedIndex] == 1 ? "" : "s")}/sec)";
        StatusText.Text = Player.IsRetired
            ? $"{Player.Name}, {Player.FinalTitle}\nRETIRED — {Player.CauseOfEnd}"
            : Player.IsAlive
                ? $"{Player.Name}, level {Player.Level} {Player.Background}\n{CurrentLivingTitle()} • Age {Player.AgeYears} • Gen {Player.Generation} • House {Player.BloodlineName}"
                : $"{Player.Name}, {Player.FinalTitle}\nDEAD — {Player.CauseOfEnd}";

        HpText.Text = $"HP: {Player.CurrentHp}/{Player.MaxHp}"; HpBar.Value = PercentValue(Player.CurrentHp, Player.MaxHp);
        EnergyText.Text = $"Energy: {Player.Energy}/100"; EnergyBar.Value = Player.Energy;
        HungerText.Text = $"Hunger: {Player.Hunger}/100"; HungerBar.Value = Player.Hunger;
        MoraleText.Text = $"Morale: {Player.Morale}/100"; MoraleBar.Value = Player.Morale;

        CoreStatsText.Text = $"Gold: {Player.Gold}\nSupplies: {Player.Supplies}\nPotions: {Player.Potions}\nReputation: {Player.Reputation}\nLuck: {Player.Luck}\nXP: {Player.Xp}/{Player.XpToNextLevel}";
        GearText.Text = $"Weapon tier: {Player.WeaponTier} • Armor tier: {Player.ArmorTier} • Camp tier: {Player.CampTier}\nAttack: {Player.Attack} • Defense: {Player.Defense} • Survival bonus: {Player.SurvivalBonus}\nSafe danger estimate: {SafeDangerLimit()} • Stability: {LongLifeStabilityBonus()}";
        string childLine = Player.HasChild ? $" • Child/heir: {Player.ChildName} ({Player.ChildAgeYears})" : string.Empty;
        TraitsText.Text = $"Background: {Player.Background}\nAge: {Player.AgeYears}y {Player.AgeDays}d • Bloodline: House {Player.BloodlineName}\nFamily: {Player.FamilyStatus}{childLine}\nImmortality: {Player.ImmortalityPath} {(Player.IsImmortal ? "(active)" : $"({Player.MythicPathProgress}%)")}\nTraits: {string.Join(", ", Player.Traits)}\nDifficulty: {Player.Difficulty}\nLife rule: {Player.LifePhilosophy}";

        var activeCompanions = Player.Companions.Where(c => c.IsActive).ToList();
        CompanionsText.Text = activeCompanions.Count == 0 ? "No active companions yet. New allies can join through travel, towns, and story events." : string.Join("\n", activeCompanions.Select(c => "• " + c.Summary));
        var activeInjuries = Player.Injuries.Where(i => i.IsActive).ToList();
        InjuriesText.Text = activeInjuries.Count == 0 ? "No active injuries. The hero is currently healthy." : string.Join("\n", activeInjuries.Select(i => $"• {i.Name}: {(i.IsPermanent ? "permanent" : i.DaysRemaining + "d left")} — {i.Description}"));

        int remaining = Math.Max(0, Player.ActivityMinutesRemaining);
        int elapsed = Math.Max(0, Player.ActivityTotalMinutes - Player.ActivityMinutesRemaining);
        ActivityText.Text = Player.IsRetired ? $"Retired in {Player.Location}" : Player.IsAlive ? $"{Player.ActivityName}\n{Player.CurrentActivity}" : $"Life ended in {Player.Location}";
        QuestText.Text = Player.IsAlive && !Player.IsRetired ? $"Elapsed: {FormatDuration(elapsed)} • Remaining: {FormatDuration(remaining)} • Danger: {EffectiveDanger(Player.ActivityDanger)} • Location: {Player.Location}" : $"Final score: {Player.SurvivalScore}";
        ActivityBar.Value = Player.ActivityTotalMinutes <= 0 ? 0 : Math.Clamp((elapsed * 100.0) / Player.ActivityTotalMinutes, 0, 100);

        WorldText.Text = RenderWorldText();
        GuildText.Text = RenderGuildText();
        FactionText.Text = string.Join("\n", Player.Factions.OrderByDescending(k => k.Value).Select(kv => $"• {kv.Key}: {kv.Value}"));
        var rumors = Player.Rumors.Where(r => !r.IsResolved).Take(8).ToList();
        RumorText.Text = rumors.Count == 0 ? "No active rumors. New leads will appear through towns, gossip, and travel." : string.Join("\n", rumors.Select(r => $"• {r.Title} — {r.Location}, danger {r.Danger}, reward {r.Reward}, age {r.DaysOld}d, {r.Faction}"));
        var arcs = Player.StoryArcs.ToList();
        ArcText.Text = arcs.Count == 0 ? "No active story arcs yet. Larger plots will appear as the chronicle advances." : string.Join("\n\n", arcs.Select(a => $"• {a.Name} [{a.Stage}]\n  Progress {a.Progress}% • Threat {a.Threat} • {(a.IsResolved ? a.Ending : a.Description)}"));
        LivingWorldText.Text = RenderLivingWorldText();
        TownText.Text = RenderTownText();
        BloodlineText.Text = RenderBloodlineText();
        ArtifactText.Text = RenderArtifactText();
        RivalNemesisText.Text = RenderRivalNemesisText();
        FaithMagicText.Text = RenderFaithMagicText();
        HomePetsText.Text = RenderHomePetsText();
        BulletinText.Text = RenderBulletinText();
        RulesText.Text = RenderRulesText();
        PatchNotesText.Text = RenderPatchNotesText();
        EventTesterText.Text = RenderEventTesterText();
        StorybookText.Text = RenderStorybookText();
        ReplayText.Text = RenderReplayText();
        RenderMapSection();
        NewspaperArchiveText.Text = RenderNewspaperArchiveText();
        MemoryBookText.Text = RenderMemoryBookText();
        DirectorText.Text = RenderDirectorText();
        ModManagerText.Text = RenderModManagerText();
        ImportExportText.Text = RenderImportExportText();
        SettingsText.Text = RenderSettingsText();
        WatchText.Text = RenderWatchText();
        DebugText.Text = RenderDebugText();
        AchievementsText.Text = RenderAchievementsText();
        StatsText.Text = RenderStatsText();
        LegacyText.Text = RenderLegacyText();
        TimelineText.Text = Player.Timeline.Count == 0 ? "No major timeline events yet." : string.Join(Environment.NewLine + Environment.NewLine, Player.Timeline.TakeLast(80));
        LifetimeText.Text = $"Time survived: {FormatSurvivedTime()}\nScore: {Player.SurvivalScore}\nQuests completed/failed: {Player.QuestsCompleted}/{Player.QuestsFailed}\nAdventures survived: {Player.AdventuresSurvived}\nNear deaths: {Player.NearDeaths}\nCompanions met/lost: {Player.CompanionsMet}/{Player.CompanionsLost}\nRumors followed: {Player.RumorsFollowed}\nLegendary events: {Player.LegendaryEventsSeen}\nArtifacts: {Player.ArtifactsFound} • Pets: {Player.PetsMet} • Nemesis/Rival: {Player.NemesisEncounters}/{Player.RivalEncounters}\nResearch breakthroughs: {Player.ResearchBreakthroughs} • Family milestones: {Player.FamilyMilestones} • Mysteries: {Player.MysteryEventsSeen}\nGold earned: {Player.TotalGoldEarned}";
        LogText.Text = string.Join(Environment.NewLine + Environment.NewLine, _storyLog.TakeLast(140));
        LogScroll.ScrollToEnd();
        PauseButton.Content = _isPaused ? "Resume" : "Pause";
        SpeedButton.Content = $"Speed: {_speedNames[_speedIndex]}";
        MiniModeButton.Content = _saveData.Settings.MiniMode ? "Close Mini" : "Mini Mode";
        PauseMajorButton.Content = _saveData.Settings.PauseOnMajorEvents ? "Major Pause On" : "Pause Major";
        SoundButton.Content = _saveData.Settings.SoundEnabled ? "Sound On" : "Sound";
        WatchModeButton.Content = _saveData.Settings.WatchMode ? "Exit Watch" : "Watch Mode";
        HintText.Text = Player.IsAlive && !Player.IsRetired
            ? (_saveData.Settings.WatchMode
                ? "Watch Mode is active: the app is focusing on the big desk-companion view. Press Exit Watch to return to the full ledger."
                : "Fully idle living-world chronicle with save slots, backups, legacy heirs, character creation, watch mode, achievements, story pacing, and clean release-ready publishing.")
            : "This chapter is complete. Press New Life to continue the world with a new generation and inheritance from prior legends.";
        SaveStatusText.Text = _lastSaveStatus;
        UpdateMainMenuVisuals();
        UpdateReleaseControlStates();
        UpdateMiniModeVisuals();
        ApplyThemeVisuals();
        UpdateWatchModeVisuals();
    }

    private void UpdateWatchModeVisuals()
    {
        bool watch = _saveData.Settings.WatchMode;

        LeftHeroPanel.Visibility = watch ? Visibility.Collapsed : Visibility.Visible;
        RightWorldPanel.Visibility = watch ? Visibility.Collapsed : Visibility.Visible;

        LeftColumn.Width = watch ? new GridLength(0) : new GridLength(0.82, GridUnitType.Star);
        CenterColumn.Width = new GridLength(1, GridUnitType.Star);
        RightColumn.Width = watch ? new GridLength(0) : new GridLength(1.05, GridUnitType.Star);

        WatchText.FontSize = watch ? 24 : 18;
        WatchText.LineHeight = watch ? 38 : 30;
        ActivityText.FontSize = watch ? 22 : 18;
        QuestText.FontSize = watch ? 16 : 14;

        if (watch && MainStoryTabs.SelectedItem != WatchTab)
        {
            MainStoryTabs.SelectedItem = WatchTab;
        }

        if (watch)
        {
            MinWidth = 900;
            MinHeight = 650;
        }
        else
        {
            MinWidth = 0;
            MinHeight = 0;
        }
    }



    private void EnsureStoryDirectorSeeds()
    {
        World.MapNotes ??= new List<MapNote>();
        World.DiscoveredLocations ??= new List<WorldLocation>();
        World.ChronicleMilestones ??= new List<ChronicleMilestone>();
        if (World.ProceduralSeed == 0) World.ProceduralSeed = _random.Next(100000, 999999);
        if (World.MapNotes.Count == 0)
        {
            foreach (var location in _locations)
                World.MapNotes.Add(new MapNote { Location = location.Name, Icon = location.Kind == "Town" ? "⌂" : location.Kind == "Legendary" ? "✦" : location.Kind == "Dungeon" ? "◆" : "•", Note = location.Flavor, Year = CurrentYear(), Danger = location.Danger });
        }
        if (World.ChronicleMilestones.Count == 0)
        {
            World.ChronicleMilestones.Add(new ChronicleMilestone { Year = 1, Title = "First Page", Text = "The chronicle begins keeping a world history instead of only a hero log." });
            World.ChronicleMilestones.Add(new ChronicleMilestone { Year = 7, Title = "Seventh-Year Road", Text = "Old road stories begin turning into local superstition." });
            World.ChronicleMilestones.Add(new ChronicleMilestone { Year = 42, Title = "The Black Tower Watches", Text = "The long arc system starts treating old omens as real pressure." });
        }
    }

    private string RollStartingBurden(string origin)
    {
        return origin switch
        {
            "Failed Noble" => "a family name that opens doors and closes hearts",
            "Temple Child" => "a promise made under a bell that still rings in dreams",
            "Old Soldier" => "old scars and a habit of standing between danger and everyone else",
            "Cursed Bloodline" => "a bloodline curse that gets louder near moonlight",
            "Merchant's Heir" => "debts, ledgers, and relatives who know exactly where to find them",
            "Wild Forest Foundling" => "a wild omen that never learned to behave indoors",
            "Orphan Wanderer" => "a missing family name and a pack that feels too light",
            _ => Pick(new[] { "a small debt", "a bad dream", "a promise to return", "a map nobody trusts", "a lonely road habit", "a knife with someone else's initials" })
        };
    }

    private string RollStartingBlessing(string origin)
    {
        return origin switch
        {
            "Temple Child" => "the Lantern Saint notices when the road gets dark",
            "Cursed Bloodline" => "bad luck sometimes trips over itself",
            "Merchant's Heir" => "shopkeepers listen before raising prices",
            "Wild Forest Foundling" => "animals are slower to run away",
            "Old Soldier" => "retreat feels like tactics instead of shame",
            _ => Pick(new[] { "a warm meal remembered at the right time", "one unusually loyal pair of boots", "a stubborn heart", "a knack for finding shelter", "a road-god's half-attention" })
        };
    }

    private string RollVisualArchetype(string background)
    {
        return background switch
        {
            "Exiled Noble" => "weathered noble in travel-stained finery",
            "Former Temple Apprentice" => "quiet lantern-bearer with careful hands",
            "Retired Guard" => "old soldier with practical armor",
            "Cursed Wanderer" => "moon-haunted wanderer with watchful eyes",
            "Failed Mage Student" => "bookish traveler with ink-stained sleeves",
            "Witch's Errand Runner" => "forest-touched courier with charm strings",
            _ => Pick(new[] { "hooded traveler", "patched-road survivor", "muddy-boot adventurer", "soft-eyed wanderer", "stubborn village blade" })
        };
    }

    private void ApplyOriginSeedEffects()
    {
        switch (Player.OriginSeed)
        {
            case "Failed Noble": Player.Gold += 20; Player.Reputation += 2; Player.AddFaction("Noble House", 8); break;
            case "Temple Child": Player.Potions += 1; Player.Faith.Favor += 8; Player.AddFaction("Temple Order", 8); break;
            case "Old Soldier": Player.ArmorTier += 1; Player.Morale += 2; Player.AddFaction("Town Guard", 7); break;
            case "Cursed Bloodline": Player.Luck += 8; World.MagicInstability += 3; Player.MythicPathProgress += 3; break;
            case "Merchant's Heir": Player.Gold += 35; Player.AddFaction("Merchant Guild", 9); break;
            case "Wild Forest Foundling": Player.Supplies += 3; Player.Luck += 5; Player.AddFaction("Mage Circle", 4); break;
            case "Orphan Wanderer": Player.Morale += 3; Player.Supplies += 2; break;
        }
        if (!Player.MemoryTags.Contains(Player.OriginSeed)) Player.MemoryTags.Add(Player.OriginSeed);
        Player.Clamp();
    }

    private void StartStoryChapter(string title, string firstLine)
    {
        var chapter = new StoryChapter { Title = title, StartYear = CurrentYear(), StartDay = DayOfYear() };
        chapter.Lines.Add(firstLine);
        Player.StoryChapters.Add(chapter);
        while (Player.StoryChapters.Count > 80) Player.StoryChapters.RemoveAt(0);
    }

    private void AddStorybookLine(string line)
    {
        if (string.IsNullOrWhiteSpace(line)) return;
        if (Player.StoryChapters.Count == 0 || Player.StoryChapters.Last().Lines.Count > 22)
            StartStoryChapter($"Chapter {Player.StoryChapters.Count + 1} — {Player.Location}", line);
        else
            Player.StoryChapters.Last().Lines.Add(line);
    }

    private void AddEventReplay(string title, IEnumerable<string> steps, string outcome)
    {
        var replay = new EventReplay { Title = title, Year = CurrentYear(), Day = DayOfYear(), Outcome = outcome };
        replay.Steps.AddRange(steps.Where(x => !string.IsNullOrWhiteSpace(x)));
        Player.EventReplays.Add(replay);
        Player.LastEventReplay = replay.Summary;
        while (Player.EventReplays.Count > 40) Player.EventReplays.RemoveAt(0);
    }

    private void AddMapNote(string location, string icon, string note, int danger)
    {
        World.MapNotes ??= new List<MapNote>();
        World.MapNotes.Add(new MapNote { Location = location, Icon = icon, Note = note, Year = CurrentYear(), Danger = Math.Max(0, danger) });
        while (World.MapNotes.Count > 90) World.MapNotes.RemoveAt(0);
    }

    private void AddChronicleMilestone(int year, string title, string text)
    {
        if (World.ChronicleMilestones.Any(m => m.Year == year && m.Title == title)) return;
        World.ChronicleMilestones.Add(new ChronicleMilestone { Year = year, Title = title, Text = text });
        World.ChronicleMilestones = World.ChronicleMilestones.OrderBy(m => m.Year).TakeLast(120).ToList();
        AddWorldHistory("Milestone", $"{title}: {text}");
    }

    private void ApplyDirectorDailyPacing()
    {
        int risk = EstimateDeathRisk();
        int recentBad = _storyLog.TakeLast(24).Count(l => l.Contains("HP -") || l.Contains("Injury") || l.Contains("disease", StringComparison.OrdinalIgnoreCase) || l.Contains("fails", StringComparison.OrdinalIgnoreCase));
        int recentMajor = _storyLog.TakeLast(24).Count(IsMajorJournal);
        if (risk > 55 || recentBad >= 4)
        {
            World.DirectorMood = "Mercy";
            World.DirectorPressure = Math.Max(0, World.DirectorPressure - 5);
        }
        else if (recentMajor == 0 && Player.StoryDay % 10 == 0)
        {
            World.DirectorMood = "Stirring Trouble";
            World.DirectorPressure = Math.Min(100, World.DirectorPressure + 4);
        }
        else
        {
            World.DirectorMood = "Balanced";
            World.DirectorPressure += World.DirectorPressure > 25 ? -1 : 1;
        }

        if (Player.StoryDay % 14 == 0 && World.DirectorMood == "Mercy")
        {
            Player.Morale += 2;
            Player.Energy += 2;
            AddStorybookLine($"The story softens around {Player.Name} for a few days, letting recovery matter more than danger.");
        }
    }

    private void ApplyDirectorBeforeDecision(WorldLocation location)
    {
        if (World.DirectorMood == "Mercy" && location.Kind == "Town" && Player.Morale < 70 && Percent(18))
        {
            Player.Morale += 3;
            AddJournal($"Director beat: the day chooses quiet mercy. {Player.Name} finds a warm corner, a patient listener, and no ambushes whatsoever.");
        }
        else if (World.DirectorMood == "Stirring Trouble" && Player.Rumors.Count(r => !r.IsResolved) < 4 && Percent(12))
        {
            MaybeCreateRumor("the Story Director");
        }
    }

    private void ApplyDifficultyDrift()
    {
        int year = CurrentYear();
        if (year < 2) return;
        int direction = (World.RoadSafety + World.TownWealth) > (World.BanditPower + World.MonsterPressure) ? 1 : -1;
        World.DifficultyDrift += direction;
        World.DifficultyDrift = Math.Clamp(World.DifficultyDrift, -25, 60);
        if (World.DifficultyDrift > 20 && Percent(35))
        {
            World.MonsterPressure += 1;
            World.MagicInstability += 1;
        }
        if (World.DifficultyDrift < -10 && Percent(35))
        {
            World.RoadSafety += 1;
            World.TownWealth += 1;
        }
    }

    private bool ShouldDailyRoutine(WorldLocation location)
    {
        if (location.Kind != "Town") return false;
        if (Player.Energy < 40 || Player.Hunger > 65) return false;
        int chance = 9 + Player.HomeTier + (Player.LifePhilosophy == "Seek Balance" ? 6 : 0);
        return Percent(chance);
    }

    private void StartDailyRoutine(WorldLocation location)
    {
        string routine = Pick(new[] { "breakfast, rumor-checking, and mending a sock with grim focus", "writing letters by a window while rain makes the street honest", "helping at the temple before checking the job board", "walking the market twice and buying nothing until the third lap", "brushing down the animals, sorting the pack, and pretending this counts as rest" });
        StartActivity("DailyRoutine", "Living a normal day", $"{Player.Name} spends the day on {routine} in {location.Name}.", _random.Next(180, 520), 0, 0, 6);
    }

    private void FinishDailyRoutine()
    {
        Player.DailyRoutineCount++;
        Player.Morale += 3;
        Player.Energy += 4;
        Player.Hunger = Math.Max(0, Player.Hunger - 2);
        string result = Pick(new[] { "The ordinary parts of life hold." , "Nothing dramatic happens, which is a luxury." , "The pack is neater and the heart less loud." });
        Player.DailyRoutines.Add(new DailyRoutineRecord { Year = CurrentYear(), Day = DayOfYear(), Routine = Player.CurrentActivity, Result = result });
        while (Player.DailyRoutines.Count > 60) Player.DailyRoutines.RemoveAt(0);
        AddJournal($"Daily routine: {result}");
        AddStorybookLine($"For once, {Player.Name}'s day is made of chores, soup, and small repairs instead of teeth.");
    }

    private bool ShouldIdleCrafting(WorldLocation location)
    {
        if (location.Kind != "Town") return false;
        if (Player.Gold < 12 || Player.Energy < 45) return false;
        int chance = 5 + Player.LibraryTier + Player.BlacksmithTier + Player.GardenTier;
        if (Player.LifePhilosophy == "Seek Safety") chance += 4;
        return Percent(chance);
    }

    private void StartIdleCrafting(WorldLocation location)
    {
        string[] names = { "weatherproof bedroll", "poultice kit", "road charm", "reinforced boot soles", "map case", "camp kettle", "quiet lantern", "pack frame" };
        string name = Pick(names);
        StartActivity("Crafting", "Idle crafting", $"{Player.Name} settles into careful idle crafting: {name}. No menu opens. The hero just gets practical.", _random.Next(150, 480), 0, 0, 9);
        Player.ActivityRumor = name;
    }

    private void FinishIdleCrafting()
    {
        Player.IdleCraftingCount++;
        string name = string.IsNullOrWhiteSpace(Player.ActivityRumor) ? "road kit" : Player.ActivityRumor;
        var craft = Player.CraftingProjects.FirstOrDefault(c => c.Name == name && !c.Completed);
        if (craft == null)
        {
            craft = new CraftProject { Name = name, Kind = "Idle utility", Progress = 0, Benefit = Pick(new[] { "safer travel", "better rest", "lower hunger spikes", "higher morale", "more reliable retreats" }) };
            Player.CraftingProjects.Add(craft);
        }
        craft.Progress += _random.Next(35, 70);
        if (craft.Progress >= 100)
        {
            craft.Completed = true;
            Player.Supplies += 1;
            Player.Morale += 2;
            Player.CampTier += Percent(20) ? 1 : 0;
            AddJournal($"Idle crafting completed: {craft.Name}. Benefit: {craft.Benefit}.");
            AddStorybookLine($"{Player.Name} finishes {craft.Name}, the kind of tiny preparation that saves lives without looking heroic.");
        }
        else
        {
            AddJournal($"Idle crafting progresses: {craft.Name} reaches {craft.Progress}%.");
        }
        while (Player.CraftingProjects.Count > 40) Player.CraftingProjects.RemoveAt(0);
    }


    private void MaybeRetiredHeroCameo()
    {
        var retired = _saveData.HallOfLegends.Where(l => l.EndType == "Retirement").OrderByDescending(l => l.Score).FirstOrDefault();
        if (retired == null || !Percent(35)) return;
        World.RetiredHeroCameos++;
        Player.RetiredCameos++;
        int help = Math.Clamp(retired.Score / 2500, 1, 8);
        Player.Reputation += help;
        Player.Morale += 2;
        World.RoadSafety += 1;
        AddJournal($"Retired legend cameo: {retired.Name}, {retired.Title}, sends advice, maps, and a little reputation down the road. Retirement does not mean vanishing.");
        AddMapNote(Player.Location, "♜", $"{retired.Name}'s retired influence helped {Player.Name} here.", 0);
    }

    private int EstimateDeathRisk()
    {
        int risk = 0;
        risk += Math.Clamp(100 - PercentValueInt(Player.CurrentHp, Player.MaxHp), 0, 100) / 3;
        risk += Math.Clamp(Player.Hunger - 50, 0, 50) / 2;
        risk += Math.Clamp(35 - Player.Energy, 0, 35) / 2;
        risk += Player.Injuries.Count(i => i.IsActive) * 4;
        risk += Player.Diseases.Where(d => d.IsActive).Sum(d => d.Severity / 8);
        risk += EffectiveDanger(Player.ActivityDanger) / 8;
        risk -= LongLifeStabilityBonus() / 3;
        risk -= Player.Companions.Count(c => c.IsActive) * 4;
        risk -= Player.PetsMounts.Count(p => p.IsAlive) * 2;
        return Math.Clamp(risk, 0, 100);
    }

    private string RenderStorybookText()
    {
        if (Player.StoryChapters.Count == 0) return "No storybook chapters yet. Let the chronicle run a little longer.";
        var sb = new StringBuilder();
        foreach (var chapter in Player.StoryChapters.TakeLast(12))
        {
            sb.AppendLine(chapter.Title);
            sb.AppendLine(new string('─', Math.Min(42, chapter.Title.Length + 6)));
            foreach (var line in chapter.Lines.TakeLast(10)) sb.AppendLine(line);
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private string RenderReplayText()
    {
        if (Player.EventReplays.Count == 0) return "No major event replays yet. Big moments will appear here as little round-by-round summaries.";
        return string.Join("\n\n", Player.EventReplays.TakeLast(10).Select(r => r.Summary));
    }

    private void RenderMapSection()
    {
        MapCurrentLocationText.Text = Player.Location;
        MapDestinationText.Text = string.IsNullOrWhiteSpace(Player.Destination) ? "No current destination" : Player.Destination;
        MapDangerDriftText.Text = World.DifficultyDrift.ToString();
        MapDirectorText.Text = $"{World.DirectorMood} ({World.DirectorPressure}/100)";

        MapLocationsPanel.Children.Clear();

        var orderedLocations = _locations
            .OrderByDescending(l => l.Name == Player.Location)
            .ThenByDescending(l => !string.IsNullOrWhiteSpace(Player.Destination) && l.Name == Player.Destination)
            .ThenBy(l => l.Danger)
            .ThenBy(l => l.Name)
            .ToList();

        foreach (var loc in orderedLocations)
        {
            MapLocationsPanel.Children.Add(BuildMapLocationCard(loc));
        }

        MapNotesText.Text = World.MapNotes.Count == 0
            ? "No map notes discovered yet. Travel will add discoveries here."
            : string.Join("\n", World.MapNotes.TakeLast(12).Reverse().Select(n => "• " + n.Summary));
    }

    private Border BuildMapLocationCard(WorldLocation loc)
    {
        bool isHere = loc.Name == Player.Location;
        bool isDestination = !string.IsNullOrWhiteSpace(Player.Destination) && loc.Name == Player.Destination;
        var town = World.Towns.FirstOrDefault(t => t.Name == loc.Name);
        string summary = town?.Summary ?? loc.Flavor;
        string kindIcon = loc.Kind switch
        {
            "Town" => "⌂",
            "Legendary" => "✦",
            "Dungeon" => "◆",
            _ => "•"
        };

        string badgeText = isHere ? "YOU ARE HERE" : isDestination ? "DESTINATION" : loc.Kind.ToUpperInvariant();
        string statLine = $"Danger {loc.Danger}   •   Reward {loc.Reward}";
        string routeLine = loc.Routes.Length == 0 ? "Routes: none" : "Routes: " + string.Join(", ", loc.Routes);

        var card = new Border
        {
            Background = BrushFromHex(isHere ? "#213B5D" : isDestination ? "#18324E" : "#102238"),
            BorderBrush = BrushFromHex(isHere ? "#E0BD77" : "#6C5330"),
            BorderThickness = new Thickness(isHere ? 1.4 : 1),
            CornerRadius = new CornerRadius(10),
            Padding = new Thickness(10),
            Margin = new Thickness(0, 0, 0, 8)
        };

        var root = new StackPanel();

        var header = new DockPanel { LastChildFill = false };
        var title = new TextBlock
        {
            Text = $"{kindIcon} {loc.Name}",
            FontSize = 16,
            FontWeight = FontWeights.Bold,
            Margin = new Thickness(0, 0, 8, 0)
        };
        DockPanel.SetDock(title, Dock.Left);
        header.Children.Add(title);

        var badge = new Border
        {
            Background = BrushFromHex(isHere ? "#E0BD77" : isDestination ? "#6F8FB7" : "#2A4260"),
            BorderBrush = BrushFromHex(isHere ? "#F3D89E" : "#7B6136"),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(8),
            Padding = new Thickness(7, 2, 7, 2),
            HorizontalAlignment = System.Windows.HorizontalAlignment.Right
        };
        badge.Child = new TextBlock
        {
            Text = badgeText,
            FontSize = 10.5,
            FontWeight = FontWeights.Bold,
            Foreground = isHere ? BrushFromHex("#1E160E") : BrushFromHex("#F7EBD2")
        };
        DockPanel.SetDock(badge, Dock.Right);
        header.Children.Add(badge);

        root.Children.Add(header);

        root.Children.Add(new TextBlock
        {
            Text = statLine,
            FontSize = 12.5,
            Foreground = BrushFromHex("#D0B889"),
            Margin = new Thickness(0, 5, 0, 0)
        });

        root.Children.Add(new TextBlock
        {
            Text = routeLine,
            FontSize = 12.5,
            Foreground = BrushFromHex("#D0B889"),
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 3, 0, 0)
        });

        root.Children.Add(new TextBlock
        {
            Text = summary,
            FontSize = 13.5,
            TextWrapping = TextWrapping.Wrap,
            LineHeight = 20,
            Margin = new Thickness(0, 7, 0, 0)
        });

        card.Child = root;
        return card;
    }

    private static System.Windows.Media.Brush BrushFromHex(string hex)
    {
        return (System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFromString(hex)!;
    }

    private string RenderMapText()
    {
        var sb = new StringBuilder();
        sb.AppendLine($"Current location: {Player.Location}  |  Destination: {(string.IsNullOrWhiteSpace(Player.Destination) ? "none" : Player.Destination)}");
        sb.AppendLine($"World danger drift: {World.DifficultyDrift}  |  Director: {World.DirectorMood} ({World.DirectorPressure}/100)");
        sb.AppendLine();
        foreach (var loc in _locations)
        {
            string here = loc.Name == Player.Location ? " ← HERO" : "";
            string town = World.Towns.FirstOrDefault(t => t.Name == loc.Name)?.Summary ?? loc.Flavor;
            sb.AppendLine($"{(loc.Kind == "Town" ? "⌂" : loc.Kind == "Legendary" ? "✦" : loc.Kind == "Dungeon" ? "◆" : "•")} {loc.Name}{here}");
            sb.AppendLine($"   {loc.Kind} • danger {loc.Danger} • reward {loc.Reward} • routes: {string.Join(", ", loc.Routes)}");
            sb.AppendLine($"   {town}");
        }
        sb.AppendLine();
        sb.AppendLine("Map notes:");
        foreach (var note in World.MapNotes.TakeLast(18)) sb.AppendLine("• " + note.Summary);
        return sb.ToString();
    }

    private string RenderNewspaperArchiveText()
    {
        if (World.Bulletins.Count == 0) return "No newspaper issues yet. Town bulletins will appear as settlements develop.";
        return string.Join("\n\n", World.Bulletins.TakeLast(20).Reverse().Select(b => b.Summary));
    }

    private string RenderMemoryBookText()
    {
        UpdateCompanionPetMemoryBook();
        var memories = Player.CompanionPetMemories.Count == 0 ? "No companion or pet memories yet." : string.Join("\n", Player.CompanionPetMemories.TakeLast(35).Select(m => "• " + m.Summary));
        var routines = Player.DailyRoutines.Count == 0 ? "No daily routine records yet." : string.Join("\n", Player.DailyRoutines.TakeLast(10).Select(r => "• " + r.Summary));
        var crafts = Player.CraftingProjects.Count == 0 ? "No idle crafting projects yet." : string.Join("\n", Player.CraftingProjects.TakeLast(15).Select(c => "• " + c.Summary));
        return $"Companion and pet memory book\n\n{memories}\n\nDaily life\n{routines}\n\nIdle crafting\n{crafts}";
    }

    private string RenderDirectorText()
    {
        return $"Story Director\n\nMood: {World.DirectorMood}\nPressure: {World.DirectorPressure}/100\nEstimated death risk: {EstimateDeathRisk()}%\nDifficulty drift: {World.DifficultyDrift}\nRecent major events: {_storyLog.TakeLast(30).Count(IsMajorJournal)}\nRecent danger lines: {_storyLog.TakeLast(30).Count(l => l.Contains("HP -") || l.Contains("Injury"))}\n\nWhat it does:\n• Adds calmer days after too much danger.\n• Adds rumors and pressure when life gets stale.\n• Nudges the world instead of giving the player direct control.\n• Helps long/endless lives feel paced instead of purely random.";
    }

    private string RenderModManagerText()
    {
        string root = ModsFolder();
        var files = Directory.Exists(root) ? Directory.GetFiles(root, "*.json", SearchOption.AllDirectories).Select(f => Path.GetFileName(f) ?? f).OrderBy(x => x).ToList() : new List<string>();
        string fileText = files.Count == 0 ? "No JSON mod files found." : string.Join("\n", files.Select(f => "• " + f));
        return $"Mods folder:\n{root}\n\nLoaded custom events: {_customEvents.Count}\n\nFiles:\n{fileText}\n\nExpected folders: Events, Companions, Artifacts, Towns, Gods, Traits, Backgrounds, Diseases, StoryArcs.\nUse Sample Mod to create an example, then Reload Mods.";
    }

    private string RenderImportExportText()
    {
        string history = _saveData.Transfers.Count == 0 ? "No imports or exports yet." : string.Join("\n", _saveData.Transfers.TakeLast(12).Select(t => "• " + t.Summary));
        return $"Import / Export\n\nActive save: {_saveService.SavePath}\nExport World copies the full save JSON somewhere you choose.\nImport World replaces the active slot with a selected save JSON. A backup is created first.\nBug Report creates a zip with the save, recent journal, balance details, mods list, settings, build info, and recent logs.\n\nHistory:\n{history}";
    }

    private string RenderSettingsText()
    {
        string uploadTime = _saveData.Settings.LastLeaderboardUploadUtc.HasValue
            ? _saveData.Settings.LastLeaderboardUploadUtc.Value.ToLocalTime().ToString("g")
            : "Not uploaded yet";

        return $"Settings\n\nTheme: {_saveData.Settings.ThemeName}\nJournal pacing: {_saveData.Settings.JournalPacing}\nWatch mode: {_saveData.Settings.WatchMode}\nMini mode: {_saveData.Settings.MiniMode}\nPause on major events: {_saveData.Settings.PauseOnMajorEvents}\nPause on legendary events: {_saveData.Settings.PauseOnLegendaryEvents}\nMajor notifications: {_saveData.Settings.MajorNotifications}\nNotification level: {_saveData.Settings.NotificationLevel}\nSound cues enabled: {_saveData.Settings.SoundEnabled}\nSave slot: {_saveService.ActiveSlot}\nOrigin seed for next life: {ComboText(OriginBox, Player.OriginSeed)}\n\nPublic leaderboard: {(_saveData.Settings.LeaderboardAutoUpload ? "Automatic" : "Off")}\nLeaderboard name: {SafeLeaderboardText(string.IsNullOrWhiteSpace(_saveData.Settings.LeaderboardDisplayName) ? Player.Name : _saveData.Settings.LeaderboardDisplayName, 32)}\nLeaderboard status: {_saveData.Settings.LastLeaderboardStatus}\nLast leaderboard upload: {uploadTime}\n\nTheme changes are lightweight desktop themes. Sound cues use small system sounds for major events. Leaderboards upload only public game stats, never your save file, email, or private journal.";
    }

    private void UpdateMainMenuVisuals()
    {
        MainMenuOverlay.Visibility = _saveData.Settings.ShowMainMenu ? Visibility.Visible : Visibility.Collapsed;
        MenuSummaryText.Text = $"Current: {Player.Name}, {CurrentLivingTitle()} • Year {CurrentYear()} • {Player.Location} • Slot {_saveService.ActiveSlot}";
    }

    private void UpdateReleaseControlStates()
    {
        try
        {
            bool hasActiveSave = _saveService.ActiveSaveExists(_saveService.ActiveSlot);
            bool hasBackup = _saveService.HasBackup(_saveService.ActiveSlot);
            if (ContinueButton != null) ContinueButton.IsEnabled = hasActiveSave || _saveData.Settings.FirstLaunchComplete;
            if (RestoreBackupButton != null) RestoreBackupButton.IsEnabled = hasBackup;
            if (ImportWorldButton != null) ImportWorldButton.IsEnabled = true;
            if (StartCustomLifeButton != null) StartCustomLifeButton.IsEnabled = true;
            if (StartRandomLifeButton != null) StartRandomLifeButton.IsEnabled = true;
            if (FirstLaunchWelcomePanel != null)
                FirstLaunchWelcomePanel.Visibility = CharacterBuilderOverlay.Visibility == Visibility.Visible && _isFirstRun && !_saveData.Settings.FirstLaunchComplete ? Visibility.Visible : Visibility.Collapsed;
        }
        catch
        {
            // Release controls are polish only; state refresh should never interrupt the chronicle.
        }
    }

    private void ApplyThemeVisuals()
    {
        // Lightweight theme support. The detailed panels keep their readable colors; the window mood shifts here.
        string theme = _saveData.Settings.ThemeName;
        string color = theme switch
        {
            "Parchment" => "#221B13",
            "Forest" => "#0B1A12",
            "Cozy Tavern" => "#20120C",
            "Winter" => "#101A24",
            "Blood Moon" => "#210D12",
            _ => "#0D1220"
        };
        Background = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(color));
    }

    private void UpdateMiniModeVisuals()
    {
        if (!_saveData.Settings.MiniMode)
        {
            CloseMiniWindowOnly();
            if (!IsVisible)
            {
                Show();
            }
            return;
        }

        if (_miniWindow == null)
        {
            _miniText = new TextBlock
            {
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(12, 10, 12, 6),
                FontSize = 14,
                LineHeight = 22,
                Foreground = System.Windows.Media.Brushes.White
            };

            var returnButton = new System.Windows.Controls.Button
            {
                Content = "Return to Full View",
                Margin = new Thickness(12, 0, 12, 12),
                Padding = new Thickness(10, 6, 10, 6),
                HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch
            };
            returnButton.Click += (_, _) => ReturnToFullViewFromMini();

            var layout = new DockPanel();
            DockPanel.SetDock(returnButton, Dock.Bottom);
            layout.Children.Add(returnButton);
            layout.Children.Add(_miniText);

            _miniWindow = new Window
            {
                Title = "Mayflower Mini Watch",
                Width = 410,
                Height = 230,
                Topmost = true,
                ResizeMode = ResizeMode.CanResizeWithGrip,
                WindowStyle = WindowStyle.ToolWindow,
                Background = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#111A2C")),
                Content = layout
            };
            _miniWindow.Icon = Icon;
            _miniWindow.Closed += (_, _) =>
            {
                _miniWindow = null;
                _miniText = null;

                if (_suppressMiniWindowClosed)
                {
                    return;
                }

                _saveData.Settings.MiniMode = false;

                if (!IsVisible)
                {
                    Show();
                }

                if (WindowState == WindowState.Minimized)
                {
                    WindowState = WindowState.Normal;
                }

                Activate();
                AddJournal("Mini watch window closed. The full chronicle view returns.");
                Render();
            };
            _miniWindow.Show();
        }

        if (IsVisible)
        {
            Hide();
        }

        if (_miniText != null)
        {
            _miniText.Text = $"{Player.Name}\n{CurrentLivingTitle()}\nYear {CurrentYear()} • {Player.Season} • {Player.Location}\n{Player.ActivityName}\nRisk: {CurrentDeathRiskLabel()} • HP {Player.CurrentHp}/{Player.MaxHp}";
        }
    }

    private void ReturnToFullViewFromMini()
    {
        _saveData.Settings.MiniMode = false;
        CloseMiniWindowOnly();

        if (!IsVisible)
        {
            Show();
        }

        if (WindowState == WindowState.Minimized)
        {
            WindowState = WindowState.Normal;
        }

        Activate();
        AddJournal("Mini mode closed. The full chronicle view returns.");
        Render();
    }

    private void CloseMiniWindowOnly()
    {
        if (_miniWindow != null)
        {
            _suppressMiniWindowClosed = true;
            try
            {
                _miniWindow.Close();
            }
            finally
            {
                _suppressMiniWindowClosed = false;
            }
        }

        _miniWindow = null;
        _miniText = null;
    }

    private void UpdateCompanionPetMemoryBook()
    {
        foreach (var c in Player.Companions)
        {
            var mem = Player.CompanionPetMemories.FirstOrDefault(m => m.Name == c.Name && m.Kind == "Companion");
            if (mem == null)
            {
                mem = new CompanionMemory { Name = c.Name, Kind = "Companion", FavoriteMemory = c.PersonalArc };
                Player.CompanionPetMemories.Add(mem);
            }
            mem.Bond = c.Bond;
            mem.Status = c.IsActive ? "Traveling" : "Gone";
            mem.YearsTogether = Math.Max(mem.YearsTogether, CurrentYear() - 1);
        }
        foreach (var pet in Player.PetsMounts)
        {
            var mem = Player.CompanionPetMemories.FirstOrDefault(m => m.Name == pet.Name && m.Kind == "Pet/Mount");
            if (mem == null)
            {
                mem = new CompanionMemory { Name = pet.Name, Kind = "Pet/Mount", FavoriteMemory = pet.Summary };
                Player.CompanionPetMemories.Add(mem);
            }
            mem.Bond = pet.Bond;
            mem.Status = pet.IsAlive ? "Alive" : "Lost";
            mem.YearsTogether = Math.Max(mem.YearsTogether, CurrentYear() - 1);
        }
        while (Player.CompanionPetMemories.Count > 80) Player.CompanionPetMemories.RemoveAt(0);
    }

    private string ModsFolder() => Path.Combine(Path.GetDirectoryName(_saveService.SavePath) ?? Environment.CurrentDirectory, "Mods");

    private void MainMenuButton_Click(object sender, RoutedEventArgs e) { _saveData.Settings.ShowMainMenu = true; Render(); }
    private void MenuContinue_Click(object sender, RoutedEventArgs e) { _saveData.Settings.ShowMainMenu = false; Render(); }
    private void MenuNewWorld_Click(object sender, RoutedEventArgs e)
    {
        var result = System.Windows.MessageBox.Show(
            "Start a brand-new chronicle? Your current save will be backed up first, but the active slot will begin a new world.",
            "New Chronicle",
            System.Windows.MessageBoxButton.YesNo,
            System.Windows.MessageBoxImage.Warning);
        if (result != System.Windows.MessageBoxResult.Yes) return;

        SaveGame(false);
        _saveService.BackupCurrentSave("before_new_chronicle");
        _saveData.Settings.ShowMainMenu = false;
        OpenCharacterBuilder(clearLegends: true);
        Render();
    }
    private void MenuHall_Click(object sender, RoutedEventArgs e) { _saveData.Settings.ShowMainMenu = false; MainStoryTabs.SelectedIndex = 2; Render(); }
    private void MenuMods_Click(object sender, RoutedEventArgs e) { _saveData.Settings.ShowMainMenu = false; OpenFolder(ModsFolder()); Render(); }
    private void MenuPatch_Click(object sender, RoutedEventArgs e) { _saveData.Settings.ShowMainMenu = false; AddJournal("Patch notes are available in the Tools tab."); Render(); }
    private void MenuExit_Click(object sender, RoutedEventArgs e) { SaveGame(false); System.Windows.Application.Current.Shutdown(); }

    private void SoundButton_Click(object sender, RoutedEventArgs e)
    {
        _saveData.Settings.SoundEnabled = !_saveData.Settings.SoundEnabled;
        if (_saveData.Settings.SoundEnabled)
        {
            try { System.Media.SystemSounds.Asterisk.Play(); } catch { }
        }
        AddJournal(_saveData.Settings.SoundEnabled ? "Sound cues are on. Major events will play a small system sound." : "Sound cues are off.");
        HintText.Text = _saveData.Settings.SoundEnabled ? "Sound cues enabled." : "Sound cues disabled.";
        Render();
    }

    private void MiniModeButton_Click(object sender, RoutedEventArgs e)
    {
        _saveData.Settings.MiniMode = !_saveData.Settings.MiniMode;
        AddJournal(_saveData.Settings.MiniMode
            ? "Mini mode opens as a small watch window and hides the full chronicle view."
            : "Mini mode is off. The full chronicle view returns.");
        Render();
    }

    private void PauseMajorButton_Click(object sender, RoutedEventArgs e)
    {
        _saveData.Settings.PauseOnMajorEvents = !_saveData.Settings.PauseOnMajorEvents;
        AddJournal(_saveData.Settings.PauseOnMajorEvents ? "Pause-on-major-events is on. Big moments will stop the clock so they are not missed." : "Pause-on-major-events is off. The chronicle will keep flowing through big moments.");
        Render();
    }

    private void ExportWorldButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveGame(false);
            using var dialog = new Forms.SaveFileDialog { Title = "Export Mayflower World", Filter = "Mayflower save (*.json)|*.json", FileName = $"MayflowerWorld_{_saveService.ActiveSlot.Replace(" ", "")}_{DateTime.Now:yyyyMMdd_HHmm}.json" };
            if (dialog.ShowDialog() != Forms.DialogResult.OK) return;
            File.Copy(_saveService.SavePath, dialog.FileName, true);
            _saveData.Transfers.Add(new ImportExportRecord { Action = "Export", Path = dialog.FileName });
            AddJournal($"World export created: {dialog.FileName}");
            Render();
            HintText.Text = $"Export complete: {dialog.FileName}";
        }
        catch (Exception ex) { HintText.Text = "Export failed: " + ex.Message; }
    }

    private void ImportWorldButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var dialog = new Forms.OpenFileDialog { Title = "Import Mayflower World", Filter = "Mayflower save (*.json)|*.json|All files (*.*)|*.*" };
            if (dialog.ShowDialog() != Forms.DialogResult.OK) return;
            var result = System.Windows.MessageBox.Show(
                "Importing replaces the active save slot. A backup of the current slot will be created first. Continue?",
                "Import World",
                System.Windows.MessageBoxButton.YesNo,
                System.Windows.MessageBoxImage.Warning);
            if (result != System.Windows.MessageBoxResult.Yes) return;
            SaveGame(false);
            _saveService.BackupCurrentSave("before_import");
            Directory.CreateDirectory(Path.GetDirectoryName(_saveService.SavePath) ?? Environment.CurrentDirectory);
            File.Copy(dialog.FileName, _saveService.SavePath, true);
            _saveData = _saveService.Load();
            EnsureSaveData();
            _saveData.Transfers.Add(new ImportExportRecord { Action = "Import", Path = dialog.FileName });
            _storyLog.Clear();
            _storyLog.AddRange(_saveData.StoryLog.TakeLast(280));
            AddJournal($"World import loaded from {dialog.FileName}");
            Render();
            HintText.Text = "Import complete. Current slot was backed up first.";
        }
        catch (Exception ex) { HintText.Text = "Import failed: " + ex.Message; }
    }

    private void BugReportButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveGame(false);
            string reportRoot = Path.Combine(Path.GetDirectoryName(_saveService.SavePath) ?? Environment.CurrentDirectory, "BugReports", DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(reportRoot);
            File.Copy(_saveService.SavePath, Path.Combine(reportRoot, "active_save.json"), true);
            File.WriteAllText(Path.Combine(reportRoot, "recent_journal.txt"), string.Join(Environment.NewLine + Environment.NewLine, _storyLog.TakeLast(160)));
            File.WriteAllText(Path.Combine(reportRoot, "balance_details.txt"), RenderDebugText() + Environment.NewLine + Environment.NewLine + RenderDirectorText());
            File.WriteAllText(Path.Combine(reportRoot, "mods.txt"), RenderModManagerText());
            File.WriteAllText(Path.Combine(reportRoot, "settings.txt"), RenderSettingsText());
            File.WriteAllText(Path.Combine(reportRoot, "build_info.txt"), ReleaseDiagnostics.GetBuildInfo());
            if (Directory.Exists(ReleaseDiagnostics.LogsFolder))
            {
                string logsOut = Path.Combine(reportRoot, "logs");
                Directory.CreateDirectory(logsOut);
                foreach (string log in Directory.GetFiles(ReleaseDiagnostics.LogsFolder).OrderByDescending(File.GetLastWriteTimeUtc).Take(10))
                    File.Copy(log, Path.Combine(logsOut, Path.GetFileName(log)), overwrite: true);
            }
            string zip = reportRoot.TrimEnd(Path.DirectorySeparatorChar) + ".zip";
            if (File.Exists(zip)) File.Delete(zip);
            ZipFile.CreateFromDirectory(reportRoot, zip);
            AddJournal($"Bug report zip created: {zip}");
            OpenFolder(Path.GetDirectoryName(zip) ?? reportRoot);
            Render();
            HintText.Text = $"Bug report created: {zip}";
        }
        catch (Exception ex) { HintText.Text = "Bug report failed: " + ex.Message; }
    }

    private void ReloadModsButton_Click(object sender, RoutedEventArgs e)
    {
        LoadCustomModEvents();
        AddJournal($"Mods reloaded. Loaded custom events: {_customEvents.Count}.");
        Render();
    }

    private void OpenModsButton_Click(object sender, RoutedEventArgs e) => OpenFolder(ModsFolder());

    private void SampleModButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string folder = Path.Combine(ModsFolder(), "Events");
            Directory.CreateDirectory(folder);
            string path = Path.Combine(folder, "custom_event_example.json");
            var sample = new List<ModEventDefinition>
            {
                new() { Name = "The Door With No Handle", Rarity = "Epic", Location = "Any", MinimumYear = 3, Text = "A door with no handle appears on a wall that had no business having doors.", Effect = "Luck:+3;Morale:-1" }
            };
            File.WriteAllText(path, JsonSerializer.Serialize(sample, new JsonSerializerOptions { WriteIndented = true }));
            AddJournal($"Sample mod written to {path}");
            LoadCustomModEvents();
            Render();
        }
        catch (Exception ex) { HintText.Text = "Sample mod failed: " + ex.Message; }
    }

    private string RenderWatchText()
    {
        string latest = _storyLog.LastOrDefault() ?? "The journal is waiting for the first real sentence.";
        string companions = Player.Companions.Any(c => c.IsActive) ? string.Join(", ", Player.Companions.Where(c => c.IsActive).Select(c => c.Name)) : "none";
        string pets = Player.PetsMounts.Any(p => p.IsAlive) ? string.Join(", ", Player.PetsMounts.Where(p => p.IsAlive).Select(p => p.Name + " the " + p.Species)) : "none";
        return $"{Player.Name} — {CurrentLivingTitle()}\n\nYear {CurrentYear()}, Day {DayOfYear()}, {Player.StoryHour:00}:{Player.StoryMinute:00}\n{Player.Season} • {Player.Weather} • {Player.Location}\n\nCurrent: {Player.ActivityName}\n{Player.CurrentActivity}\n\nHP {Player.CurrentHp}/{Player.MaxHp} • Energy {Player.Energy}/100 • Hunger {Player.Hunger}/100 • Morale {Player.Morale}/100\nGold {Player.Gold} • Supplies {Player.Supplies} • Potions {Player.Potions}\n\nCompanions: {companions}\nPets: {pets}\n\nRisk: {CurrentDeathRiskLabel()} • Safe danger {SafeDangerLimit()} • Stability {LongLifeStabilityBonus()}\n\nLatest journal:\n{latest}";
    }

    private string RenderDebugText()
    {
        int deathRisk = CurrentDeathRiskScore();
        int retreat = Math.Clamp(40 + Player.SurvivalBonus + LongLifeStabilityBonus() - EffectiveDanger(Player.ActivityDanger) / 2, 0, 98);
        int healing = Math.Clamp(25 + Player.InfirmaryTier * 10 + Player.Potions * 6 + ((Player.Location is "Brindlewick" or "Riverglass Port") ? 18 : 0), 0, 100);
        int hungerDanger = Math.Clamp(Player.Hunger - 55, 0, 45);
        int injuryDanger = Player.Injuries.Count(i => i.IsActive) * 8;
        int diseaseDanger = Player.Diseases.Where(d => d.IsActive).Sum(d => d.Severity / 4);
        int questDanger = EffectiveDanger(Player.ActivityDanger);
        string source = "Normal drift";
        var sources = new Dictionary<string, int>
        {
            ["Hunger"] = hungerDanger,
            ["Injury"] = injuryDanger,
            ["Disease"] = diseaseDanger,
            ["Current activity"] = questDanger,
            ["World pressure"] = World.BanditPower / 3 + World.MonsterPressure / 3 + World.Plague / 4
        };
        source = sources.OrderByDescending(kv => kv.Value).First().Key;
        return $"Balance Details\n\nDeath risk estimate: {deathRisk}% ({CurrentDeathRiskLabel()})\nMain danger source: {source}\nRetreat chance estimate: {retreat}%\nHealing access: {healing}%\nHunger danger: {hungerDanger}\nInjury danger: {injuryDanger}\nDisease danger: {diseaseDanger}\nQuest/activity danger: {questDanger}\nSafe danger limit: {SafeDangerLimit()}\nLong-life stability bonus: {LongLifeStabilityBonus()}\nCheat-death bonus: {CheatDeathBonus()}\nHourly difficulty risk modifier: {DifficultyRiskHourly()}\nLayered rescues used: {Player.RescueLayersUsed}\n\nCurrent activity raw:\nType: {Player.ActivityType}\nTotal minutes: {Player.ActivityTotalMinutes}\nRemaining: {Player.ActivityMinutesRemaining}\nReward: {Player.ActivityRewardGold} gold / {Player.ActivityRewardXp} XP\nFaction: {(string.IsNullOrWhiteSpace(Player.ActivityFaction) ? "none" : Player.ActivityFaction)}\n\nEvent weights:\nSocial {SocialChance()} • Legendary {LegendaryEventChance()} • Companion chance {CompanionMeetChance()} • Research {(ShouldResearch() ? "possible" : "unlikely")} • Pet care {(ShouldPetCare() ? "possible" : "unlikely")}";
    }

    private int CurrentDeathRiskScore()
    {
        int risk = 0;
        risk += Math.Clamp(100 - PercentValueInt(Player.CurrentHp, Player.MaxHp), 0, 100) / 3;
        risk += Math.Clamp(Player.Hunger - 50, 0, 50) / 2;
        risk += Math.Clamp(35 - Player.Energy, 0, 35) / 2;
        risk += Player.Injuries.Count(i => i.IsActive) * 4;
        risk += Player.Diseases.Where(d => d.IsActive).Sum(d => d.Severity / 8);
        risk += EffectiveDanger(Player.ActivityDanger) / 8;
        risk += DifficultyRiskHourly() * 4;
        risk -= LongLifeStabilityBonus() / 3;
        risk -= Player.Potions * 2;
        risk -= Player.Companions.Count(c => c.IsActive) * 4;
        return Math.Clamp(risk, 0, 100);
    }

    private int PercentValueInt(int value, int max) => max <= 0 ? 0 : Math.Clamp((int)Math.Round(value * 100.0 / max), 0, 100);

    private string CurrentDeathRiskLabel()
    {
        int score = CurrentDeathRiskScore();
        return score switch { <= 10 => "calm", <= 25 => "watchful", <= 45 => "dangerous", <= 70 => "critical", _ => "catastrophic" };
    }

    private string RenderAchievementsText()
    {
        EnsureAchievementSeeds();
        int unlocked = _saveData.Achievements.Count(a => a.Unlocked);
        return $"Achievements unlocked: {unlocked}/{_saveData.Achievements.Count}\n\n" + string.Join("\n", _saveData.Achievements.OrderByDescending(a => a.Unlocked).ThenBy(a => a.Name).Select(a => "• " + a.Summary));
    }

    private string RenderStatsText()
    {
        if (_saveData.StatHistory.Count == 0) return "No stat snapshots yet. The game records one every seven story days.";
        var latest = _saveData.StatHistory.TakeLast(18).ToList();
        string Bar(int value) => new string('█', Math.Clamp(value / 5, 0, 20)).PadRight(20, '░');
        var lines = latest.Select(s => $"Y{s.Year} D{s.Day:000} | HP {Bar(s.HpPercent)} {s.HpPercent,3}% | Danger {Bar(s.WorldDanger)} {s.WorldDanger,3}% | Safety {Bar(s.TownSafety)} {s.TownSafety,3}% | Gold {s.Gold} | Score {s.Score}");
        return "Recent world/hero graphs\n\n" + string.Join("\n", lines) + $"\n\nSnapshots stored: {_saveData.StatHistory.Count}\nThis stays text-based for a stable release build.";
    }

    private string RenderPatchNotesText()
    {
        EnsurePatchNotes();
        return string.Join("\n\n", _saveData.PatchNotes.Select(n => "• " + n));
    }

    private string RenderEventTesterText()
    {
        string tests = _saveData.EventTests.Count == 0 ? "No event checks yet. Press Run Event Check to simulate one safely." : string.Join("\n\n", _saveData.EventTests.TakeLast(8).Reverse().Select(t => $"• {t.Name} [{t.TestedUtc:g}]\n  {t.Result}"));
        return $"Event Check\nLoaded custom events: {_customEvents.Count}\nMod folders: Mods/Events, Mods/Companions, Mods/Artifacts, Mods/Towns, Mods/Gods, Mods/Traits, Mods/Backgrounds, Mods/Diseases, Mods/StoryArcs\n\n{tests}";
    }

    private string CurrentLivingTitle()
    {
        if (Player.StoryDay >= 3600) return "Decade-Worn Legend";
        if (Player.StoryDay >= 1800) return "Five-Year Flame";
        if (Player.LegendaryEventsSeen >= 4) return "Myth-Touched";
        if (Player.GuildHallTier >= 3) return "Hall-Builder";
        if (Player.Companions.Any(c => c.IsActive && c.Bond >= 80)) return "Sworn Friend";
        if (Player.StoryDay >= 720) return "Road-Rooted Survivor";
        if (Player.Reputation >= 30) return "Lantern-Bearer";
        return "Still Becoming Someone";
    }

    private string RenderWorldText()
    {
        var location = CurrentLocation();
        int generated = World.DiscoveredLocations?.Count ?? 0;
        return $"Location: {location.Name} ({location.Kind})\n{location.Flavor}\nRoutes: {string.Join(", ", location.Routes)}\nBase danger: {location.Danger} • Reward: {location.Reward}\n\nLiving atlas:\nKnown places: {_locations.Count}\nGenerated discoveries: {generated}\nWorld seed: {World.ProceduralSeed}\nExpansion count: {World.WorldExpansionCount}\n\nWorld simulation:\nTown wealth: {World.TownWealth}/100\nRoad safety: {World.RoadSafety}/100\nMonster pressure: {World.MonsterPressure}/100\nBandit power: {World.BanditPower}/100\nFood supply: {World.FoodSupply}/100\nPlague: {World.Plague}/100\nWar tension: {World.WarTension}/100\nMagic instability: {World.MagicInstability}/100\nEconomy: {World.Economy}/100\n\nLatest world event: {World.LastMajorEvent}";
    }

    private string RenderGuildText()
    {
        return $"Guild hall: {Player.GuildHallTier}\nInfirmary: {Player.InfirmaryTier}\nStable: {Player.StableTier}\nLibrary: {Player.LibraryTier}\nShrine: {Player.ShrineTier}\nBlacksmith: {Player.BlacksmithTier}\nMemorial garden: {Player.MemorialGardenTier}\n\nThe hall gives long-term safety, healing, travel, lore, morale, gear, and legacy bonuses. The hero invests automatically when town, wealthy, and not urgently dying.";
    }


    private string RenderLivingWorldText()
    {
        var history = World.WorldHistory.TakeLast(10).Select(h => $"• Y{h.Year} D{h.Day} [{h.Category}] {h.Text}");
        var diseases = Player.Diseases.Where(d => d.IsActive).Select(d => "• " + d.Summary).ToList();
        var scars = Player.EmotionalScars.Where(e => e.IsActive).Select(e => "• " + e.Summary).ToList();
        var dreams = Player.Dreams.TakeLast(8).Select(d => "• " + d.Summary).ToList();
        string mythic = Player.IsImmortal ? "active" : Player.MythicPathProgress + "%";
        string diseaseText = diseases.Count == 0 ? "None active." : string.Join("\n", diseases);
        string scarText = scars.Count == 0 ? "No active scars or inspirations." : string.Join("\n", scars);
        string dreamText = dreams.Count == 0 ? "No recorded omens yet." : string.Join("\n", dreams);
        string historyText = World.WorldHistory.Count == 0 ? "The history book is still mostly blank." : string.Join("\n", history);
        return $"Era: {World.CurrentEra}\nAge: {Player.AgeYears} years, {Player.AgeDays} days\nMythic path: {Player.ImmortalityPath} {mythic}\nFamily: {Player.FamilyStatus}\n\nDiseases:\n{diseaseText}\n\nEmotional state:\n{scarText}\n\nDreams and omens:\n{dreamText}\n\nWorld history:\n{historyText}";
    }

    private string RenderTownText()
    {
        if (World.Towns.Count == 0) return "No town records yet.";
        return string.Join("\n\n", World.Towns.OrderBy(t => t.Name).Select(t => "• " + t.Summary + (t.LocalHistory.Count == 0 ? "" : "\n  " + string.Join("\n  ", t.LocalHistory.TakeLast(3)))));
    }

    private string RenderBloodlineText()
    {
        if (World.Bloodlines.Count == 0) return "No bloodlines yet.";
        return string.Join("\n\n", World.Bloodlines.OrderByDescending(b => b.GenerationCount).ThenByDescending(b => b.Reputation).Take(12).Select(b => "• " + b.Summary + (b.FamilyHistory.Count == 0 ? "" : "\n  " + string.Join("\n  ", b.FamilyHistory.TakeLast(4)))));
    }

    private string RenderArtifactText()
    {
        var heroArtifacts = Player.Artifacts.Count == 0 ? "None held." : string.Join("\n", Player.Artifacts.Select(a => "• " + a.Summary));
        var worldArtifacts = World.WorldArtifacts.Count == 0 ? "No known loose artifacts." : string.Join("\n", World.WorldArtifacts.Take(12).Select(a => "• " + a.Summary));
        return $"Held artifacts:\n{heroArtifacts}\n\nKnown world artifacts:\n{worldArtifacts}";
    }

    private string RenderRivalNemesisText()
    {
        string nemeses = World.Nemeses.Count == 0 ? "No nemeses recorded yet." : string.Join("\n", World.Nemeses.OrderByDescending(n => n.Threat + n.Grudge).Take(10).Select(n => "• " + n.Summary));
        string rivals = World.Rivals.Count == 0 ? "No rival adventurers yet." : string.Join("\n", World.Rivals.OrderByDescending(r => r.Fame).Take(12).Select(r => "• " + r.Summary));
        return $"Nemeses:\n{nemeses}\n\nRival adventurers:\n{rivals}";
    }

    private string RenderFaithMagicText()
    {
        return $"Faith:\n{Player.Faith.Summary}\n\nResearch:\n{Player.Research.Summary}\n\nMagic instability: {World.MagicInstability}/100\nPlague pressure: {World.Plague}/100\n\nGods known in this region:\n• {string.Join("\n• ", _gods)}";
    }

    private string RenderHomePetsText()
    {
        string pets = Player.PetsMounts.Count == 0 ? "No pets or mounts yet." : string.Join("\n", Player.PetsMounts.Select(p => "• " + p.Summary));
        string child = Player.HasChild
            ? $"Child: {Player.ChildName}, age {Player.ChildAgeYears}y {Player.ChildAgeDays}d • {(Player.ChildIsAdopted ? "adopted" : "born into the house")} • {Player.ChildStatus}"
            : "Child: none yet";
        return $"Home: {Player.HomeName}\nHome tier: {Player.HomeTier} • Comfort: {Player.HomeComfort}/100 • Garden: {Player.GardenTier} • Trophies: {Player.TrophyCount}\nFamily members: {Player.FamilyMembers} • Apprentices: {Player.Apprentices} • Heir/apprentice name: {Player.HeirName}\n{child}\n\nPets and mounts:\n{pets}";
    }

    private string RenderBulletinText()
    {
        string bulletins = World.Bulletins.Count == 0 ? "No bulletins printed yet. Wait for a town newspaper cycle." : string.Join("\n\n", World.Bulletins.TakeLast(6).Reverse().Select(b => b.Summary));
        return $"Recent bulletins:\n\n{bulletins}\n\nLoaded custom JSON mod events: {_customEvents.Count}\nSample mods live in the save folder under Mods/events.sample.json.";
    }

    private string RenderRulesText()
    {
        return $"Difficulty presets:\n• Cozy Chronicle: story-first, very forgiving.\n• Adventurer: balanced danger.\n• Endless Legend: long lives with real but rare death.\n• Harsh World: sharper failures.\n• Iron Fate: unforgiving, cheat-death gets weaker.\n\nCurrent broad life rule: {Player.LifePhilosophy}\nThis is not direct control. It nudges idle choices: safety, glory, helping, wealth, avoiding violence, trusting companions, refusing to abandon quests, chasing legends, or retiring wealthy.\n\nJSON modding: the game creates a Mods folder next to the save file. Add *.json files containing arrays of custom events with Name, Rarity, Text, Location, Effect, and MinimumYear. Loaded events: {_customEvents.Count}.\n\nTray mode: minimizing hides the window and keeps the world running in the system tray.";
    }

    private string RenderLegacyText()
    {
        if (_saveData.HallOfLegends.Count == 0) return "No legends recorded yet. Completed lives will appear here.";
        return string.Join("\n\n", _saveData.HallOfLegends.OrderByDescending(l => l.Score).Take(12).Select((l, i) => $"{i + 1}. Gen {l.Generation}: {l.Name}, {l.Title} [{l.EndType}]\n   {FormatLegacyDays(l.DaysSurvived)}, lvl {l.Level}, score {l.Score}, age {l.AgeYears}, {l.FinalLocation}\n   House {l.BloodlineName} • Heir: {l.HeirName} • {l.ImmortalityPath}\n   Artifacts: {(string.IsNullOrWhiteSpace(l.Artifacts) ? "None" : l.Artifacts)}\n   {l.CauseOfEnd}"));
    }

    private string FormatLegacyDays(int days)
    {
        int years = Math.Max(0, days) / 360;
        int rem = Math.Max(0, days) % 360;
        return years <= 0 ? $"{days}d" : $"{years}y {rem}d";
    }

    private double PercentValue(int value, int max)
    {
        if (max <= 0) return 0;
        return Math.Clamp((value * 100.0) / max, 0, 100);
    }

    private string BuildLifeStoryText(bool shortVersion)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"The Life of {Player.Name}, {Player.FinalTitle}");
        sb.AppendLine($"Generation {Player.Generation} • Age {Player.AgeYears} • House {Player.BloodlineName} • {Player.Background} • {string.Join(", ", Player.Traits)}");
        sb.AppendLine($"Family: {Player.FamilyStatus} • Heir/apprentice: {Player.HeirName} • Child: {(Player.HasChild ? Player.ChildName + " age " + Player.ChildAgeYears : "none")} • Mythic path: {Player.ImmortalityPath} {(Player.IsImmortal ? "active" : Player.MythicPathProgress + "%")}");
        sb.AppendLine($"Difficulty: {Player.Difficulty} • Life rule: {Player.LifePhilosophy}");
        sb.AppendLine($"Time survived: {FormatSurvivedTime()} • Level {Player.Level} • Score {Player.SurvivalScore}");
        sb.AppendLine($"Ending: {(Player.IsRetired ? "Retirement" : Player.IsAlive ? "Still alive" : "Death")} — {Player.CauseOfEnd}");
        sb.AppendLine();
        sb.AppendLine($"Quests completed/failed: {Player.QuestsCompleted}/{Player.QuestsFailed}");
        sb.AppendLine($"Companions met/lost: {Player.CompanionsMet}/{Player.CompanionsLost}");
        sb.AppendLine($"Legendary events: {Player.LegendaryEventsSeen} • Artifacts: {Player.ArtifactsFound} • Pets: {Player.PetsMet} • Research breakthroughs: {Player.ResearchBreakthroughs} • Mysteries: {Player.MysteryEventsSeen}");
        sb.AppendLine($"Guild hall: {Player.GuildHallTier}, infirmary {Player.InfirmaryTier}, stable {Player.StableTier}, library {Player.LibraryTier}, shrine {Player.ShrineTier}, blacksmith {Player.BlacksmithTier}, memorial garden {Player.MemorialGardenTier}");
        sb.AppendLine($"Home: {Player.HomeName}, tier {Player.HomeTier}, comfort {Player.HomeComfort}, garden {Player.GardenTier}");
        sb.AppendLine($"Faith: {Player.Faith.Summary}");
        sb.AppendLine($"Research: {Player.Research.Summary}");
        sb.AppendLine($"Artifacts: {(Player.Artifacts.Count == 0 ? "None" : string.Join(", ", Player.Artifacts.Select(a => a.Name)))}");
        sb.AppendLine($"Pets/mounts: {(Player.PetsMounts.Count == 0 ? "None" : string.Join(", ", Player.PetsMounts.Select(p => p.Name + " the " + p.Species)))}");
        sb.AppendLine($"Memory tags: {(Player.MemoryTags.Count == 0 ? "None" : string.Join(", ", Player.MemoryTags.TakeLast(12)))}");
        sb.AppendLine($"Achievements unlocked: {_saveData.Achievements.Count(a => a.Unlocked)}/{_saveData.Achievements.Count}");
        if (shortVersion) return sb.ToString();
        sb.AppendLine();
        sb.AppendLine("Major timeline:");
        foreach (string line in Player.Timeline.TakeLast(120)) sb.AppendLine(line);
        sb.AppendLine();
        sb.AppendLine("Recent journal:");
        foreach (string line in _storyLog.TakeLast(120)) { sb.AppendLine(line); sb.AppendLine(); }
        return sb.ToString();
    }

    private void SelectCombo(System.Windows.Controls.ComboBox combo, string value)
    {
        foreach (object item in combo.Items)
        {
            if (item is System.Windows.Controls.ComboBoxItem cbi && string.Equals(cbi.Content?.ToString(), value, StringComparison.OrdinalIgnoreCase))
            {
                combo.SelectedItem = cbi;
                return;
            }
        }
        combo.SelectedIndex = 0;
    }

    private string ComboText(System.Windows.Controls.ComboBox combo, string fallback)
    {
        if (combo.SelectedItem is System.Windows.Controls.ComboBoxItem cbi && cbi.Content != null) return cbi.Content.ToString() ?? fallback;
        return fallback;
    }

    private void ApplyRulesButton_Click(object sender, RoutedEventArgs e)
    {
        string name = PlayerNameBox.Text.Trim();
        if (!string.IsNullOrWhiteSpace(name)) Player.Name = name;
        Player.Difficulty = ComboText(DifficultyBox, "Endless Legend");
        Player.LifePhilosophy = ComboText(PhilosophyBox, "Seek Balance");
        Player.OriginSeed = ComboText(OriginBox, Player.OriginSeed);
        _saveData.Settings.JournalPacing = ComboText(PacingBox, "Normal");
        _saveData.Settings.ThemeName = ComboText(ThemeBox, "Moonlit");
        AddJournal($"The chronicle updates its broad rule: {Player.LifePhilosophy} on {Player.Difficulty}, journal pacing {_saveData.Settings.JournalPacing}. The hero remains idle, but their instincts shift.");
        SaveGame(true);
        Render();
    }

    private void PauseButton_Click(object sender, RoutedEventArgs e)
    {
        _isPaused = !_isPaused;
        Render();
    }

    private void SpeedButton_Click(object sender, RoutedEventArgs e)
    {
        _speedIndex = (_speedIndex + 1) % _storyMinutesPerTick.Length;
        Render();
    }

    private void NewLifeButton_Click(object sender, RoutedEventArgs e)
    {
        if (Player.IsAlive && !Player.IsRetired)
        {
            var result = System.Windows.MessageBox.Show(
                "Begin a new life while the current character is still alive? A backup will be created first.",
                "New Life",
                System.Windows.MessageBoxButton.YesNo,
                System.Windows.MessageBoxImage.Question);
            if (result != System.Windows.MessageBoxResult.Yes) return;
            SaveGame(false);
            _saveService.BackupCurrentSave("before_new_life");
        }

        _legacySavedForThisEnd = false;
        OpenCharacterBuilder(clearLegends: false);
        Render();
    }

    private void AboutButton_Click(object sender, RoutedEventArgs e)
    {
        string message =
            ReleaseDiagnostics.GetBuildInfo() + Environment.NewLine + Environment.NewLine +
            $"Save slot: {_saveService.ActiveSlot}" + Environment.NewLine +
            $"Save folder: {_saveService.SaveFolder}" + Environment.NewLine +
            $"Save version: {_saveData.SaveVersion}" + Environment.NewLine +
            $"Last save: {_lastSaveStatus}";

        System.Windows.MessageBox.Show(
            message,
            "About Mayflower Idle RPG",
            System.Windows.MessageBoxButton.OK,
            System.Windows.MessageBoxImage.Information);
    }

    private void ResetWindowButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            _saveData.Settings.MiniMode = false;
            _saveData.Settings.WatchMode = false;
            WindowState = WindowState.Normal;
            Width = 1540;
            Height = 940;
            MinWidth = 1240;
            MinHeight = 790;
            Left = Math.Max(0, (SystemParameters.WorkArea.Width - Width) / 2 + SystemParameters.WorkArea.Left);
            Top = Math.Max(0, (SystemParameters.WorkArea.Height - Height) / 2 + SystemParameters.WorkArea.Top);
            AddJournal("Window layout reset to the release default.");
            Render();
            HintText.Text = "Window layout reset.";
        }
        catch (Exception ex)
        {
            ReleaseDiagnostics.LogException(ex, "ResetWindowButton_Click");
            HintText.Text = "Could not reset the window layout: " + ex.Message;
        }
    }

    private void OpenLogsButton_Click(object sender, RoutedEventArgs e)
    {
        try { ReleaseDiagnostics.OpenLogsFolder(); }
        catch (Exception ex) { HintText.Text = "Could not open logs folder: " + ex.Message; }
    }

    private void ExportStoryButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string? folder = Path.GetDirectoryName(_saveService.SavePath);
            folder ??= Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            Directory.CreateDirectory(folder);
            string safeName = string.Join("_", Player.Name.Split(Path.GetInvalidFileNameChars(), StringSplitOptions.RemoveEmptyEntries));
            string path = Path.Combine(folder, $"{safeName}_LifeStory_Gen{Player.Generation}_{DateTime.Now:yyyyMMdd_HHmmss}.txt");
            File.WriteAllText(path, BuildLifeStoryText(shortVersion: false));
            HintText.Text = $"Exported story to {path}";
            Process.Start(new ProcessStartInfo { FileName = folder, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            HintText.Text = "Export failed: " + ex.Message;
        }
    }

    private void SaveSlotButton_Click(object sender, RoutedEventArgs e)
    {
        string slot = ComboText(SaveSlotBox, "Slot 1");
        _saveService.SetActiveSlot(slot);
        _saveData.Settings.SaveSlot = slot;
        SaveGame(true);
        Render();
    }

    private void LoadSlotButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string slot = ComboText(SaveSlotBox, "Slot 1");
            if (!string.Equals(slot, _saveService.ActiveSlot, StringComparison.OrdinalIgnoreCase) && Player.IsAlive && !Player.IsRetired)
            {
                var result = System.Windows.MessageBox.Show(
                    $"Load {slot}? The current slot will be saved first.",
                    "Load Save Slot",
                    System.Windows.MessageBoxButton.YesNo,
                    System.Windows.MessageBoxImage.Question);
                if (result != System.Windows.MessageBoxResult.Yes) return;
            }
            SaveGame(false);
            _saveService.SetActiveSlot(slot);
            _saveData = _saveService.Load(slot);
            EnsureSaveData();
            _storyLog.Clear();
            _storyLog.AddRange(_saveData.StoryLog.TakeLast(520));
            if (_storyLog.Count == 0) AddJournal($"Loaded {slot}. No journal entries were found, so a fresh page is ready.");
            PlayerNameBox.Text = Player.Name;
            SelectCombo(DifficultyBox, Player.Difficulty);
            SelectCombo(PhilosophyBox, Player.LifePhilosophy);
            SelectCombo(PacingBox, _saveData.Settings.JournalPacing);
            SelectCombo(SaveSlotBox, slot);
            LoadCustomModEvents();
            ApplyOfflineProgress();
            Render();
            HintText.Text = $"Loaded {slot}.";
        }
        catch (Exception ex)
        {
            HintText.Text = "Load slot failed: " + ex.Message;
        }
    }

    private void RestoreBackupButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string slot = ComboText(SaveSlotBox, "Slot 1");
            _saveService.SetActiveSlot(slot);
            if (!_saveService.HasBackup(slot))
            {
                HintText.Text = $"No backup found for {slot}.";
                return;
            }

            var result = System.Windows.MessageBox.Show(
                $"Restore the latest backup for {slot}? The current save will be backed up first.",
                "Restore Backup",
                System.Windows.MessageBoxButton.YesNo,
                System.Windows.MessageBoxImage.Warning);
            if (result != System.Windows.MessageBoxResult.Yes) return;

            SaveGame(false);
            _saveService.BackupCurrentSave("before_restore");
            if (!_saveService.RestoreLatestBackup())
            {
                HintText.Text = $"No backup found for {slot}.";
                return;
            }
            _saveData = _saveService.Load(slot);
            EnsureSaveData();
            Player.BackupRestores++;
            _storyLog.Clear();
            _storyLog.AddRange(_saveData.StoryLog.TakeLast(520));
            AddJournal($"Backup restored for {slot}. The previous active save was backed up before the restore.");
            Render();
            HintText.Text = $"Restored latest backup for {slot}.";
        }
        catch (Exception ex)
        {
            HintText.Text = "Restore failed: " + ex.Message;
        }
    }

    private void WatchModeButton_Click(object sender, RoutedEventArgs e)
    {
        _saveData.Settings.WatchMode = !_saveData.Settings.WatchMode;
        if (_saveData.Settings.WatchMode)
        {
            Width = Math.Max(1040, Width);
            Height = Math.Max(760, Height);
            AddJournal("Watch mode is on. The side ledgers fold away, and the chronicle becomes a big desk-companion view.");
        }
        else
        {
            AddJournal("Watch mode is off. The hero sheet and world ledger return.");
        }
        SaveGame(false);
        Render();
    }

    private void TestEventButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string name;
            string result;
            var custom = _customEvents.Where(e => e.MinimumYear <= CurrentYear() && (e.Location == "Any" || e.Location == Player.Location)).OrderBy(_ => _random.Next()).FirstOrDefault();
            if (custom != null)
            {
                name = custom.Name;
                result = $"Would fire at {Player.Location}: {custom.Text}\nEffect string: {custom.Effect}\nRarity: {custom.Rarity}";
            }
            else
            {
                name = "Built-in Peaceful Callback";
                result = $"Would create a quiet-life event for {Player.Name} in {Player.Location}, adding morale/comfort and possibly a memory tag.";
            }
            _saveData.EventTests.Add(new EventTestResult { Name = name, Result = result, TestedUtc = DateTime.Now });
            while (_saveData.EventTests.Count > 30) _saveData.EventTests.RemoveAt(0);
            HintText.Text = "Event test completed.";
            Render();
        }
        catch (Exception ex)
        {
            HintText.Text = "Event check failed: " + ex.Message;
        }
    }

    private void OpenFolder(string folder)
    {
        try
        {
            Directory.CreateDirectory(folder);
            Process.Start(new ProcessStartInfo { FileName = folder, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            HintText.Text = "Could not open folder: " + ex.Message;
        }
    }

    private void OpenSaveButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string? folder = Path.GetDirectoryName(_saveService.SavePath);
            if (!string.IsNullOrWhiteSpace(folder)) Directory.CreateDirectory(folder);
            Process.Start(new ProcessStartInfo { FileName = folder ?? _saveService.SavePath, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            HintText.Text = "Could not open save folder: " + ex.Message;
        }
    }

    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
        try { SaveGame(false); } catch { }
        DisposeTrayIconSafely();
        base.OnClosing(e);
    }

}
