@echo off
setlocal
cd /d "%~dp0"

echo.
echo ================================================
echo   Mayflower Idle RPG - Single File EXE Build
echo ================================================
echo.

where dotnet >nul 2>nul
if errorlevel 1 (
    echo ERROR: .NET SDK was not found.
    echo Install the .NET 8 SDK, then run this file again.
    echo.
    pause
    exit /b 1
)

echo Restoring packages...
dotnet restore "MayflowerIdleRPG.csproj"
if errorlevel 1 goto failed

echo.
echo Publishing one self-contained Windows x64 EXE...
dotnet publish "MayflowerIdleRPG.csproj" ^
  -c Release ^
  -r win-x64 ^
  --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:IncludeNativeLibrariesForSelfExtract=true ^
  -p:IncludeAllContentForSelfExtract=true ^
  -p:EnableCompressionInSingleFile=true ^
  -p:PublishTrimmed=false ^
  -p:PublishReadyToRun=false ^
  -p:DebugType=embedded

if errorlevel 1 goto failed

echo.
echo Done.
echo Your release EXE should be here:
echo bin\Release\net8.0-windows\win-x64\publish\
echo.
for %%F in ("bin\Release\net8.0-windows\win-x64\publish\*.exe") do echo Built: %%~fF
echo.
pause
exit /b 0

:failed
echo.
echo Build failed. Copy the error text or screenshot it and send it to ChatGPT.
echo.
pause
exit /b 1
